package com.hp.frameworks.wpa.wsrp4j.om.common.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.pluto.om.common.Preference;
import org.apache.pluto.om.common.PreferenceCtrl;

public class WPAPreferenceImpl implements Preference, PreferenceCtrl,
        Serializable, Cloneable
{

    // ---------------------------------------------------------- Class Members
    
    
    // String representation of an empty preference value list
    private final static String NULL_VALUE = "#*!0_NULL_0!*#";
    
    // String representation of a null value within preference value list
    private final static String NULL_ARRAYENTRY = "#*!1_NULL_1!*#";

    
    // ------------------------------------------------------ Protected Members
    
    
    // Preference name
    protected String name;
    
    // List of preference string values
    protected ArrayList values;
    
    // Flag indicating whether or not the preference is read-only
    protected Boolean readOnly;

    // Unique database key associated with this preference
    protected String registryId;
    
    
    // --------------------------------------------------------- Public Methods
    
    
    /**
     * Return the name of this preference
     */
    public String getName()
    {
        return this.name;
    }


    /**
     * Returns an iterator for all the preference values.  Returns null
     * if there are no values associated with this preference.
     */
    public Iterator getValues()
    {
        // Replace the NULL_VALUE String by NULL
        if (this.values.contains(NULL_VALUE)) 
        {
            return null;
        }

        ArrayList returnValue = new ArrayList(this.values.size());
        returnValue.addAll(this.values);

        // Replace all NULL_ARRAYENTRY Strings by NULL
        for (int i = 0; i < returnValue.size(); i++) 
        {
            if (NULL_ARRAYENTRY.equals(returnValue.get(i))) 
            {
                returnValue.set(i, null);
            }
        }

        return returnValue.iterator();
    }


    /**
     * Returns a flag indicating whether or not this preference is read-only.
     */
    public boolean isReadOnly()
    {
        boolean readOnly = false;
        
        if (this.readOnly != null)
        {
            readOnly = this.readOnly.booleanValue(); 
        }
        
        return readOnly; 
    }


    /**
     * Returns a flag indicating whether or not any values have yet been set
     * for this preference.
     */
    public boolean isValueSet()
    {
        return (this.values != null);
    }


    /**
     * Sets the name of this preference.
     */
    public void setName(String name)
    {
        this.name = name;
    }


    /**
     * Sets the list of values for this preference.
     */
    public void setValues(List values)
    {
        // Either create new list or clear old one
        if (this.values == null) 
        {
            this.values = new ArrayList();
        } 
        else 
        {
            this.values.clear();
        }

        List addValue = null;

        // Replace NULL by the NULL_VALUE String
        if (values == null) 
        {
            addValue = new ArrayList(1);
            addValue.add(NULL_VALUE); 
        } 
        else 
        {
            // Replace all NULL by the NULL_ARRAYENTRY String
            addValue = new ArrayList(values.size());
            addValue.addAll(values);
            
            for (int i = 0; i < addValue.size(); i++) 
            {
                if (addValue.get(i) == null) 
                {
                    addValue.set(i, NULL_ARRAYENTRY);
                }
            }
        }

        this.values.addAll(addValue);
    }


    /**
     * Sets the flag indicating whether or not this preference is read-only.
     */
    public void setReadOnly(String readOnly)
    {
        this.readOnly = Boolean.valueOf(readOnly);
    }

    
    /**
     * Returns the database ID for this preference.
     */
    public String getRegistryId()
    {
        return this.registryId;        
    }
    
    
    /**
     * Sets the database ID for this preference.
     */
    public void setRegistryId(String registryId)
    {
        this.registryId = registryId;
    }
    

    /**
     * Returns a clone of this preference.  All the properties of the clone 
     * will be identical to that of the original object except for the
     * registry ID which will be set to null.
     */
    public Object clone() 
    {
        WPAPreferenceImpl clone = null;
        
        try
        {
            clone = (WPAPreferenceImpl) super.clone();
            clone.registryId = null;
            
            if (this.isValueSet())
            {
                clone.values = new ArrayList();
                clone.setValues(this.values);
            }
        }
        catch (CloneNotSupportedException e) { }
        
        return clone;
    }


    public String toString()
    {
        StringBuffer buffer = new StringBuffer();
        
        buffer.append(this.getClass().toString());
        buffer.append("{ ");        
        buffer.append("Name: " + this.name);
        buffer.append("Read Only: " + this.readOnly);
        buffer.append("Values: " + this.values.toString());
        buffer.append(" }");
        
        return buffer.toString();
    }    
}
