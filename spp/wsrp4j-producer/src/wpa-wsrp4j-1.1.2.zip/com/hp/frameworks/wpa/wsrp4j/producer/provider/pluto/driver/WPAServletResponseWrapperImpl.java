package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;


import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.util.Utility;

import java.io.*;


/**
 * <p>
 * This class is used to buffer the rendered response when a portlet is invoked.
 * This class is being used as a replacement for the WSRP4J-provided
 * StoredResponse class. StoredResponse implements only the getWriter() method,
 * however the getOutputStream() method is needed for compatibility with
 * WebLogic.
 * </p>
 * 
 * <p>
 * This class is implemented as a HttpServletResponseWrapper instead of a simple
 * extension to the StoredResponse class. This was necessary because there is
 * some code in WebLogic that looks specifically for an instance of their
 * response object. By wrapping the original response we can still capture the
 * generated output and make WebLogic happy at the same time.
 * </p>
 *
 * <p>
 * This class also provides a proper implementation of sendRedirect to handle
 * remote portlet redirects.  And it overrides several methods to provide
 * a character encoding, UTF-8, that will work with non-ASCII characters in
 * portlet pages.  For whatever reason, the RenderResponseImpl.setContentType
 * method of Pluto/WSRP4J strips off any charset data the developer provides.
 * As such, when the contentType string reached our resposne wrapper, the
 * character encoding was defaulting to ISO-8859 and non-ASCII characters
 * were being rendered as question marks when using the output stream
 * rather than the PrintWriter.
 * </p>
 *
 * <p>
 * This class is directly instantiated in both the invokeGetMarkup() and
 * invokedPerformBlockingInteraction() methods of the WPAProtletInvokerImpl
 * class.
 * </p>
 */
public class WPAServletResponseWrapperImpl extends HttpServletResponseWrapper
        implements Serializable
{
    
	// ---------------------------------------------------------- Class Members  
    
    
    private static final Log log = 
        LogFactory.getLog(WPAServletResponseWrapperImpl.class);

    
	// ------------------------------------------------------ Protected Members

    //
    protected String contentType;

    //
    protected boolean charsetSet;

    //
    protected String characterEncoding;

    // String writer used when getWriter() is called
    protected StringWriter stringWriter;

    // Wrapper for the string writer
    protected PrintWriter writer;

    // Byte array stream used when getOutputStream is called
    protected ByteArrayOutputStream byteArrayOutputStream;

    protected String location;

    public String getLocation() {
        return location;
    }

    // ----------------------------------------------------------- Constructors


    public WPAServletResponseWrapperImpl(HttpServletResponse response)
    {
		super(response);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("constructor"));
            log.debug(Utility.strExit("constructor"));
        } 
	}


	// --------------------------------------------------------- Public Methods


    /**
     * Returns a ServletOutputStream suitable for writing binary data in the
     * response.  Either this method or getWriter() may be called to write the
     * body, not both.
     */
    public ServletOutputStream getOutputStream() throws IOException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getOutputStream"));
        } 

		if (this.byteArrayOutputStream == null)
        {
            this.byteArrayOutputStream = new ByteArrayOutputStream();
        }

        ServletOutputStream servletOutputStream = new ServletOutputStream()
        {
            public void write(int b)
            {
                byteArrayOutputStream.write(b);
            }
        };

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getOutputStream"));
        } 
        
        return servletOutputStream;
    }



    /**
     * Returns a PrintWriter object that can send character text to the
     * client.  Either this method or getOutputStream() may be called to write the
     * body, not both.
     */
    public PrintWriter getWriter()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getWriter"));
        } 

		if (this.writer == null)
        {
            this.stringWriter = new StringWriter();
            this.writer = new PrintWriter(this.stringWriter);
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getWriter"));
        }         
        return this.writer;
    }


    /**
     * Due to some weirdness in WSRP4J/Pluto that we don't quite understand
     * it is important that any calls to sendRedirect get swallowed.  The
     * StoredResponse class that we are replacing does this and testing has
     * shown that it is important that we do it also.
     */
    public void sendRedirect(String s) 
    {
        try
        {
            location = Utility.decode(s, this.getCharacterEncoding()); //TODO test for effects of overriden getCharacterEncoding method
        }
        catch (UnsupportedEncodingException e)
        {
            log.error("could not decode redirect url", e);
        }
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("sendRedirect"));
            log.debug(Utility.strExit("sendRedirect"));
        } 
    }


    /**
     * Returns the output buffer content as String.  When using outputStream,
     * the character encoding is always UTF-8.
     * 
     * @return java.lang.String
     */
    public String getOutputBufferAsString() throws IOException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getOutputBufferAsString"));
        } 

		String output = "";

        if (this.byteArrayOutputStream != null)
        {
            output = this.byteArrayOutputStream.toString(getCharacterEncoding());
        }
        else if (this.stringWriter != null)
        {
            output = this.stringWriter.getBuffer().toString();
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getOutputBufferAsString"));
        }
        
        return output;
    }

    // overridden to ensure proper character encoding as UTF-8
    public String getCharacterEncoding() {
        if (characterEncoding == null)
            characterEncoding = "UTF-8";

        return characterEncoding;
    }

    // overridden to provide a method copied from the Tomcat implementation.
    // the content type string passed in is parsed to retrieve the value
    // of the charset attribute.  Unfortunately, this argument never HAS a
    // charset value, as Pluto strips it off in its RenderResponseImpl
    // implementation of this method which is called prior in the stack to this
    // wrapper's implementation.
    public void setContentType(String type) {

        int semicolonIndex = -1;

        if (type == null) {
            this.contentType = null;
            return;
        }

        boolean hasCharset = false;
        int len = type.length();
        int index = type.indexOf(';');
        while (index != -1) {
            semicolonIndex = index;
            index++;
            while (index < len && Character.isWhitespace(type.charAt(index))) {
                index++;
            }
            if (index+8 < len
                    && type.charAt(index) == 'c'
                    && type.charAt(index+1) == 'h'
                    && type.charAt(index+2) == 'a'
                    && type.charAt(index+3) == 'r'
                    && type.charAt(index+4) == 's'
                    && type.charAt(index+5) == 'e'
                    && type.charAt(index+6) == 't'
                    && type.charAt(index+7) == '=') {
                hasCharset = true;
                break;
            }
            index = type.indexOf(';', index);
        }

        if (!hasCharset) {
            this.contentType = type;
            return;
        }

        this.contentType = type.substring(0, semicolonIndex);
        String tail = type.substring(index+8);
        int nextParam = tail.indexOf(';');
        String charsetValue = null;
        if (nextParam != -1) {
            this.contentType += tail.substring(nextParam);
            charsetValue = tail.substring(0, nextParam);
        } else {
            charsetValue = tail;
        }

        // The charset value may be quoted, but must not contain any quotes.
        if (charsetValue != null && charsetValue.length() > 0) {
            charsetSet=true;
            charsetValue = charsetValue.replace('"', ' ');
            this.characterEncoding = charsetValue.trim();
        }
    }

    // method is apparently never called, but ought to provide a
    // content type string that includes the charset of the response.
    public String getContentType() {

        String ret = contentType;

        if (ret != null
            && characterEncoding != null
            && charsetSet) {
            ret = ret + ";charset=" + characterEncoding;
        }

        return ret;
    }
}
