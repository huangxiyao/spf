package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import javax.portlet.PortletMode;
import javax.portlet.WindowState;

import org.apache.pluto.services.information.PortletActionProvider;


/**
 * <p>
 * This class is being provided as a substitute for the WSRP4J-provided
 * PortletActionProviderImpl.  The constructor for PortletActionProviderImpl
 * takes a reference to the WSRP4J-provided DynamicInformationProviderImpl.
 * However, since we are implementing our own WSRPDynamicInformationProvider
 * we are unable to construct an instance of PortletActionProviderImpl.
 * </p>
 * 
 * <p>
 * The solution was to implement this class with a constructor that takes a
 * reference to a WPADynamicInformationProviderImpl (our implementation of the
 * WSRPDynamicInformationProvider interface).  The implementation of this class
 * is pretty simplistic, so there isn't much more to say.
 * </p>
 * 
 * <p>
 * This class is directly instantiated by the getPortletActionProvider method
 * of the WPADynamicInformationProviderImpl class.
 * </p>
 */
public class WPAPortletActionProviderImpl implements PortletActionProvider
{

	// ------------------------------------------------------ Protected Members   
    

    // The dynamic information provider we were instantiated with
    protected WPADynamicInformationProviderImpl dynamicInfoProvider;


    
    // ----------------------------------------------------------- Constructors
    
    
    public WPAPortletActionProviderImpl(
            WPADynamicInformationProviderImpl dynInfoProvider)
    {
        this.dynamicInfoProvider = dynInfoProvider;
    }


	// --------------------------------------------------------- Public Methods 
    
    
    /**
     * Change the portlet mode by invoking the changePortletMode() method on 
     * the dynamic information provider.
     */
    public void changePortletMode(PortletMode mode)
    {
        this.dynamicInfoProvider.changePortletMode(mode);
    }


    /**
     * Change the window state by invoking the changePortletWindowState() 
     * method on the dynamic information provider.
     */
    public void changePortletWindowState(WindowState state)
    {
        this.dynamicInfoProvider.changePortletWindowState(state);
    }

}
