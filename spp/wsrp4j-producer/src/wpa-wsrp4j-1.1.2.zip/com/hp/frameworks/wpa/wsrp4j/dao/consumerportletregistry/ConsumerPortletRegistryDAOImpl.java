package com.hp.frameworks.wpa.wsrp4j.dao.consumerportletregistry;

import com.hp.frameworks.wpa.wsrp4j.dao.BaseDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.util.Utility;


public class ConsumerPortletRegistryDAOImpl extends BaseDAO implements ConsumerPortletRegistryDAO
{
    
	// ------------------------------------------------------ Private Constants    
    
    
    private static final String SQL_SELECT_CONSUMER_PORTLET =
        "SELECT portlet_handle from WSRP_CONSUMER_PORTLET WHERE consumer_handle = ?";
    
    private static final String SQL_INSERT_CONSUMER_PORTLET = 
        "INSERT INTO WSRP_CONSUMER_PORTLET (consumer_handle, portlet_handle) values (?, ?)";

    private static final String SQL_DELETE_CONSUMER_PORTLET = 
        "DELETE FROM WSRP_CONSUMER_PORTLET WHERE consumer_handle = ? AND portlet_handle = ?";

	private static final String SQL_DELETE_ALL_CONSUMER_PORTLETS =
		"DELETE FROM WSRP_CONSUMER_PORTLET WHERE consumer_handle = ?";

    
    // -------------------------------------------------------- Private Members
    
    
    private static final Log log = 
        LogFactory.getLog(ConsumerPortletRegistryDAOImpl.class);
    
    
	// --------------------------------------------------------- Public Methods 
    
    
	public List loadRegistrations(String regHandle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("loadRegistrations"));
        }        
        
        Connection conn = null;
        List portletHandles = new ArrayList();
        
        try
        {
            conn = this.getConnection();
            portletHandles = this.selectConsumerPortlet(conn, regHandle);
        }
        catch (SQLException e)
        {
            log.error("Error loading registrations for consumer " + regHandle,
                    e);
        }
        finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException ex)
            {
            }
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("loadRegistrations"));
        }   
        
        return portletHandles;
    }
    
    
    public void saveRegistration(String regHandle, String portletHandle)
    {        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("saveRegistration"));
        }   
        
        Connection conn = null;
        try
        {
            conn = this.getConnection();
            this.insertConsumerPortlet(conn, regHandle, portletHandle);
        }
        catch (SQLException e)
        {
            log.error("Error saving registration for consumer " + regHandle
                    + " and " + portletHandle, e);
        }
        finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException ex)
            {
            }
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("saveRegistration"));
        }        
    }
    
    
    public void deleteRegistration(String regHandle, String portletHandle)
    {        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("deleteRegistration"));
        } 
        
        Connection conn = null;
        try
        {
            conn = this.getConnection();
            this.deleteConsumerPortlet(conn, regHandle, portletHandle);
        }
        catch (SQLException e)
        {
            log.error("Error deleting registration for consumer " + regHandle
                    + " and " + portletHandle, e);
        }
        finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException ex)
            {
            }
        }          
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("deleteRegistration"));
        }       
    }


    public void deleteRegistrations(String regHandle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("deleteRegistrations"));
        } 
        
        Connection conn = null;
        
		try
		{
			conn = this.getConnection();
			this.deleteConsumerPortlets(conn, regHandle);
		}
		catch (SQLException e)
		{
            log.error("Error deleting registrations for consumer " + regHandle,
                    e);
		}
		finally
		{
			try
			{
				conn.close();
			}
			catch (SQLException ex)
			{
			}
		}
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("deleteRegistrations"));
        }         
	}

    
	// ------------------------------------------------------ Protected Methods    
    
    
	protected void deleteConsumerPortlets(Connection conn, String regHandle)
            throws SQLException
    {
        PreparedStatement stmt = 
            conn.prepareStatement(SQL_DELETE_ALL_CONSUMER_PORTLETS);

        try
        {
            stmt.setString(1, regHandle);
            stmt.executeUpdate();
        }
        finally
        {
            stmt.close();
        }
    }


	protected List selectConsumerPortlet(Connection conn, String regHandle)
            throws SQLException
    {
        List portletHandles = new ArrayList();

        PreparedStatement stmt = 
            conn.prepareStatement(SQL_SELECT_CONSUMER_PORTLET);
        ResultSet rs = null;

        try
        {
            stmt.setString(1, regHandle);
            rs = stmt.executeQuery();

            while (rs.next())
            {
                portletHandles.add(rs.getString("portlet_handle"));
            }
        }
        finally
        {
            if (rs != null)
            {
                rs.close();
            }
            
            stmt.close();
        }

        return portletHandles;
    }


    protected void insertConsumerPortlet(Connection conn, String regHandle,
            String portletHandle) throws SQLException
    {
        PreparedStatement stmt = 
            conn.prepareStatement(SQL_INSERT_CONSUMER_PORTLET);

        try
        {
            stmt.setString(1, regHandle);
            stmt.setString(2, portletHandle);
            stmt.executeUpdate();
        }
        finally
        {
            stmt.close();
        }
    }


    protected void deleteConsumerPortlet(Connection conn, String regHandle,
            String portletHandle) throws SQLException
    {
        PreparedStatement stmt = 
            conn.prepareStatement(SQL_DELETE_CONSUMER_PORTLET);

        try
        {
            stmt.setString(1, regHandle);
            stmt.setString(2, portletHandle);
            stmt.executeUpdate();
        }
        finally
        {
            stmt.close();
        }
    }
}
