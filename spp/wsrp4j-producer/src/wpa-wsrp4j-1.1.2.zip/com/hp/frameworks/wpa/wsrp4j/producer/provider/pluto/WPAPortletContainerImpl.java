package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto;

import java.io.IOException;
import java.util.Map;

import javax.portlet.PortletMode;
import javax.portlet.WindowState;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.pluto.PortletContainerImpl;
import org.apache.pluto.core.InternalActionResponse;
import org.apache.pluto.om.window.PortletWindow;
import org.apache.pluto.services.information.DynamicInformationProvider;
import org.apache.pluto.services.information.InformationProviderAccess;
import org.apache.pluto.services.information.PortletURLProvider;


/**
 * <p>
 * This class extends the PortletContainerImpl class that is provided by Pluto.
 * This class is necessary to compensate for some changes that were made to the
 * PortletInvoker to support WebLogic. The only method that we are overriding is
 * the redirect() method.
 * </p>
 * 
 * <p>
 * Originally, WSRP4J was instantiating a StoredResponse and using that to
 * buffer the portlet output. However, it was discovered that WebLogic was
 * looking specifically for its ServletResponse implementation so we had to
 * replace the StoredResponse with a custom ServletResponseWrapper
 * (WPAServletResponseWrapperImpl). This keeps WebLogic happy, but ends-up
 * breaking WSRP4J because Pluto has some code (in the redirect() method below)
 * that unwraps the response and calls the sendRedirect() method. Unfortunately,
 * calling sendRedirect() on the underlying WebLogic response screws-up all of
 * the WSRP4J processing.
 * </p>
 * 
 * <p>
 * The solution was to simply override the redirect() method and ensure that the
 * response is not unwrapped before sendRedirect() method is called. The
 * implementation below is a cut-n-paste from the Pluto implementation -- the
 * only change is some code that has been commented out (see the area delimited
 * by the "WPA-ALTERED CODE" comment).
 * 
 * <p>
 * This class will continue to be necessary as long as we are wrapping the
 * original response object and passing it to the portlets.
 * </p>
 * 
 * <p>
 * This class needs to be registered in the
 * /WEB-INF/config/services/ConfigServices.properties file under the following
 * key: portletcontainer.entrance.impl
 * </p>
 */
public class WPAPortletContainerImpl extends PortletContainerImpl
{

    protected void redirect(String location, PortletWindow portletWindow,
            HttpServletRequest servletRequest,
            HttpServletResponse servletResponse,
            InternalActionResponse _actionResponse) throws IOException
    {
        if (location == null && _actionResponse != null)
        {
            DynamicInformationProvider provider = InformationProviderAccess
                    .getDynamicProvider(servletRequest);

            // TODO: don't send changes in case of exception -> PORTLET:SPEC:17

            PortletMode portletMode = provider.getPortletMode(portletWindow);
            WindowState windowState = provider.getWindowState(portletWindow);

            // get the changings of this portlet entity that might be set during
            // action handling
            // change portlet mode
            if (_actionResponse.getChangedPortletMode() != null)
            {
                portletMode = _actionResponse.getChangedPortletMode();
                InformationProviderAccess.getDynamicProvider(servletRequest)
                        .getPortletActionProvider(portletWindow)
                        .changePortletMode(portletMode);
            }
            // change window state
            if (_actionResponse.getChangedWindowState() != null)
            {
                windowState = _actionResponse.getChangedWindowState();
                InformationProviderAccess.getDynamicProvider(servletRequest)
                        .getPortletActionProvider(portletWindow)
                        .changePortletWindowState(windowState);
            }
            // get render parameters
            Map renderParameter = _actionResponse.getRenderParameters();

            PortletURLProvider redirectURL = provider
                    .getPortletURLProvider(portletWindow);

            if (provider.getPortletMode(portletWindow) != null)
            {
                redirectURL.setPortletMode(portletMode);
            }
            if (provider.getWindowState(portletWindow) != null)
            {
                redirectURL.setWindowState(windowState);
            }
            if (servletRequest.isSecure())
            {
                redirectURL.setSecure(); // TBD
            }
            redirectURL.clearParameters();
            redirectURL.setParameters(renderParameter);

            location = servletResponse
                    .encodeRedirectURL(redirectURL.toString());
        }

        javax.servlet.http.HttpServletResponse redirectResponse = servletResponse;

        // BEGIN WPA-ALTERED CODE
        // while (redirectResponse instanceof
        // javax.servlet.http.HttpServletResponseWrapper)
        // {
        // redirectResponse = (javax.servlet.http.HttpServletResponse)
        // ((javax.servlet.http.HttpServletResponseWrapper) redirectResponse)
        // .getResponse();
        // }
        // END WPA-ALTERED CODE

        redirectResponse.sendRedirect(location);
    }

}
