package com.hp.frameworks.wpa.wsrp4j.dao.portletentityregistry;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.util.Utility;

import com.hp.frameworks.wpa.wsrp4j.dao.BaseDAO;
import com.hp.frameworks.wpa.wsrp4j.om.common.impl.WPAPreferenceImpl;
import com.hp.frameworks.wpa.wsrp4j.om.common.impl.WPAPreferenceSetImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletApplicationEntityImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletApplicationEntityListImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletEntityImpl;


public class PortletRegistryDAOImpl extends BaseDAO implements
        PortletRegistryDAO
{
    
	// ------------------------------------------------------ Private Constants   
    
    
    private static final String SQL_SELECT_APPLICATIONS = 
        "SELECT * FROM WSRP_APPLICATION";

    private static final String SQL_SELECT_APPLICATIONS_BY_DEFINITION_ID = 
        "SELECT * FROM WSRP_APPLICATION WHERE definition_id IN ({0})";
    
    private static final String SQL_SELECT_PORTLETS = 
        "SELECT * FROM WSRP_PORTLET WHERE application = ?";

    private static final String SQL_SELECT_PREFERENCES = 
        "SELECT * FROM WSRP_PREFERENCE WHERE portlet = ?";

    private static final String SQL_SELECT_PREFERENCE_VALUES = 
        "SELECT * FROM WSRP_PREFERENCE_VALUE WHERE preference = ? ORDER BY preference_idx";
    
    private static final String SQL_INSERT_APPLICATION =
        "INSERT INTO WSRP_APPLICATION (id, definition_id) VALUES (?, ?)";
        
    private static final String SQL_INSERT_PORTLET =
        "INSERT INTO WSRP_PORTLET (id, portlet_id, definition_id, application, parent_handle) VALUES (?, ?, ?, ?, ?)";
        
    private static final String SQL_INSERT_PREFERENCE =
        "INSERT INTO WSRP_PREFERENCE (id, name, read_only, portlet) VALUES (?, ?, ?, ?)";

    private static final String SQL_INSERT_PREFERENCE_VALUE =
        "INSERT INTO WSRP_PREFERENCE_VALUE (value, preference, preference_idx) VALUES (?, ?, ?)";

    private static final String SQL_DELETE_PORTLET =
        "DELETE FROM WSRP_PORTLET WHERE id = ?";
    
    private static final String SQL_DELETE_PREFERENCES =
        "DELETE FROM WSRP_PREFERENCE WHERE portlet = ?";
    
    private static final String SQL_DELETE_PREFERENCE_VALUES =
        "DELETE FROM WSRP_PREFERENCE_VALUE WHERE preference = ?";
      
    private static final String SQL_DELETE_ALL_APPLICATIONS =
        "DELETE FROM WSRP_APPLICATION";
    
    private static final String SQL_DELETE_ALL_PORTLETS = 
        "DELETE FROM WSRP_PORTLET";

    private static final String SQL_DELETE_ALL_PREFERENCES = 
        "DELETE FROM WSRP_PREFERENCE";

    private static final String SQL_DELETE_ALL_PREFERENCE_VALUES = 
        "DELETE FROM WSRP_PREFERENCE_VALUE";


    
    // -------------------------------------------------------- Private Members
    
    
    private static final Log log = 
        LogFactory.getLog(PortletRegistryDAOImpl.class); 

    
	// --------------------------------------------------------- Public Methods    
    
    
	public WPAPortletApplicationEntityListImpl loadPortletRegistry()
	{
	    return this.loadPortletRegistry(null);
	}
    

    public WPAPortletApplicationEntityListImpl loadPortletRegistry(String[] definitionIds)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("loadPortletRegistry"));
        } 
        
        Connection conn = null;
        
        WPAPortletApplicationEntityListImpl portletApps =
            new WPAPortletApplicationEntityListImpl();

        try
        {
            conn = this.getConnection();
            
            this.loadPortletApplicationEntityList(conn, portletApps, definitionIds);
        }
        catch (SQLException e)
        {
            log.error("Error loading portlet registry", e);
        }
        finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException ex) { }
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("loadPortletRegistry"));
        } 
        
        return portletApps;
    }


    public void savePortletRegistry(WPAPortletApplicationEntityListImpl portletApps)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("savePortletRegistry"));
        } 
        
        Connection conn = null;
        
        try
        {
            conn = this.getConnection();
            conn.setAutoCommit(false);
            
            this.deletePortletRegistry(conn);
            this.savePortletApplicationEntityList(conn, portletApps);
            
            conn.commit();
        }
        catch (SQLException e)
        {
            log.error("Error saving portlet registry", e);
            
            try
            {
                conn.rollback();
            }
            catch (SQLException ex) { }
        }
        finally
        {
            try
            {
                conn.close();       
            }
            catch (SQLException ex) { }            
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("savePortletRegistry"));
        }  
    }
    
    
    public void savePortletEntity(WPAPortletEntityImpl portlet) 
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("savePortletEntity"));
        } 
        
        Connection conn = null;                

        try
        {
            conn = this.getConnection();
            conn.setAutoCommit(false);

            String portletRegistryId = portlet.getRegistryId();
            
            if (portletRegistryId == null)
            {
                this.insertPortletEntity(conn, portlet);
            }
            else
            {
                this.updatePortletEntity(conn, portlet);
            }
            
            conn.commit();
        }
        catch (SQLException e)
        {
            log.error("Error saving portlet entity " + portlet.getId(), e);
            
            try
            {
                conn.rollback();
            }
            catch (SQLException ex) { }
        }
        finally
        {
            try
            {
                conn.close();       
            }
            catch (SQLException ex) { }            
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("savePortletEntity"));
        } 
    }

    
	public void deletePortletEntity(WPAPortletEntityImpl portlet)
	{
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("deletePortletEntity"));
        } 
        
        Connection conn = null;
        
		try
		{
            conn = this.getConnection();     
            conn.setAutoCommit(false);
            
            this.deletePortletEntity(conn, portlet);
            
            conn.commit();
		}
		catch (SQLException e)
		{
            log.error("Error deleting portlet entity " + portlet.getId(), e);
            
            try
            {
                conn.rollback();
            }
            catch (SQLException ex) { }
		}
		finally
		{
			try
			{
				conn.close();
			}
			catch (SQLException ex) { }
		}
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("deletePortletEntity"));
        } 
	}


	// ------------------------------------------------------ Protected Methods
    
    
	protected void loadPortletApplicationEntityList(Connection conn,
            WPAPortletApplicationEntityListImpl portletApps,
            String[] definitionIds) throws SQLException
    {
        Statement stmt = conn.createStatement();
        ResultSet rs = null;

        try
        {
            if (definitionIds == null || definitionIds.length == 0)
            {
                rs = stmt.executeQuery(SQL_SELECT_APPLICATIONS);
            }
            else
            {
                String definitionIdList = this
                        .getStringFromArray(definitionIds);

                String sql = MessageFormat.format(
                        SQL_SELECT_APPLICATIONS_BY_DEFINITION_ID,
                        new Object[] { definitionIdList });

                rs = stmt.executeQuery(sql);
            }

            while (rs.next())
            {
                WPAPortletApplicationEntityImpl portletApp = new WPAPortletApplicationEntityImpl();
                portletApps.add(portletApp);

                portletApp.setId(rs.getString("id"));
                portletApp.setDefinitionId(rs.getString("definition_id"));

                this.loadPortletEntityList(conn, portletApp);
            }
        }
        finally
        {
            if (rs != null)
            {
                rs.close();
            }

            stmt.close();
        }
    }
    
    
    protected void loadPortletEntityList(Connection conn,
            WPAPortletApplicationEntityImpl portletApp) throws SQLException
    {
        String appId = portletApp.getId().toString();

        PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_PORTLETS);
        ResultSet rs = null;

        try
        {
            stmt.setString(1, appId);
            rs = stmt.executeQuery();

            while (rs.next())
            {
                WPAPortletEntityImpl portlet = new WPAPortletEntityImpl();
                portletApp.addPortletEntity(portlet);

                portlet.setId(rs.getString("portlet_id"));
                portlet.setDefinitionId(rs.getString("definition_id"));
                portlet.setPortletApplicationEntity(portletApp);
                portlet.setRegistryId(rs.getString("id"));
                portlet.setParentHandle(rs.getString("parent_handle"));
                this.loadPreferenceSet(conn, portlet);
            }
        }
        finally
        {
            if (rs != null)
            {
                rs.close();
            }

            stmt.close();
        }
    }
    
    
    protected void loadPreferenceSet(Connection conn,
            WPAPortletEntityImpl portlet) throws SQLException
    {
        PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_PREFERENCES);
        ResultSet rs = null;

        try
        {
            stmt.setString(1, portlet.getRegistryId());
            rs = stmt.executeQuery();

            while (rs.next())
            {
                WPAPreferenceImpl preference = new WPAPreferenceImpl();
                ((WPAPreferenceSetImpl) portlet.getPreferenceSet())
                        .add(preference);

                preference.setName(rs.getString("name"));
                preference.setReadOnly(rs.getString("read_only"));
                preference.setRegistryId(rs.getString("id"));

                this.loadPreferenceValues(conn, preference);
            }

            // Create a backup copy of the newly loaded preferences so that
            // we can easily do a rollback in the event that the reset()
            // method is called at some point. This is the only context
            // in which this method should ever be called.
            portlet.backupPreferences();
        }
        finally
        {
            if (rs != null)
            {
                rs.close();
            }

            stmt.close();
        }
    }
    
    
    protected void loadPreferenceValues(Connection conn,
            WPAPreferenceImpl preference) throws SQLException
    {
        PreparedStatement stmt = conn
                .prepareStatement(SQL_SELECT_PREFERENCE_VALUES);
        ResultSet rs = null;

        try
        {
            stmt.setString(1, preference.getRegistryId());
            rs = stmt.executeQuery();

            ArrayList values = new ArrayList();

            while (rs.next())
            {
                values.add(rs.getString("value"));
            }

            preference.setValues(values);
        }
        finally
        {
            if (rs != null)
            {
                rs.close();
            }

            stmt.close();
        }
    }
    
    
    protected void savePortletApplicationEntityList(
            Connection conn,
            WPAPortletApplicationEntityListImpl portletApps)
            throws SQLException
    {
        Iterator i = portletApps.iterator();
        
        while (i.hasNext())
        {
            WPAPortletApplicationEntityImpl portletApp = 
                (WPAPortletApplicationEntityImpl) i.next();
            
            this.insertPortletApplicationEntity(conn, portletApp);
        }
    }
    
       
    protected void insertPortletApplicationEntity(Connection conn,
            WPAPortletApplicationEntityImpl portletApp) throws SQLException
    {
        PreparedStatement stmt = conn.prepareStatement(SQL_INSERT_APPLICATION);

        try
        {
            stmt.setString(1, portletApp.getId().toString());
            stmt.setString(2, portletApp.getDefinitionId());
            stmt.executeUpdate();

            this.savePortletEntityList(conn, portletApp);
        }
        finally
        {
            stmt.close();
        }
    }
    
      
    protected void savePortletEntityList(
            Connection conn,
            WPAPortletApplicationEntityImpl portletApp)
            throws SQLException
    {
        Iterator i = portletApp.getPortletEntityList().iterator();
        
        while (i.hasNext())
        {
            WPAPortletEntityImpl portlet = (WPAPortletEntityImpl) i.next();
            this.insertPortletEntity(conn, portlet);            
        }
    }
    
    
    protected void insertPortletEntity(Connection conn,
            WPAPortletEntityImpl portlet) throws SQLException
    {
        String id = portlet.getRawId();
        String definitionId = portlet.getDefinitionId();
        String appId = ((WPAPortletApplicationEntityImpl) portlet
                .getPortletApplicationEntity()).getId().toString();
        String parentHandle = portlet.getParentHandle();
        String registryId = appId + "." + id;

        PreparedStatement stmt = conn.prepareStatement(SQL_INSERT_PORTLET);

        try
        {
            stmt.setString(1, registryId);
            stmt.setString(2, id);
            stmt.setString(3, definitionId);
            stmt.setString(4, appId);
            stmt.setString(5, parentHandle);
            stmt.executeUpdate();

            portlet.setRegistryId(registryId);

            this.savePreferenceSet(conn, portlet);
        }
        finally
        {
            stmt.close();
        }
    }
    
    
    protected void updatePortletEntity(Connection conn,
            WPAPortletEntityImpl portlet) throws SQLException
    {            
        this.savePreferenceSet(conn, portlet);
    }
    
    
    protected void savePreferenceSet(Connection conn,
            WPAPortletEntityImpl portlet) throws SQLException
    {        
        // Be sure to delete any existing preferences and preference 
        // values. We need to do this so that we appropriately handle 
        // deletions to the preference set.
        this.deletePreferences(conn, portlet);
        
        Iterator i = portlet.getPreferenceSet().iterator();
        
        // Iterator over preferences
        while (i.hasNext())
        {
            WPAPreferenceImpl pref = (WPAPreferenceImpl) i.next();
                                                
            this.insertPreference(conn, pref, portlet.getRegistryId());
        }    
    }
    
        
    protected void insertPreference(Connection conn,
            WPAPreferenceImpl preference, String portletRegistryId)
            throws SQLException
    {
        String id = portletRegistryId + "." + preference.getName();
        String name = preference.getName();
        String readOnly = Boolean.valueOf(preference.isReadOnly()).toString();

        PreparedStatement stmt = conn.prepareStatement(SQL_INSERT_PREFERENCE);

        try
        {
            stmt.setString(1, id);
            stmt.setString(2, name);
            stmt.setString(3, readOnly);
            stmt.setString(4, portletRegistryId);
            stmt.executeUpdate();

            preference.setRegistryId(id);

            this.insertPreferenceValues(conn, preference);
        }
        finally
        {
            stmt.close();
        }
    }       
    
    
    protected void insertPreferenceValues(Connection conn,
            WPAPreferenceImpl preference) throws SQLException
    {
        String preferenceRegistryId = preference.getRegistryId();
        PreparedStatement stmt = conn
                .prepareStatement(SQL_INSERT_PREFERENCE_VALUE);

        try
        {
            int index = 0;

            Iterator i = preference.getValues();

            while (i.hasNext())
            {
                String value = (String) i.next();

                stmt.setString(1, value);
                stmt.setString(2, preferenceRegistryId);
                stmt.setString(3, String.valueOf(index++));
                stmt.executeUpdate();
            }
        }
        finally
        {
            stmt.close();
        }
    }
    
    
    protected void deletePortletRegistry(Connection conn) throws SQLException
    {
        this.deleteAllPreferenceValues(conn);
        this.deleteAllPreferences(conn);
        this.deleteAllPortlets(conn);
        this.deleteAllApplications(conn);
    }


    protected void deleteAllApplications(Connection conn) throws SQLException
    {
        Statement stmt = conn.createStatement();

        try
        {
            stmt.executeUpdate(SQL_DELETE_ALL_APPLICATIONS);
        }
        finally
        {
            stmt.close();
        }
    }

    
    protected void deleteAllPortlets(Connection conn) throws SQLException
    {
        Statement stmt = conn.createStatement();
        
        try
        {
            stmt.executeUpdate(SQL_DELETE_ALL_PORTLETS);
        }
        finally
        {
            stmt.close();
        }
    }
    
    
    protected void deleteAllPreferences(Connection conn) throws SQLException
    {
        Statement stmt = conn.createStatement();

        try
        {
            stmt.executeUpdate(SQL_DELETE_ALL_PREFERENCES);
        }
        finally
        {
            stmt.close();
        }
    }


    protected void deleteAllPreferenceValues(Connection conn)
            throws SQLException
    {
        Statement stmt = conn.createStatement();

        try
        {
            stmt.executeUpdate(SQL_DELETE_ALL_PREFERENCE_VALUES);
        }
        finally
        {
            stmt.close();
        }
    }
    
    
    protected void deletePortletEntity(Connection conn,
            WPAPortletEntityImpl portlet) throws SQLException
    {
        this.deletePreferences(conn, portlet);

        // Delete portlet
        PreparedStatement stmt = conn.prepareStatement(SQL_DELETE_PORTLET);

        try
        {
            stmt.setString(1, portlet.getRegistryId());
            stmt.executeUpdate();
        }
        finally
        {
            stmt.close();
        }
    }
    
    
    protected void deletePreferences(Connection conn,
            WPAPortletEntityImpl portlet) throws SQLException
    {
        WPAPreferenceSetImpl preferences = (WPAPreferenceSetImpl) portlet
                .getPreferenceSet();

        // Delete associated preferences and their values (a.k.a. cascade
        // delete)
        if (!preferences.isEmpty())
        {
            Iterator iter = preferences.iterator();

            while (iter.hasNext())
            {
                WPAPreferenceImpl preference = (WPAPreferenceImpl) iter.next();

                this.deletePreferenceValues(conn, preference);
            }

            // Delete preferences
            PreparedStatement stmt = conn
                    .prepareStatement(SQL_DELETE_PREFERENCES);

            try
            {
                stmt.setString(1, portlet.getRegistryId());
                stmt.executeUpdate();
            }
            finally
            {
                stmt.close();
            }
        }
    }
    
    
    protected void deletePreferenceValues(Connection conn,
            WPAPreferenceImpl preference) throws SQLException
    {
        PreparedStatement stmt = conn
                .prepareStatement(SQL_DELETE_PREFERENCE_VALUES);

        try
        {
            stmt.setString(1, preference.getRegistryId());
            stmt.executeUpdate();
        }
        finally
        {
            stmt.close();
        }
    }
    
    
	// -------------------------------------------------------- Private Methods
    
    
    /**
     * Takes an array of strings and formats it as a single string in the form
     * of: 'string1', 'string2', 'string3'. This method is used when we need to
     * take a list of strings and pass it into the "WHERE x IN (list)" clause of
     * a SQL statement.
     */
    private String getStringFromArray(String[] items)
    {
        StringBuffer buffer = new StringBuffer();
        
        // Iterate over all items in array
        for (int i = 0; i < items.length; i++)
        {
            // Separate each item with a comma
            if (i > 0)
            {
                buffer.append(",");
            }
            
            // Quote each string
            buffer.append("'");
            buffer.append(items[i]);
            buffer.append("'");
        }        
        
        return buffer.toString();
    }
}
