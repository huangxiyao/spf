package com.hp.frameworks.wpa.wsrp4j.om.entity.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pluto.om.common.ObjectID;
import org.apache.pluto.om.entity.PortletApplicationEntity;
import org.apache.pluto.om.entity.PortletApplicationEntityList;
import org.apache.pluto.om.entity.PortletEntity;
import org.apache.wsrp4j.commons.util.Utility;


public class WPAPortletApplicationEntityListImpl extends HashSet implements
        PortletApplicationEntityList, Serializable
{
   
    // -------------------------------------------------------- Private Members
    
   
    private static final Log log = 
        LogFactory.getLog(WPAPortletApplicationEntityListImpl.class);   
    
    
	// ------------------------------------------------------ Protected Members
    
    
    // Cache used to store all of the portlets in the app entity list.
    // Instead of iterating through the collections each time, this allows us
    // to do a quick look-up of a portlet in map
    protected Map portletEntityCache = new HashMap();
    
    
	// --------------------------------------------------------- Public Methods    
    
    
    /**
     * Retrieve the portlet application associated with the given object ID.
     */
    public PortletApplicationEntity get(ObjectID objectId)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("get"));
        } 
        
        PortletApplicationEntity result = null;
        
        Iterator i = this.iterator();
        
        while (i.hasNext())
        {
            PortletApplicationEntity portletApp = 
                (PortletApplicationEntity) i.next();
            
            if (portletApp.getId().equals(objectId))
            {
                result = portletApp;
                break;
            }
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("get"));
        } 
        
        return result;
    }
    
       
    public String toString()
    {
        StringBuffer buffer = new StringBuffer();
        
        buffer.append(this.getClass().toString());
        buffer.append("{\n");
        
        Iterator i = this.iterator();
        
        while (i.hasNext())
        {
            buffer.append(i.next().toString());
            buffer.append("\n");
        }
        
        buffer.append("}\n");
        
        return buffer.toString();
    }

    
    /**
     * Returns an iterator for all portlet entities in all portlet
     * applications contained in this list.
     */
    public Iterator getAllPortletEntities()
    {        
        return this.getPortletEntityCache().values().iterator();
    }
    
    
    /**
     * Searches all portlet applications contained in this list
     * for a portlet entity matching the given object ID.
     */
    public PortletEntity getPortletEntity(ObjectID objectId)
    {
        return this.getPortletEntity(objectId.toString());
    }
    
    
    /**
     * Searches all portlet applications contained in this list
     * for a portlet entity matching the given handle.
     */    
    public PortletEntity getPortletEntity(String handle)
    {
        Map cache = this.getPortletEntityCache();
        
        return (PortletEntity) cache.get(handle);
    }
    
    
	// ------------------------------------------------------ Protected Members
    
    
    /**
     * Returns the map used to cache all of the portlet entities associated
     * with this producer.  If the cache hasn't yet been populated, the
     * populatePortletEntityCache() method is called before the value is
     * returned.
     */
    protected Map getPortletEntityCache()
    {
        if (this.portletEntityCache.isEmpty())
        {
            synchronized (this)
            {
                if (this.portletEntityCache.isEmpty())
                {
                    this.populatePortletEntityCache();
                }
            }
        }
        
        return this.portletEntityCache;
    }
    
    
    /**
     * Populates the portlet entity cache by iterating through all of the
     * applications and storing each of the portlet entities in the cache
     * map.
     */
    protected void populatePortletEntityCache()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("populatePortletEntityCache"));
        } 
        
        Iterator i = this.iterator();

        // Iterate through all the applications
        while (i.hasNext())
        {
            PortletApplicationEntity portletApp = (PortletApplicationEntity) i
                    .next();

            Iterator j = portletApp.getPortletEntityList().iterator();

            // Iterate through all the portlets
            while (j.hasNext())
            {
                PortletEntity portlet = (PortletEntity) j.next();
                this.portletEntityCache.put(
                        portlet.getId().toString(), portlet);
            }
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("populatePortletEntityCache"));
        } 
    }
}
