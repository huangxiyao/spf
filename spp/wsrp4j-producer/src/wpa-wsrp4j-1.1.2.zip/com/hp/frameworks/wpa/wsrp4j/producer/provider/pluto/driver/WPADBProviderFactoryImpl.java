package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import org.apache.wsrp4j.commons.producer.provider.interfaces.Provider;
import org.apache.wsrp4j.commons.producer.provider.interfaces.ProviderFactory;

/**
 * <p>
 * This class is solely responsible for instantiating and returning an
 * instance of the WPADBProviderImpl.  For details regarding why we
 * even need a WPADBProviderImpl in the first place, see the comments
 * in that class.
 * </p>
 * 
 * <p>
 * This class must be registered in 
 * the /WEB-INF/classes/WSRPServices.properties file under the
 * following key name: provider.factory
 * </p>
 */
public class WPADBProviderFactoryImpl implements ProviderFactory
{

	// ---------------------------------------------------------- Class Members 
    
    
    private static Provider provider = new WPADBProviderImpl();
    

   	// --------------------------------------------------------- Public Methods
    
    
    /**
     * Returns an instance of the WPADBProviderImpl class.
     */    
    public Provider getProvider()
    {
        return provider;
    }
}
