package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import javax.servlet.http.HttpServletRequest;

import org.apache.pluto.portalImpl.core.InformationProviderServiceFactoryImpl;
import org.apache.pluto.services.information.DynamicInformationProvider;


/**
 * <p>
 * This class is solely responsible for instantiating and returning an instance
 * of the WPADynamicInformationProviderImpl.  For details regarding why we even
 * need a WPADynamicInformationProviderImpl in the first place, see the comments
 * in that class.
 * </p>
 * 
 * <p>
 * This class must be registered in 
 * the /WEB-INF/config/services/FactoryManagerService.properties file under the
 * following key name: 
 * factory.org.apache.pluto.portalImpl.factory.InformationProviderFactory
 * </p>
 */
public class WPAInformationProviderServiceFactoryImpl extends
        InformationProviderServiceFactoryImpl
{
    
	// ------------------------------------------------------ Private Constants
    
    
    // Key name under which the dynamic information provider is stored in 
    // request scope.
    private static final String DYNAMIC_INFORMATION_PROVIDER_KEY = 
        "org.apache.pluto.portalImpl.DynamicInformationProvider";
    
    
	// --------------------------------------------------------- Public Methods  
    
    
    /**
     * Returns the instance of the dynamic information provider.  If the 
     * provider has already been instantiated, it is returned from the
     * appropriate request-scoped attribute; otherwise, it is instantiated and
     * stored in request scope.
     */
    public DynamicInformationProvider getDynamicProvider(HttpServletRequest request)
    {
        DynamicInformationProvider provider = (DynamicInformationProvider) 
            request.getAttribute(DYNAMIC_INFORMATION_PROVIDER_KEY);
    
        if (provider == null)
        {
            provider = new WPADynamicInformationProviderImpl(request);
            request.setAttribute(DYNAMIC_INFORMATION_PROVIDER_KEY, provider);
        }
    
        return provider;
    }
}
