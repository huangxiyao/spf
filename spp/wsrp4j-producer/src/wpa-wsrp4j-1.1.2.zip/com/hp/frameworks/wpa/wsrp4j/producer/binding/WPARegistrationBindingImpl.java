package com.hp.frameworks.wpa.wsrp4j.producer.binding;

import java.rmi.RemoteException;

import oasis.names.tc.wsrp.v1.types.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.exception.WSRPException;
import org.apache.wsrp4j.commons.exception.WSRPXHelper;
import org.apache.wsrp4j.commons.producer.binding.WSRPRegistrationBindingImpl;
import org.apache.wsrp4j.commons.producer.interfaces.ConsumerRegistry;
import org.apache.wsrp4j.commons.producer.interfaces.ConsumerRegistryAccess;
import org.apache.wsrp4j.commons.util.Constants;
import org.apache.wsrp4j.commons.util.ParameterChecker;
import org.apache.wsrp4j.commons.util.Utility;
import com.hp.frameworks.wpa.wsrp4j.producer.driver.WPAWSRPEngine;


/**
 * <p>
 * This class is being provided as a replacement for
 * WSRPRegistrationBindingImpl. The WSRP4J-provided class doesn't properly
 * implement the deregister service so no consumers are ever deregistered. To
 * fix this problem, we are extending the WSRP4J class and overriding the
 * deregister() method with an implementation that actually invokes the
 * deregistration service of the ConsumerRegistry.
 * </p>
 * 
 * <p>
 * The WSRP4J-provided implementation of WSRPRegistrationBindingImpl actually
 * defers all processing to the WSRPEngine class, however, WSRPEngine is not
 * extensible, so we are forced to place our implementation here in the binding
 * impl.  NOTE: as of wpa-wsrp4j-1.1.2 we do provide our own WPAWSRPEngine class.
 * This was necessary to handle redirects from remote portlet actions.  As a
 * result of this, several classes, including this one, were modified to refer
 * directly to the WPAWSRPEngine class rather than WSRPEngine.
 * </p>
 * 
 * <p>
 * If WSRP4J properly implements the deregister service at some point in the
 * future, this class can be safely removed.
 * </p>
 * 
 * <p>
 * This class must be registered in the /WEB-INF/server-config.wsdd
 * configuration file as the implementing class for the WSRPRegistrationService.
 * </p>
 */
public class WPARegistrationBindingImpl extends WSRPRegistrationBindingImpl
{
    // -------------------------------------------------------- Private Members    


    private static final Log log =
        LogFactory.getLog(WPARegistrationBindingImpl.class);


    // --------------------------------------------------------- Public Methods


    /**
     * Our custom implementation of the deregister service.  Checks the 
     * incoming parameters and then invokes the deregister() method on the
     * ConsumerRegistry.
     */
    public ReturnAny deregister(RegistrationContext regContext)
            throws RemoteException, InvalidRegistrationFault,
            OperationFailedFault
    {
        //TODO can this now be moved to our WPAWSRPEngine class?

        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("deregister"));
        }

        // Make sure we've actually got a handle to deregister
        ParameterChecker paramCheck = new ParameterChecker();
        paramCheck.check(regContext, Constants.NILLABLE_FALSE);

        try
        {
            // Retrieve the consumer registry            
            ConsumerRegistry consumerRegistry =
                ConsumerRegistryAccess.getConsumerRegistry();

            // Deregister
            consumerRegistry.deregister(regContext.getRegistrationHandle());
        }
        catch (WSRPException e)
        {
            WSRPXHelper.handleWSRPException(e);
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("deregister"));
        }

        return new ReturnAny();
    }

    public RegistrationContext register(RegistrationData register) throws RemoteException, OperationFailedFault, MissingParametersFault {
        return WPAWSRPEngine.getInstance().register(register);
    }

    public RegistrationState modifyRegistration(ModifyRegistration modifyRegistration) throws RemoteException, InvalidRegistrationFault, OperationFailedFault, MissingParametersFault {
        return WPAWSRPEngine.getInstance().modifyRegistration(modifyRegistration);
    }

}
