package com.hp.frameworks.wpa.wsrp4j.dao.consumerregistry;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oasis.names.tc.wsrp.v1.types.RegistrationContext;
import oasis.names.tc.wsrp.v1.types.RegistrationData;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.producer.driver.RegistrationImpl;
import org.apache.wsrp4j.commons.producer.interfaces.Registration;
import org.apache.wsrp4j.commons.util.Utility;

import com.hp.frameworks.wpa.wsrp4j.dao.BaseDAO;

public class ConsumerRegistryDAOImpl extends BaseDAO implements ConsumerRegistryDAO
{

    // ------------------------------------------------------ Private Constants
    
    
    private static final String SQL_SELECT_CONSUMER =
        "SELECT handle, name, agent, method_get_supported FROM WSRP_CONSUMER WHERE handle = ?";
    
    private static final String SQL_SELECT_ALL_CONSUMERS =
        "SELECT handle, name, agent, method_get_supported FROM WSRP_CONSUMER";
    
    private static final String SQL_INSERT_CONSUMER =
        "INSERT INTO WSRP_CONSUMER (handle, name, agent, method_get_supported) VALUES (?, ?, ?, ?)";

    private static final String SQL_DELETE_CONSUMER =
        "DELETE FROM WSRP_CONSUMER WHERE handle = ?";
    
    
    // -------------------------------------------------------- Private Members
    
    
    private static final Log log = 
        LogFactory.getLog(ConsumerRegistryDAOImpl.class); 
    
    
	// --------------------------------------------------------- Public Methods    
    
    
    public void saveRegistration(Registration registration)
    {        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("saveRegistration"));
        } 
        
        Connection conn = null;
        
        try
        {
            conn = this.getConnection();
            this.insertRegistration(conn, registration);
        }
        catch (SQLException e)
        {
            log.error("Error saving registration", e);
        }
        finally
        {
            try
            {
                conn.close();       
            }
            catch (SQLException ex) { }            
        }           
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("saveRegistration"));
        }       
    }

    
    public Registration loadRegistration(String handle)
    {        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("loadRegistration"));
        } 
        
        Connection conn = null;
        Registration registration = null;
        
        try
        {
            conn = this.getConnection();
            registration = this.selectRegistrationByHandle(conn, handle);
        }
        catch (SQLException e)
        {
            log.error("Error loading registration", e);
        }
        finally
        {
            try
            {
                conn.close();       
            }
            catch (SQLException ex) { }            
        }    
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("loadRegistration"));
        } 
        
        return registration;
    }
    
    
    public List loadAllRegistrations()
    {       
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("loadAllRegistrations"));
        } 
        
        Connection conn = null;
        List registrations = new ArrayList();
        
        try
        {
            conn = this.getConnection();
            registrations = this.selectRegistrations(conn);
        }
        catch (SQLException e)
        {
            log.error("Error loading registrations", e);            
        }
        finally
        {
            try
            {
                conn.close();       
            }
            catch (SQLException ex) { }            
        }    
                
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("loadAllRegistrations"));
        } 
        
        return registrations;
    }
    
    
    public void deleteRegistration(String handle)
    {                     
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("deleteRegistration"));
        } 
        
        Connection conn = null;
        
        try
        {
            conn = this.getConnection();
            this.deleteRegistrationByHandle(conn, handle);
        }
        catch (SQLException e)
        {
            log.error("Error deleting registration", e);
        }
        finally
        {
            try
            {
                conn.close();       
            }
            catch (SQLException ex) { }            
        }                      
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("deleteRegistration"));
        } 
    }
    
    
	// ------------------------------------------------------ Protected Methods
    
    
    protected void insertRegistration(Connection conn, Registration registration)
            throws SQLException
    {
        RegistrationContext context = registration.getRegistrationContext();
        RegistrationData data = registration.getRegistrationData();

        String handle = context.getRegistrationHandle();
        String name = data.getConsumerName();
        String agent = data.getConsumerAgent();
        String methodGetSupported = Boolean.toString(
                data.isMethodGetSupported());

        PreparedStatement stmt = conn.prepareStatement(SQL_INSERT_CONSUMER);

        try
        {
            stmt.setString(1, handle);
            stmt.setString(2, name);
            stmt.setString(3, agent);
            stmt.setString(4, methodGetSupported);

            stmt.executeUpdate();
        }
        finally
        {
            stmt.close();
        }
    }
    
    
    protected Registration selectRegistrationByHandle(Connection conn,
            String handle) throws SQLException
    {
        Registration registration = null;

        PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_CONSUMER);
        ResultSet rs = null;

        try
        {
            stmt.setString(1, handle);
            rs = stmt.executeQuery();

            if (rs.next())
            {
                String name = rs.getString("name");
                String agent = rs.getString("agent");
                String methodGetSupported = 
                    rs.getString("method_get_supported");

                registration = new RegistrationImpl();
                RegistrationContext context = new RegistrationContext();
                RegistrationData data = new RegistrationData();

                registration.setRegistrationContext(context);
                registration.setRegistrationData(data);

                context.setRegistrationHandle(handle);
                context.setRegistrationState(null);
                context.setExtensions(null);

                data.setConsumerName(name);
                data.setConsumerAgent(agent);
                data.setMethodGetSupported(Boolean
                        .getBoolean(methodGetSupported));
            }

        }
        finally
        {
            if (rs != null)
            {
                rs.close();
            }

            stmt.close();
        }

        return registration;
    }
    
    
    protected List selectRegistrations(Connection conn) throws SQLException
    {
        List registrations = new ArrayList();

        PreparedStatement stmt = conn
                .prepareStatement(SQL_SELECT_ALL_CONSUMERS);
        ResultSet rs = null;

        try
        {
            rs = stmt.executeQuery();

            while (rs.next())
            {
                String handle = rs.getString("handle");
                String name = rs.getString("name");
                String agent = rs.getString("agent");
                String methodGetSupported = 
                    rs.getString("method_get_supported");

                Registration registration = new RegistrationImpl();
                registrations.add(registration);
                RegistrationContext context = new RegistrationContext();
                RegistrationData data = new RegistrationData();

                registration.setRegistrationContext(context);
                registration.setRegistrationData(data);

                context.setRegistrationHandle(handle);
                context.setRegistrationState(null);
                context.setExtensions(null);

                data.setConsumerName(name);
                data.setConsumerAgent(agent);
                data.setMethodGetSupported(
                        Boolean.getBoolean(methodGetSupported));
            }
        }
        finally
        {
            if (rs != null)
            {
                rs.close();
            }

            stmt.close();
        }

        return registrations;
    }
    
    
    protected void deleteRegistrationByHandle(Connection conn, String handle)
            throws SQLException
    {
        PreparedStatement stmt = conn.prepareStatement(SQL_DELETE_CONSUMER);

        try
        {
            stmt.setString(1, handle);
            stmt.executeUpdate();
        }
        finally
        {
            stmt.close();
        }
    }
}
