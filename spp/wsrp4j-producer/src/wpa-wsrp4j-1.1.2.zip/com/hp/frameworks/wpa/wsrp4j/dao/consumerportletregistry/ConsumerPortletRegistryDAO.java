package com.hp.frameworks.wpa.wsrp4j.dao.consumerportletregistry;

import java.util.List;


public interface ConsumerPortletRegistryDAO
{

    public List loadRegistrations(String regHandle);


    public void saveRegistration(String regHandle, String portletHandle);


    public void deleteRegistration(String regHandle, String portletHandle);


    public void deleteRegistrations(String regHandle);

}