package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import java.util.*;
import java.lang.reflect.Array;

import oasis.names.tc.wsrp.v1.types.CookieProtocol;
import oasis.names.tc.wsrp.v1.types.LocalizedString;
import oasis.names.tc.wsrp.v1.types.MarkupType;
import oasis.names.tc.wsrp.v1.types.PortletDescription;
import oasis.names.tc.wsrp.v1.types.RegistrationContext;
import oasis.names.tc.wsrp.v1.types.ServiceDescription;
import oasis.names.tc.wsrp.v1.types.UserContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pluto.om.common.Description;
import org.apache.pluto.om.common.DisplayName;
import org.apache.pluto.om.common.Language;
import org.apache.pluto.om.entity.PortletEntity;
import org.apache.pluto.om.portlet.ContentType;
import org.apache.pluto.om.portlet.PortletDefinition;
import org.apache.pluto.portalImpl.services.portletentityregistry.PortletEntityRegistry;
import org.apache.pluto.portalImpl.util.ObjectID;
import org.apache.pluto.portalImpl.om.portlet.impl.PortletDefinitionImpl;
import org.apache.wsrp4j.commons.exception.ErrorCodes;
import org.apache.wsrp4j.commons.exception.WSRPException;
import org.apache.wsrp4j.commons.exception.WSRPXHelper;
import org.apache.wsrp4j.commons.persistence.PersistentDataObject;
import org.apache.wsrp4j.commons.persistence.PersistentHandler;
import org.apache.wsrp4j.commons.persistence.ProducerPersistentFactory;
import org.apache.wsrp4j.commons.persistence.driver.PersistentAccess;
import org.apache.wsrp4j.commons.persistence.driver.WSRPServiceDescription;
import org.apache.wsrp4j.commons.producer.provider.interfaces.DescriptionHandler;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Portlet;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Provider;
import org.apache.wsrp4j.commons.producer.interfaces.ProviderAccess;
import org.apache.wsrp4j.commons.util.Constants;
import org.apache.wsrp4j.commons.util.Utility;
import org.apache.wsrp4j.commons.util.WindowStates;
import org.apache.wsrp4j.producer.provider.pluto.interfaces.PlutoProvider;

import com.hp.frameworks.wpa.wsrp4j.util.ModeMapper;


/**
 * <p>
 * This class is a replacement for the WSRP4J-provided DescriptionHandlerImpl.
 * We are providing our own implementation so that we can use our custom
 * portlet-to-WSRP mode mapping logic and also so that we can fix a bug related
 * to the default locale selection.
 * </p>
 * 
 * <p>
 * Unfortunately, the WSRP4J DescriptionHandlerImpl class has a private
 * constructor so we are unable to extend that class. Additionally, the
 * changes/fixes that we need to make are buried pretty deep within the
 * getPortletDescription() method so wrapping the original class wasn't an
 * option either. Instead, we were forced to re-implement the entire class. The
 * code below is a copy-n-paste from DescriptionHandlerImpl. We've done some
 * minor clean-up and re-formatting, but the basic logic remains unchanged
 * except for the areas marked by the "WPA MODIFIED" comment.
 * </p>
 * 
 * <p>
 * If the locale selection bug is fixed in the WSRP4J codebase at some point in
 * the future, the implementation of this class could be greatly simplified. The
 * mode mapping logic could easily be moved into a simply class that wraps the
 * DescriptionHandlerImpl.
 * </p>
 * 
 * <p>
 * This class is not instantiated directly, but is retrieved via the
 * getDescriptionHandler() method on the WPAProviderImpl.
 * </p>
 */
public class WPADescriptionHandlerImpl implements DescriptionHandler
{    
   
	// ------------------------------------------------------ Private Constants
    
    
    private final static Locale LOCALE_US_ENGLISH = new Locale("us", "en");
           
    
	// ------------------------------------------------------ Protected Members    
    
    
    protected PlutoProvider provider;
    
            
    protected ServiceDescription serviceDescription;
    
    
    // Indicates whether the producer supports URL template processing
    protected Boolean doesUrlTemplateProcessing = Boolean.FALSE;

    
	// -------------------------------------------------------- Private Members    
    
    
    // Logging and exception support
    private static final Log log = 
        LogFactory.getLog(WPADescriptionHandlerImpl.class);
    
    
	// ----------------------------------------------------------- Constructors    
    
    
    private WPADescriptionHandlerImpl() 
    { 
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("constructor"));
        }
        
        try
        {
            // Retrieve factory
            ProducerPersistentFactory persistentFactory = 
                PersistentAccess.getProducerPersistentFactory();
        
            // Use factory to retrieve handler
            PersistentHandler persistentHandler = 
                persistentFactory.getPersistentHandler();
        
            PersistentDataObject persistentDataObject = 
                persistentFactory.getServiceDescriptionList();
            
            persistentDataObject = 
                persistentHandler.restore(persistentDataObject);
                
            WSRPServiceDescription tempServiceDescription = 
                (WSRPServiceDescription) persistentDataObject.getLastElement();
            
            this.serviceDescription = 
                tempServiceDescription.toServiceDescription();
        }
        catch (WSRPException e)
        {
            log.error("Restore ServiceDescription failed. "
                    + "Check persistent XML file and content", e);            
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("constructor"));
        }        
    }
    
    
	// ---------------------------------------------------------- Class Methods    
    
    
    public static DescriptionHandler create(Provider provider) 
    {
        WPADescriptionHandlerImpl handler = new WPADescriptionHandlerImpl();
        handler.provider = (PlutoProvider) provider;       
        
        return handler;
    }
    
    
	// --------------------------------------------------------- Public Methods    
    
    
    /**
     * Returns the ServiceDescription that is returned as part of the
     * WSRP getServiceDescription operation.
     */
    public ServiceDescription getServiceDescription(
            RegistrationContext regContext, String[] desiredLocales)
            throws WSRPException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getServiceDescription"));
        }

        if (this.serviceDescription != null)
        {
            // check if full description is required
            if (regContext != null || !this.isRegistrationRequired())
            {               
                // Get all portlet descriptions from portlet pool
                PortletDescription[] descriptions =
                    this.getProducerOfferedPortletDescriptions(
                            regContext, 
                            desiredLocales);                    
                
                this.serviceDescription.setOfferedPortlets(descriptions);
                        
                this.serviceDescription.setRequiresInitCookie(
                        CookieProtocol.perGroup);
            }
        }
        else
        {
            WSRPXHelper.throwX(log, ErrorCodes.LOAD_SERVICEDESCRIPTION_FAILED);
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getServiceDescription"));
        }

        return serviceDescription;
    }


    /**
     * Returns a boolean indicating whether or not registration is
     * required in order to invoke the WSRP getServiceDescription operation.
     */
    public boolean isRegistrationRequired() throws WSRPException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("isRegistrationRequired"));
        }
        
       boolean result = true;
        
        if (this.serviceDescription != null) 
        {            
            result = this.serviceDescription.isRequiresRegistration();            
        } 
        else 
        {            
            WSRPXHelper.throwX(log, ErrorCodes.LOAD_SERVICEDESCRIPTION_FAILED);
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("isRegistrationRequired"));
        }
        
        return result;
    }


    /**
     * Returns an array of PortletDescription objects for all of the
     * producer-offered-portlets registered to this producer.
     */
    public PortletDescription[] getProducerOfferedPortletDescriptions(
            RegistrationContext regContext, String[] desiredLocales)
            throws WSRPException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getProducerOfferedPortletDescriptions"));
        }
        
        // Temporary list used to collection portlet descriptions
        List portletDescriptions = new ArrayList();
        
        // Retrieve iterator for all producer offered portlets
        Iterator portlets = 
            this.provider.getPortletPool().getAllProducerOfferedPortlets();
    
        // Iterate over portlets
        while (portlets.hasNext()) 
        {
            String id = ((Portlet) portlets.next()).getPortletHandle();       
            ObjectID objectID = ObjectID.createFromString(id);
            
            PortletEntity portletEntity = 
                    PortletEntityRegistry.getPortletEntity(objectID);
            
            if (portletEntity != null) 
            {
                PortletDefinition definition = 
                        portletEntity.getPortletDefinition();
                
                if (definition != null) 
                {
                    // Retrieve portlet description
                    PortletDescription desc = this.getPortletDescription(
                            id, 
                            regContext, 
                            null, 
                            desiredLocales);
                    
                    // Add description to temporary list
                    portletDescriptions.add(desc);
                }
            }
        }

        // Convert from list to array
        PortletDescription[] result = (PortletDescription[])
            portletDescriptions.toArray(new PortletDescription[] { });
                        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getProducerOfferedPortletDescriptions"));
        }
                
        return result;
    }


    public PortletDescription getPortletDescription(String portletHandle)
            throws WSRPException
    {       
        return this.getPortletDescription(portletHandle, null, null, null);
    }


    /**
     * This method is the reason that we even implement this class. Most of this
     * implementation is a copy-n-paste from the WSRP4J-provided
     * DescriptionHandlerImpl, but we have made a few minor changes -- look for
     * the blocks marked with the "WPA MODIFED" comment.
     */
    public PortletDescription getPortletDescription(
            String portletHandle,
            RegistrationContext regContext, 
            UserContext userContext,
            String[] desiredLocales) throws WSRPException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getPortletDescription"));
            log.debug("INPUT portletHandle: " + portletHandle);
        }

        ModeMapper modeMapper = ModeMapper.getInstance();
        
        PortletDescription portletDescription = null;

        // Need to have the portlet entity to get the portletDefinition
        PortletEntity portletEntity = PortletEntityRegistry
                .getPortletEntity(ObjectID.createFromString(portletHandle));

        if (portletEntity == null)
        {
            // no portlet entity found for given portletHandle
            WSRPXHelper.throwX(log, ErrorCodes.PORTLET_PORTLET_NOT_FOUND);
        }

        // Get a portletDefinition, to be mapped to an PortletDescription
        PortletDefinition portletDefinition = portletEntity
                .getPortletDefinition();

        if (portletDefinition != null)
        {
            portletDescription = new PortletDescription();
            Vector vector = new Vector();

            portletDescription.setPortletHandle(portletHandle);
            
            // BEGIN WPA CHANGES
            if (desiredLocales == null)
                desiredLocales = new String[0];
            
            String[] locales = getLocaleStringArray(desiredLocales);

            // global to remember the preferred language with locale, title,
            // short-title and description.  Note that the variable is misspelled
            // in the non-wpa-modified code, so we have to keep the misspelling
            Language preferedLanguage = getPreferredLanguage(desiredLocales, portletDefinition);



            // move description, title and shorttitle from Language to
            // PortletDescription
            LocalizedString localizedString;

            Locale currentLocale = preferedLanguage.getLocale();

            // pass locale to portletInvoker
            ((WPAPortletInvokerImpl)ProviderAccess.getProvider().getPortletInvoker()).setUsedLocale(currentLocale);
            // END WPA CHANGES

            String stringLocale = Constants.LOCALE_EN_US;
            if (currentLocale != null)
            {
                stringLocale = currentLocale.toString();
            }

            // add title
            String titleStr = preferedLanguage.getTitle();
            if (titleStr != null && titleStr.length() > 0)
            {
                localizedString = new LocalizedString();
                localizedString.setLang(stringLocale);
                localizedString.setValue(titleStr);
                portletDescription.setTitle(localizedString);
            }

            // add short title
            String shortTitleStr = preferedLanguage.getShortTitle();
            if (shortTitleStr != null && shortTitleStr.length() > 0)
            {
                localizedString = new LocalizedString();
                localizedString.setLang(stringLocale);
                localizedString.setValue(shortTitleStr);
                portletDescription.setShortTitle(localizedString);
            }

            // add description
            String descStr = null;
            Description description = portletDefinition
                    .getDescription(currentLocale);
            if (description != null)
            {
                descStr = description.getDescription();
            }
            if (descStr != null && descStr.length() > 0)
            {
                localizedString = new LocalizedString();
                localizedString.setLang(stringLocale);
                localizedString.setValue(descStr);
                portletDescription.setDescription(localizedString);
            }

            // add keywords
            Iterator keywordIterator = preferedLanguage.getKeywords();
            List validKeywords = new ArrayList();
            while (keywordIterator != null && keywordIterator.hasNext())
            {
                String keyword = (String) keywordIterator.next();
                if (keyword != null && keyword.length() > 0)
                {
                    validKeywords.add(keyword);
                }
            }

            int numberOfKeywords = 0;
            if ((numberOfKeywords = validKeywords.size()) > 0)
            {
                LocalizedString[] keywords = new LocalizedString[numberOfKeywords];
                Iterator it = validKeywords.iterator();
                int index = 0;
                while (it != null && it.hasNext())
                {
                    keywords[index] = new LocalizedString();
                    keywords[index].setLang(stringLocale);
                    keywords[index++].setValue((String) it.next());

                }
                portletDescription.setKeywords(keywords);
            }

            // add display name
            String displayNameStr = null;
            DisplayName displayName = portletDefinition
                    .getDisplayName(currentLocale);
            if (displayName != null)
            {
                displayNameStr = displayName.getDisplayName();
            }
            if (displayNameStr != null && displayNameStr.length() > 0)
            {
                localizedString = new LocalizedString();
                localizedString.setLang(stringLocale);
                localizedString.setValue(displayNameStr);
            }

            Iterator iterator = ((Set) portletDefinition.getContentTypeSet())
                    .iterator();
            while (iterator.hasNext())
            {

                MarkupType markupType = new MarkupType();
                ContentType contentType = (ContentType) iterator.next();

                // set ContentType->contentType to MarkupType->mimeType
                markupType.setMimeType(contentType.getContentType());

                // set Language locales to markupType locales
                markupType.setLocales(locales);

                // set ContentType->PortletModes to markupType->modes
                Iterator portletModes = contentType.getPortletModes();

                Vector modesVec = new Vector();

                while (portletModes.hasNext())
                {
                    String modeStr = portletModes.next().toString();

                    // BEGIN WPA MODIFIED
                    modeStr = modeMapper.getWsrpModeFromPortletMode(
                            portletHandle, modeStr);

                    //if (!modeStr.startsWith("wsrp:"))
                    //{
                    //    modeStr = "wsrp:" + modeStr;
                    //}
                    // END WPA MODIFIED


                    modesVec.add(modeStr);
                }

                String[] modes = new String[modesVec.size()];
                modesVec.toArray(modes);

                markupType.setModes(modes);

                /*
                 * TODO: Handling of Window States!
                 *  // set ContentType->windowStates to MarkupType->windowStates
                 * Collection windowStateCol = contentType.getWindowStates();
                 * String[] windowStates = new String[windowStateCol.size()];
                 * markupType.setWindowStates(windowStates); Iterator statesIter =
                 * windowStateCol.iterator();
                 *
                 * int j = 0; while (statesIter.hasNext()) {
                 *
                 * markupType.setWindowStates(j, statesIter.next().toString());
                 * j++; }
                 */

                // tentative solution: set some window states
                String[] windowStates = new String[3];
                markupType.setWindowStates(windowStates);
                markupType.setWindowStates(0, WindowStates.normal.getValue());
                markupType
                        .setWindowStates(1, WindowStates.minimized.getValue());
                markupType
                        .setWindowStates(2, WindowStates.maximized.getValue());

                vector.add(markupType);
            }

            // build markupTypes
            MarkupType[] markupTypeArray = new MarkupType[vector.size()];
            System.arraycopy(vector.toArray(), 0, markupTypeArray, 0,
                    markupTypeArray.length);
            portletDescription.setMarkupTypes(markupTypeArray);

            // set Application ID to PortletDescription GroupID
            portletDescription.setGroupID(portletEntity
                    .getPortletApplicationEntity().getId().toString());

            // set general default values for the following attributes
            // for the WSRP implementation.
            portletDescription.setUsesMethodGet(Boolean.FALSE);
            portletDescription.setUserContextStoredInSession(Boolean.FALSE);
            portletDescription.setTemplatesStoredInSession(Boolean.FALSE);
            portletDescription.setHasUserSpecificState(Boolean.TRUE);
            portletDescription
                    .setDoesUrlTemplateProcessing(doesUrlTemplateProcessing);

        }
        else
        {
            // no portlet definition found
            WSRPXHelper.throwX(log, ErrorCodes.MISSING_PORTLET_DEFINITION);
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getPortletDescription"));
        }

        return portletDescription;
    }

    // BEGIN WPA CHANGES

    /**
     * Ensure that US English locale is included in the array of desired locales.
     * @param desiredLocales
     * @return array of 1 or more locale String values including at least "en_US"
     */
    private String[] getLocaleStringArray(String[] desiredLocales) {
        String[] newLocales;
        boolean desiresEN = false;

        for (int i = 0; i < desiredLocales.length; i++)
        {
            if (desiredLocales[i].equals(Constants.LOCALE_EN_US))
                desiresEN = true;
        }

        if (desiresEN)
        {
            newLocales = desiredLocales;
        }
        else
        {
            newLocales = (String[]) Array.newInstance(String.class, desiredLocales.length+1);
            System.arraycopy(desiredLocales, 0, newLocales, 0, desiredLocales.length);
            Array.set(newLocales, newLocales.length-1, Constants.LOCALE_EN_US);
        }

        return newLocales;
    }

    /**
     * Compare the list of desired locales to the list of supported locales.
     * if the desired locale is supported, get the language for that locale
     * and set it as the preferrred language. If only the language is supported
     * and not the country variant, return that language still.  Otherwise use
     * US English as the default.
     *
     * Note that the list of desired locale Strings are NOT in the same format
     * as Locale.toString.  For whatever reason, the desired locales have values
     * separated by hyphens rather than by underscore, like "es-MX" rather than "es_MX".
     * Because Locale.toString returns a string with underscore, the comparisons
     * cannot work as-is and the desired locale string must first be converted
     * to a valid Locale for comparison.
     *
     * @param desiredLocales
     * @param portletDefinition
     * @return preferrred Language
     */
    private Language getPreferredLanguage(String[] desiredLocales, PortletDefinition portletDefinition)
    {
        Iterator supportedLocales = ((PortletDefinitionImpl)portletDefinition).getSupportedLocales().iterator();
        Language preferredLanguage = null;

        // set the default language first
        if (portletDefinition.getLanguageSet().getDefaultLocale() != null)
        {
            preferredLanguage = portletDefinition.getLanguageSet().get(
                    portletDefinition.getLanguageSet().getDefaultLocale());
        }
        else
        {
            preferredLanguage = portletDefinition.getLanguageSet().get(
                    LOCALE_US_ENGLISH
                );
        }

        // determine if there is an exact match in locale or at least match by language
        // desired locales should come in order of preferrence, so look "top down" for support
        outer: for (int i = 0; i < desiredLocales.length; i++)
        {
            while (supportedLocales.hasNext())
            {
                Locale supportedLocale = (Locale) supportedLocales.next();
                Locale desiredLocale = buildLocaleFromString(desiredLocales[i]);

                if (desiredLocale.equals(supportedLocale)) // exact locale match
                {
                    preferredLanguage = portletDefinition.getLanguageSet().get(supportedLocale);
                    break outer; // don't loop through and change the preferred language again
                }
                else if(desiredLocale.getLanguage().equals(supportedLocale.getLanguage())) // match by language
                {
                    preferredLanguage = portletDefinition.getLanguageSet().get(supportedLocale);
                }
            }
        }

        return preferredLanguage;
    }

    /**
     * Method to take a locale string formatted like "es-MX" and convert it to a
     * Locale object.
     *
     * @param locale String formatted with a hyphen rather than with the underscore
     * @return  a valid Locale equivalent to the locale String argument
     */
    protected Locale buildLocaleFromString(String locale) {
        StringTokenizer tokenizer = new StringTokenizer(locale,"-");
        String[] localeDef = new String[3];
        for (int i=0; i<3 ;i++) {
            if (tokenizer.hasMoreTokens()) {
                localeDef[i] = tokenizer.nextToken();
            } else {
                localeDef[i] = "";
            }
        }

        return new java.util.Locale(localeDef[0], localeDef[1], localeDef[2]);

    }
    //END WPA CHANGES
}
