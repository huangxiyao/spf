package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import java.io.IOException;
import java.io.FileWriter;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.portlet.ActionResponse;

import oasis.names.tc.wsrp.v1.types.*;

import org.apache.axis.AxisEngine;
import org.apache.axis.MessageContext;
import org.apache.axis.transport.http.HTTPConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.pluto.om.entity.PortletEntity;
import org.apache.pluto.om.window.PortletWindow;
import org.apache.pluto.om.window.PortletWindowCtrl;
import org.apache.pluto.om.window.PortletWindowList;
import org.apache.pluto.om.window.PortletWindowListCtrl;
import org.apache.pluto.portalImpl.core.PortalEnvironment;
import org.apache.pluto.portalImpl.om.window.impl.PortletWindowImpl;
import org.apache.pluto.portalImpl.services.portletentityregistry.PortletEntityRegistry;
import org.apache.pluto.portalImpl.util.ObjectID;
import org.apache.pluto.util.PrintWriterServletOutputStream;
import org.apache.pluto.factory.PortletObjectAccess;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletInvoker;
import org.apache.wsrp4j.commons.producer.util.Base64;
import org.apache.wsrp4j.commons.producer.util.MapDeserializer;
import org.apache.wsrp4j.commons.producer.util.MapSerializer;
import org.apache.wsrp4j.commons.producer.util.ServletAccess;
import org.apache.wsrp4j.commons.util.Constants;
import org.apache.wsrp4j.commons.util.LocaleHelper;
import org.apache.wsrp4j.commons.util.Utility;
import org.apache.wsrp4j.producer.provider.pluto.interfaces.PlutoProvider;
import org.apache.wsrp4j.producer.provider.pluto.interfaces.WSRPDynamicInformationProvider;

/**
 * <p>
 * This class is provided so that we can instantiate custom request and 
 * response objects before they are passed to the porlet being invoked.
 * See the comments in the WPAServletRequestWrapperImpl and 
 * WPAServletResponseWrapperImpl for an explanation as to why these classes
 * are necessary.
 * </p>
 * 
 * <p>
 * The WSRP4J development team, in their infinite wisdom decided that their
 * PortletInvokerImpl should have a private constructor and numerous
 * private methods and member variables -- making it essentially useless from
 * an extension standpoint.  In order to provide a custom implementation we
 * were forced to reimplement the entire class and cut-n-paste the code
 * from the WSRP4J-provided PortletInvoker.
 * </p>
 *
 * <p>
 * This class provides a few features that were either missing or poorly
 * implemented in the original WSRP4J class.  It was modified to handle
 * creation of the custom request object with a default locale.  It was also
 * modified to handle file uploads from remote portlets.  Finally, it was
 * modified to deal with redirection from remote portlet actions.  Only the
 * first feature was not originally specified in the WSRP spec.  The other two
 * were left out of the WSRP4J implementation.
 * </p>
 * 
 * <p>
 * If the WSRP4J project ever provides suitable implementations for the 
 * StoredResponse and WSRPServletRequestWrapperImpl, this class would no longer
 * be necessary -- and if this class were no longer necessary, the 
 * WPAProviderImpl class could be removed as well.
 * </p> 
 * 
 * <p>
 * This class is directly instantiated in the getPortletInvoker() method of
 * the WPAProviderImpl class. 
 * </p>
 */
public class WPAPortletInvokerImpl implements PortletInvoker
{

    // provider
    private PlutoProvider provider;

    // BEGIN WPA-ALTERED CODE
    // we rely on the usedLocale being set from the WPADescriptionHandler
    // when the locale and language are determined based on the request
    // OR based on the default locale.
    // The usedLocale is used when we instantiate the wrapped request and
    // for the locale set on the response
    private Locale usedLocale;

    public void setUsedLocale(Locale usedLocale) {
        this.usedLocale = usedLocale;
    }
    // END WPA-ALTERED CODE

    // for logging and exception support
    private static final Log log = 
        LogFactory.getLog(WPAPortletInvokerImpl.class);
    
    /**
     * private constructor
     */
    private WPAPortletInvokerImpl() {
        // private
    }
    
    /**
     * Creates a new PortletInvokerImpl-object. To be called within
     * an implementation of the abstract factory Provider.
     */
    public static WPAPortletInvokerImpl create(PlutoProvider provider) {
        
        WPAPortletInvokerImpl portletInvoker = new WPAPortletInvokerImpl();
        portletInvoker.provider = provider;
        
        return portletInvoker;
    }

    /**
     * @see org.apache.wsrp4j.commons.producer.provider.interfaces.PortletInvoker#invokeGetMarkup(oasis.names.tc.wsrp.v1.types.GetMarkup)
     */
    public MarkupResponse invokeGetMarkup(GetMarkup request) {
        
        String MN = "invokeGetMarkup";
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter(MN));
        }
        
        // get PortletID from PortletContext
        String portletID = request.getPortletContext().getPortletHandle();
        PortletEntity portletEntity = 
                PortletEntityRegistry.getPortletEntity(
                ObjectID.createFromString(portletID));
        PortletWindow win = null;
        String instanceKey = 
                request.getRuntimeContext().getPortletInstanceKey();
        // determine window
        if (instanceKey != null) {
            win = getPortletWindow(portletEntity, instanceKey);
        } else {
            win = getPortletWindow(portletEntity, portletID);
        }
        
        // BEGIN WPA-ALTERED CODE
        // the following lines are commented out because
        // we are modifying the collection of locales
        // to provide US English as a default
        // Locale usedLocale = LocaleHelper.getLocale(
        //        request.getMarkupParams().getLocales()[0]);

        //StoredResponse servletResponse = new StoredResponse();
        
        // Retrieve the original servlet response
        MessageContext msgContext = AxisEngine.getCurrentMessageContext();
        HttpServletResponse servletResponseOG =
            (HttpServletResponse)msgContext.getProperty(HTTPConstants.MC_HTTP_SERVLETRESPONSE);        
        
        // Wrap the servlet response in our custom wrapper
        WPAServletResponseWrapperImpl servletResponse = 
            new WPAServletResponseWrapperImpl(servletResponseOG);
        // END WPA-ALTERED CODE
        
        HttpServletRequest servletRequestOrig = 
                ServletAccess.getServletRequest();
        
        // need to have a PortalEnvironment in request
        // the constructor does this
        PortalEnvironment env =
                new PortalEnvironment(servletRequestOrig, servletResponse, 
                ServletAccess.getServlet().getServletConfig());
        
        // BEGIN WPA-ALTERED CODE
        // Wrap the original request in our wrapper
        HttpServletRequest servletRequest = new WPAServletRequestWrapperImpl(
                servletRequestOrig, 
                win, 
                usedLocale, 
                request.getMarkupParams().getMimeTypes()[0], 
                getMarkupParams(request));

        // Set the current value of the user context key on the request wrapper
        // so that it can be retrieved via the getRemoteUser() method
		if (request.getUserContext() != null)
        {
			((WPAServletRequestWrapperImpl) servletRequest).setUserContextKey(
                    request.getUserContext().getUserContextKey());
			
            if (log.isDebugEnabled())
            {
                log.debug("setting userContextKey : " + 
                    request.getUserContext().getUserContextKey());
            }
		}
        // END WPA-ALTERED CODE
        
        try {
            // set char encoding, default to UTF-8
            String[] charSets = 
                    request.getMarkupParams().getMarkupCharacterSets();
            String charEncoding = null;
            if (charSets != null) {
                charEncoding = charSets[0];
            } else {
                charEncoding = Constants.UTF_8;
            }
            
            servletRequest.setCharacterEncoding(charEncoding);
            
            //servletRequest.setCharacterEncoding(request.getMarkupParams().
            //        getMarkupCharacterSets()[0]);
        } catch (java.io.UnsupportedEncodingException e) {
        }
        
        servletResponse.setLocale(usedLocale);
        servletResponse.setContentType(
                request.getMarkupParams().getMimeTypes()[0]);
        
        // put getMarkup-request and Provider in servletRequest
        servletRequest.setAttribute(
                WSRPDynamicInformationProvider.REQUEST, request);
        servletRequest.setAttribute(
                WSRPDynamicInformationProvider.PROVIDER, this.provider);
        
        String markup = "Error occured while invoking portlet service!";
        String locale = null;
        
        try {
            provider.getPortletContainer().renderPortlet(win, servletRequest,
                    servletResponse);
            
            markup = servletResponse.getOutputBufferAsString();
            
            locale = servletResponse.getLocale().toString();
            
        } catch (Throwable t) {
            locale = Constants.LOCALE_EN_US;
            
            if (log.isErrorEnabled()) {
                log.error("Call of portletService() failed!", t);
            }
            
        }
        
        // build MarkupResponse
        MarkupResponse markupResponse = new MarkupResponse();
        
        // set markupContext in markupResponse
        if (markup != null) {
            MarkupContext markupContext = new MarkupContext();
            markupContext.setMarkupString(markup);
            markupContext.setLocale(locale);
            markupContext.setMimeType(servletRequest.getContentType());
            markupResponse.setMarkupContext(markupContext);
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit(MN));
        }
        
        return markupResponse;
    }
    
    /**
     * @see org.apache.wsrp4j.commons.producer.provider.interfaces.PortletInvoker#invokePerformBlockingInteraction(oasis.names.tc.wsrp.v1.types.PerformBlockingInteraction)
     */
    public BlockingInteractionResponse invokePerformBlockingInteraction(
            PerformBlockingInteraction request) {
        String MN = "invokePerformBlockingInteraction";
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter(MN));
        }
        
        // get portletID from PortletContext
        String portletID = request.getPortletContext().getPortletHandle();
        // get Portlet from PortletEntityRegistry by id
        PortletEntity portletEntity = 
                PortletEntityRegistry.getPortletEntity(
                ObjectID.createFromString(portletID));
        PortletWindow win = null;
        String instanceKey = 
                request.getRuntimeContext().getPortletInstanceKey();
        
        if (instanceKey != null) {
            win = getPortletWindow(portletEntity, instanceKey);
        } else {
            win = getPortletWindow(portletEntity, portletID);
        }
        
        // BEGIN WPA-ALTERED CODE
        //Locale usedLocale = LocaleHelper.getLocale(
        //        request.getMarkupParams().getLocales()[0]);
                
        //StoredResponse servletResponse = new StoredResponse();
        
        // Retrieve the original servlet response
        MessageContext msgContext = AxisEngine.getCurrentMessageContext();
        HttpServletResponse servletResponseOG =
            (HttpServletResponse)msgContext.getProperty(HTTPConstants.MC_HTTP_SERVLETRESPONSE);        
        
        // Wrap the servlet response in our custom wrapper
        WPAServletResponseWrapperImpl servletResponse = 
            new WPAServletResponseWrapperImpl(servletResponseOG);
        // END WPA-ALTERED CODE
        
        HttpServletRequest servletRequestOrig = 
                ServletAccess.getServletRequest();

        // need to have a PortalEnvironment in request
        // the constructor does this
        PortalEnvironment env =
                new PortalEnvironment(servletRequestOrig, servletResponse, 
                ServletAccess.getServlet().getServletConfig());

        // BEGIN WPA-ALTERED CODE
        // set default mime type
        String mimeType = request.getMarkupParams().getMimeTypes()[0];

        // handle file upload
        UploadContext[] uploadContexts = request.getInteractionParams().getUploadContexts();
        byte[] bytes = null;
        if (uploadContexts != null && uploadContexts.length != 0)
        {
            UploadContext uc = uploadContexts[0];
            mimeType = uc.getMimeType();
            bytes = uc.getUploadData();
        }

        // Wrap the original request in our wrapper
        HttpServletRequest servletRequest = new WPAServletRequestWrapperImpl(
                servletRequestOrig,
                win,
                usedLocale,
                mimeType,
                getInteractionParams(request));

        // set file upload content onto servletRequest
        if (bytes != null)
        {
            ((WPAServletRequestWrapperImpl)servletRequest).setMultipartData(bytes);
        }

        // Set the current value of the user context key on the request wrapper
        // so that it can be retrieved via the getRemoteUser() method
		if (request.getUserContext() != null)
        {
			((WPAServletRequestWrapperImpl) servletRequest).setUserContextKey(
                    request.getUserContext().getUserContextKey());
			
            if (log.isDebugEnabled())
            {
                log.debug("setting userContextKey : " + 
                    request.getUserContext().getUserContextKey());
            }
		}
        // END WPA-ALTERED CODE
        
		try {
            // set char encoding, default to UTF-8
            String[] charSets = 
                    request.getMarkupParams().getMarkupCharacterSets();
            String charEncoding = null;
            if (charSets != null) {
                charEncoding = charSets[0];
            } else {
                charEncoding = Constants.UTF_8;
            }
            
            servletRequest.setCharacterEncoding(charEncoding);
        } catch (java.io.UnsupportedEncodingException e) {
        }
        
        servletResponse.setLocale(usedLocale);
        
        // put performBlockingInteraction-request and Provider in servletRequest
        servletRequest.setAttribute(
                WSRPDynamicInformationProvider.REQUEST, request);
        servletRequest.setAttribute(
                WSRPDynamicInformationProvider.PROVIDER, this.provider);
        
        String markup = "";
        String locale = "";
        
        try {
            
            provider.getPortletContainer().processPortletAction(win, 
                    servletRequest, servletResponse);
            
            markup = servletResponse.getOutputBufferAsString();
            locale = servletResponse.getLocale().toString();
            
        } catch (Throwable e) {
            if (log.isErrorEnabled()) {
                log.error("Call of performPortletAction() failed!", e);
            }
        }

        // create new BlockingInteractionResponse
        BlockingInteractionResponse blockingInteractionResponse = 
                new BlockingInteractionResponse();

        // BEGIN WPA ALTERED CODE

        // get the redirect URL, set it on the blockingInteractionResponse, and return
        String location = servletResponse.getLocation();
        if (location != null && StringUtils.contains(location, "wsrp-urlType=resource"))
        {

            location = StringUtils.substringBetween(location, "wsrp-url=", "&amp;");
            blockingInteractionResponse.setRedirectURL(location);
            blockingInteractionResponse.setUpdateResponse(null);
            blockingInteractionResponse.setExtensions(null);
            return blockingInteractionResponse;
        }

        //END WPA ALTERED CODE

        // new UpdateResponse
        UpdateResponse updateResponse = new UpdateResponse();
        
        // set the nav state
        // get render params from servlet request and serialize the map
        String navState = null;
        Map renderParams = (Map) servletRequest.getAttribute(
                WSRPDynamicInformationProvider.RENDER_PARAMS);
        if (renderParams != null) {
            try {
                navState = Base64.encode(MapSerializer.serialize(renderParams));
            } catch (IOException e) {
                if (log.isErrorEnabled()) {
                    log.error("Could not serialize and " +
                            "encode render params", e);
                }
            }
        }
        
        updateResponse.setNavigationalState(navState);
        
        // set markupContext in interactionResponse
        if ((markup != null) && (markup.length() != 0)) {
            MarkupContext markupContext = new MarkupContext();
            markupContext.setLocale(locale);
            markupContext.setMimeType(servletRequest.getContentType());
            markupContext.setMarkupString(markup);
            updateResponse.setMarkupContext(markupContext);
        }
        
        // set the updateResponse of the blockingInteraction
        blockingInteractionResponse.setUpdateResponse(updateResponse);
        blockingInteractionResponse.setRedirectURL(null);
        blockingInteractionResponse.setExtensions(null);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit(MN));
        }
        
        return blockingInteractionResponse;
    }
    
    /**
     * Internal method
     * Return the portlet window for a portlet entity with a particular 
     * identifier
     * @param portletEntity the portlet entity
     * @param id String representing a portlet window idendtifier
     */
    private PortletWindow getPortletWindow(PortletEntity portletEntity, 
            String id) {
        
        String MN = "getPortletWindow";
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter(MN));
        }
        
        PortletWindow win = null;
        
        PortletWindowList windows = portletEntity.getPortletWindowList();
        
        if (windows.get(ObjectID.createFromString(id)) != null) {
            win = windows.get(ObjectID.createFromString(id));
        } else {
            win = new PortletWindowImpl(id);
            ((PortletWindowCtrl)win).setPortletEntity(portletEntity);
            ((PortletWindowListCtrl)portletEntity.getPortletWindowList()).
                    add(win);
            
            if (log.isInfoEnabled()) {
                log.info("New portlet window created!");
            }
            
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit(MN));
        }
        
        return win;
        
    }
    
    private Map getMarkupParams(GetMarkup markupRequest) {
        Map navParams = new HashMap();
        
        String naviStateStr = 
                markupRequest.getMarkupParams().getNavigationalState();
        if (naviStateStr != null) {
            
            byte[] desMap = Base64.decode(naviStateStr);
            
            Map naviState = null;
            try {
                naviState = MapDeserializer.deserialize(desMap);
            } catch (IOException iox) {
            } catch (ClassNotFoundException classNotFoundEx) {
            }
            
            if (naviState != null) {
                navParams.putAll(naviState);
            }
        }
        
        return navParams;
    }
    
    private Map getInteractionParams(
            PerformBlockingInteraction blockingInteractionRequest) {
        
        Map actionParams = new HashMap();
        
        String actionStateStr = 
                blockingInteractionRequest.getInteractionParams().
                getInteractionState();
        if (actionStateStr != null) {
            
            byte[] desMap = Base64.decode(actionStateStr);
            
            Map actionState = null;
            try {
                actionState = MapDeserializer.deserialize(desMap);
            } catch (IOException iox) {
            } catch (ClassNotFoundException classNotFoundEx) {
            }
            
            if (actionState != null) {
                actionParams.putAll(actionState);
            }
        }
        
        actionParams.putAll(getFormParameters(blockingInteractionRequest.
                getInteractionParams().getFormParameters()));
        
        return actionParams;
    }
    
    /**
     * Internal method.
     * Return the FORM parameters as Map
     * @param params array of NamedString objects
     * @return java.util.Map containing the FORM parameters and values
     */
    private static Map getFormParameters(NamedString[] params) {
        
        HashMap tmp = new HashMap();
        
        if (params != null) {
            for (int i = 0; i < params.length; i++) {
                String parameterName = params[i].getName();
                if (tmp.containsKey(parameterName)) {
                    // Handle case in which parameter name has multiple values
                    String[] currentValues = (String[])tmp.get(parameterName);
                    String[] newValues = new String[currentValues.length+1];
                    System.arraycopy(currentValues, 0, newValues, 0, 
                            currentValues.length);
                    newValues[currentValues.length] = params[i].getValue();
                    tmp.put(parameterName, newValues);
                } else {
                    String[] values = { params[i].getValue()};
                    tmp.put(parameterName, values);
                }
            }
        }
        
        return tmp;
    }
    

}
