package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import java.util.Locale;
import java.util.Map;
import java.io.IOException;
import java.io.StringReader;
import java.io.ByteArrayInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletInputStream;

import org.apache.pluto.om.window.PortletWindow;
import org.apache.wsrp4j.producer.provider.pluto.driver.WSRPServletRequestWrapperImpl;

/**
 * <p>
 * This class serves as the HttpServletRequest that is used to initiate a 
 * portlet request.  This class extends the WSRP4J-provided 
 * WSRPServletRequestWrapperImpl and overrides the getRemoteUser() method
 * so that the user information sent in the WSRP &lt;userContextKey&gt; field
 * can be propagated down the the portlet.  It also overrides the
 * getInputStream() method to handle multipart form data -- file uploads.
 * </p>
 *
 * <p>
 * If the WSRPServletRequestWrapperImpl class implements the getRemoteUser() 
 * method at some point in the future, this class can be safely eliminated.
 * </p>
 * 
 * <p>
 * This class is directly instantiated in both the invokeGetMarkup() and
 * invokePerformBlockingInteraction() methods of the WPAProtletInvokerImpl
 * class.
 * </p>
 * 
 * @version $Id: WPAServletRequestWrapperImpl.java,v 1.3 2006/08/17 16:00:47 arnoldmi Exp $
 */
public class WPAServletRequestWrapperImpl extends WSRPServletRequestWrapperImpl
{

    // ------------------------------------------------------ Protected Members
	
    
    // ID of the remote user
    protected String userContextKey;

    // multipart form data
    protected byte[] multipartData = null;

	// ----------------------------------------------------------- Constructors

    
    public WPAServletRequestWrapperImpl(HttpServletRequest request,
            PortletWindow window, Locale locale, String mimeType, Map parameters)
    {
        super(request, window, locale, mimeType, parameters);
    }

    // --------------------------------------------------------- Public Methods

    /**
     * Overridden to handle multipart form upload.  If multipart data has been set on this wrapper, an instance of the
     * inner WPAServletInputStream class is returned.
     * @return
     * @throws IOException
     */
    public ServletInputStream getInputStream() throws IOException {
        if (multipartData == null)
            return super.getInputStream();    //To change body of overridden methods use File | Settings | File Templates.
        return new WPAServletInputStream(multipartData);
    }

    /**
     * Returns the login of the user making this request, if the user has been
     * authenticated, or null if the user has not been authenticated.
     */
    public String getRemoteUser()
    {
        return this.userContextKey;
    }

        
    /**
     * Sets the value of the WSRP user context key.
     */
	public void setUserContextKey(String userContextKey) 
    {
		this.userContextKey = userContextKey;
	}

    /**
     * gets the value of the multipart data byte[]
     * @return
     */
    public byte[] getMultipartData() {
        return multipartData;
    }

    /**
     * sets the value of the multipart data byte[]
     * @param multipartData
     */
    public void setMultipartData(byte[] multipartData) {
        this.multipartData = multipartData;
    }


    /**
     * Inner class implementation of ServletInputStream to handle reading of multipart data byte[]
     */
    protected class WPAServletInputStream extends ServletInputStream
    {
        private ByteArrayInputStream stream;

        public WPAServletInputStream(byte[] bytes) {
            stream = new ByteArrayInputStream(bytes);
        }

        public int read() throws IOException {
            return stream.read();
        }
    }
}
