package com.hp.frameworks.wpa.wsrp4j.om.entity.impl;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pluto.om.common.ObjectID;
import org.apache.pluto.om.entity.PortletApplicationEntity;
import org.apache.pluto.om.entity.PortletEntity;
import org.apache.pluto.om.entity.PortletEntityList;
import org.apache.pluto.om.portlet.PortletApplicationDefinition;
import org.apache.pluto.portalImpl.services.ConfigurationException;
import org.apache.pluto.portalImpl.services.portletdefinitionregistry.PortletDefinitionRegistry;
import org.apache.wsrp4j.commons.util.Utility;


public class WPAPortletApplicationEntityImpl implements
        PortletApplicationEntity, Serializable
{

    // -------------------------------------------------------- Private Members
    
    
    private static final Log log = 
        LogFactory.getLog(WPAPortletApplicationEntityImpl.class);   
    
    
    // ------------------------------------------------------ Protected Members
    

    protected String id = null;
    
    
    protected ObjectID objectId = null;
    
    
    // Name of the web application 
    protected String definitionId = null;
    
    
    // List of portlets associated with this application
    protected PortletEntityList portletList = new WPAPortletEntityListImpl();
    
    
    // --------------------------------------------------------- Public Methods
    
    
    /**
     * Returns the object ID of this application.
     */
    public ObjectID getId()
    {
        if (this.objectId == null) 
        {
            this.objectId = 
                org.apache.pluto.portalImpl.util.ObjectID.createFromString(this.id);
        }
        
        return objectId;
    }

    
    /**
     * Returns the list of portlets associated with this application.
     */
    public PortletEntityList getPortletEntityList()
    {
        return this.portletList;
    }


    /**
     * Returns a representation of the portlet descriptor associated with this
     * application.
     */
    public PortletApplicationDefinition getPortletApplicationDefinition()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getPortletApplicationDefinition"));
        } 
        
        PortletApplicationDefinition definition = 
            PortletDefinitionRegistry.getPortletApplicationDefinitionList().get(
                    org.apache.pluto.portalImpl.util.ObjectID.createFromString(this.definitionId));
        
        if (definition == null) 
        {
            throw new ConfigurationException("Unable to find portlet application definition. "+
                    "Ensure that all portlets definied within the portlet registry are correct" +
                    "and have been deployed.");
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getPortletApplicationDefinition"));
        } 
        
        return definition;
    }


    public void setId(String id)
    {
        this.id = id;
    }

    
    public String getDefinitionId()
    {
        return this.definitionId;
    }
    
    
    public void setDefinitionId(String definitionId)
    {
        this.definitionId = definitionId;        
    }
    
    
    public void addPortletEntity(PortletEntity portlet)
    {
        ((WPAPortletEntityListImpl) this.portletList).add(portlet);
    }
    
       
    public String toString()
    {
        StringBuffer buffer = new StringBuffer();
        
        buffer.append(this.getClass().toString());
        buffer.append("{ ");        
        buffer.append("ID: " + this.id);
        buffer.append("Definition ID: " + this.definitionId);
        buffer.append("Portlets: " + this.portletList.toString());
        buffer.append(" }");
        
        return buffer.toString();
    }
}
