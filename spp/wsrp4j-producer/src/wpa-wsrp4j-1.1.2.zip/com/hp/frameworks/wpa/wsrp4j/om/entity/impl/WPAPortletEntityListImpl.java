package com.hp.frameworks.wpa.wsrp4j.om.entity.impl;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pluto.om.common.ObjectID;
import org.apache.pluto.om.entity.PortletEntity;
import org.apache.pluto.om.entity.PortletEntityList;
import org.apache.wsrp4j.commons.util.Utility;



public class WPAPortletEntityListImpl extends HashSet implements PortletEntityList,
        Serializable
{

    // -------------------------------------------------------- Private Members
    
    
    private static final Log log = 
        LogFactory.getLog(WPAPortletEntityListImpl.class);    
    
    
	// --------------------------------------------------------- Public Methods 
    
    
    /**
     * Find the portlet entity in this list with the given object ID.
     */
    public PortletEntity get(ObjectID objectId)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("get"));
        } 
        
        PortletEntity result = null;
        Iterator i = this.iterator();
        
        while (i.hasNext())
        {
            PortletEntity portlet = (PortletEntity) i.next();
            
            if (portlet.getId().equals(objectId))
            {
                result = portlet;
            }
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("get"));
        } 
        
        return result;
    }

       
    public String toString()
    {
        StringBuffer buffer = new StringBuffer();
        
        buffer.append(this.getClass().toString());
        buffer.append("{\n");
        
        Iterator i = this.iterator();
        
        while (i.hasNext())
        {
            buffer.append(i.next().toString());
            buffer.append("\n");
        }
        
        buffer.append("}\n");
        
        return buffer.toString();
    }

}
