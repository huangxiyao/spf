package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import oasis.names.tc.wsrp.v1.types.CookieProtocol;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class CookieProtocolHolder {
	private static final Log log = LogFactory.getLog(CookieProtocolHolder.class);
	private static CookieProtocol cookieProtocol;

	public static synchronized CookieProtocol getCookieProtocol() {
		if (cookieProtocol == null) {
			log.warn("CookieProtocol not set! Will use default 'perGroup'.");
			cookieProtocol = CookieProtocol.perGroup;
		}
		return cookieProtocol;
	}

	public static void setCookieProtocol(CookieProtocol cookieProtocol) {
		log.info("Setting CookieProtocol to " + cookieProtocol);
		CookieProtocolHolder.cookieProtocol = cookieProtocol;
	}


}
