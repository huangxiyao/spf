package com.hp.frameworks.wpa.wsrp4j.om.entity.impl;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pluto.om.ControllerFactory;
import org.apache.pluto.om.common.Description;
import org.apache.pluto.om.common.DescriptionSet;
import org.apache.pluto.om.common.ObjectID;
import org.apache.pluto.om.common.Preference;
import org.apache.pluto.om.common.PreferenceCtrl;
import org.apache.pluto.om.common.PreferenceSet;
import org.apache.pluto.om.common.PreferenceSetCtrl;
import org.apache.pluto.om.entity.PortletApplicationEntity;
import org.apache.pluto.om.entity.PortletEntity;
import org.apache.pluto.om.entity.PortletEntityCtrl;
import org.apache.pluto.om.portlet.PortletDefinition;
import org.apache.pluto.om.window.PortletWindowList;
import org.apache.pluto.portalImpl.services.ConfigurationException;
import org.apache.pluto.portalImpl.services.factorymanager.FactoryManager;
import org.apache.wsrp4j.commons.util.Utility;

import com.hp.frameworks.wpa.wsrp4j.dao.portletentityregistry.PortletRegistryDAOImpl;
import com.hp.frameworks.wpa.wsrp4j.om.common.impl.WPAPreferenceSetImpl;
import com.hp.frameworks.wpa.wsrp4j.services.portletentityregistry.RegistryCache;
import com.hp.frameworks.wpa.wsrp4j.producer.driver.WPAWSRPEngine;
import oasis.names.tc.wsrp.v1.types.ClonePortlet;
import oasis.names.tc.wsrp.v1.types.PortletContext;


public class WPAPortletEntityImpl implements PortletEntity, PortletEntityCtrl,
        Cloneable, Serializable
{
    
    // -------------------------------------------------------- Private Members
    
    
    private static final Log log = 
        LogFactory.getLog(WPAPortletEntityImpl.class);   
    
    
	// ------------------------------------------------------ Protected Members
    
    
	protected String id;

    protected ObjectID objectId;

    protected String definitionId;

    protected String registryId;

    protected String parentHandle;

    protected PortletApplicationEntity portletApp;

    protected PreferenceSet origPreferences = new WPAPreferenceSetImpl();

    protected PreferenceSet preferences = new WPAPreferenceSetImpl();

    protected PortletWindowList portletWindows =
        new org.apache.pluto.portalImpl.om.window.impl.PortletWindowListImpl();

    protected DescriptionSet descriptions =
        new org.apache.pluto.portalImpl.om.common.impl.DescriptionSetImpl();


	// --------------------------------------------------------- Public Methods  
    
            
    public Description getDescription(Locale locale)
    {
        return this.descriptions.get(locale);
    }


    public ObjectID getId()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getId"));
        } 
        
        if (this.objectId == null && this.portletApp != null)
        {
            this.objectId =
                org.apache.pluto.portalImpl.util.ObjectID.createFromString(
                    this.portletApp.getId().toString() + "." + id);
        }
    
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getId"));
        } 
        
        return objectId;
    }


    public PortletApplicationEntity getPortletApplicationEntity()
    {
        return this.portletApp;
    }


    public PortletDefinition getPortletDefinition()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getPortletDefinition"));
        } 
    
        ObjectID defObjId =
            org.apache.pluto.portalImpl.util.ObjectID.createFromString(
                    this.definitionId);
    
        PortletDefinition def = this.portletApp
                .getPortletApplicationDefinition()
                .getPortletDefinitionList()
                .get(defObjId);
    
        if (def == null)
        {
            throw new ConfigurationException("Unable to obtain portlet definition for :"+definitionId+
                    " Perhaps a portlet has been defined incorrectly in the portlet registry.");
        }
    
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getPortletDefinition"));
        } 
        
        return def;
    }


    public PortletWindowList getPortletWindowList()
    {
        return this.portletWindows;
    }


    public PreferenceSet getPreferenceSet()
    {
        return this.preferences;
    }


    public void setId(String id)
    {
        this.id = id;
    }


    public void setPortletDefinition(PortletDefinition portletDefinition)
    {
        this.definitionId = portletDefinition.getId().toString();
    }


    /**
     * Stores the object persistently
     */
    public void store() throws IOException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("store"));
        } 
    
		// BEGIN WPA CHANGES
		// If a pending clone request has been stored in ThreadLocal, this means that the incoming request had
        // "cloneBeforeWrite" state change request. Clone the portlet before saving it.
		if (WPAWSRPEngine.pendingClone.getClonePortlet() != null)
		{
			ClonePortlet cloneRequest = WPAWSRPEngine.pendingClone.getClonePortlet();
			// Set this to null in case the clonePortlet method behind will end up calling this
			// method again - so we don't get into infinite call loop
			WPAWSRPEngine.pendingClone.remove();
			// cloning the portlet will also save it in database and flush the cache
			PortletContext portletContext = WPAWSRPEngine.getInstance().clonePortlet(cloneRequest);
			// Save the cloned portletContext in the ThreadLocal wrapper so it can be returned to
			// the caller.
			WPAWSRPEngine.pendingClone.setPortletContext(portletContext);

			// copy the data that may have changed after the cloning
			this.id = portletContext.getPortletHandle();
			this.parentHandle = portletContext.getPortletHandle();
		}
		else {
			//we are in normal case - just save the portlet entity
            new PortletRegistryDAOImpl().savePortletEntity(this);
            RegistryCache.getInstance().flushEntry(RegistryCache.PORTLET_REGISTRY);
        }
		//new PortletRegistryDAOImpl().savePortletEntity(this);
    	//RegistryCache.getInstance().flushEntry(RegistryCache.PORTLET_REGISTRY);
        // END WPA CHANGES

        // Copy all the prefs into the backup collection
    	this.origPreferences = new WPAPreferenceSetImpl();
        ((WPAPreferenceSetImpl) this.origPreferences).addAll(
                (Collection) this.preferences);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("store"));
        }       
    }


    /**
     * Reset all changes made until the last <code>store</code>
     * call in the persistent store.
     */
    public void reset() throws IOException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("reset"));
        } 
        
        ((WPAPreferenceSetImpl) this.preferences).clear();
        ((WPAPreferenceSetImpl) this.preferences).addAll(
                (Collection) this.origPreferences);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("reset"));
        }        
    }


    public String getRawId()
    {
        return this.id;
    }

    
    public String getDefinitionId()
    {
        return this.definitionId;
    }


    public void setDefinitionId(String definitionId)
    {
        this.definitionId = definitionId;
    }


    public void setPortletApplicationEntity(PortletApplicationEntity portletApp)
    {
        this.portletApp = portletApp;
    }


    public String getRegistryId()
    {
        return this.registryId;
    }
    
    
    public void setRegistryId(String registryId)
    {
        this.registryId = registryId;
    }
    
 
    public String getParentHandle()
    {
        return this.parentHandle;
    }
    
    
    public void setParentHandle(String parentHandle)
    {
        this.parentHandle = parentHandle;
    }
    
    
    public boolean isConsumerConfigured()
    {
        return (this.parentHandle != null);
    }
         
    
    public void backupPreferences()
    {
        ((WPAPreferenceSetImpl) this.origPreferences).addAll(
                (Collection) this.preferences);        
    }
    
    
    public String toString()
    {
        StringBuffer buffer = new StringBuffer();
        
        buffer.append(this.getClass().toString());
        buffer.append("{ ");        
        buffer.append("ID: " + this.id);
        buffer.append("Definition ID: " + this.definitionId);
        buffer.append("Preferences: " + this.preferences.toString());
        buffer.append(" }");
        
        return buffer.toString();
    }
    
    
    public Object clone()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("clone"));
        } 
        
        WPAPortletEntityImpl portletEntity = new WPAPortletEntityImpl();

        portletEntity.setPortletApplicationEntity(
                this.getPortletApplicationEntity());
        portletEntity.setDefinitionId(this.getDefinitionId());

        PreferenceSet preferenceSet = portletEntity.getPreferenceSet();
        ControllerFactory ctrlFactory = 
            (ControllerFactory) FactoryManager.getFactory(ControllerFactory.class);
        PreferenceSetCtrl preferenceSetCtrl = 
            (PreferenceSetCtrl) ctrlFactory.get(preferenceSet);

        Iterator i = this.getPreferenceSet().iterator();

        while (i.hasNext())
        {
            Preference pref = (Preference) i.next();

            ArrayList values = null;
            Iterator j = pref.getValues();
            
            if (j != null) 
            {
                values = new ArrayList();
                
                while (j.hasNext()) 
                {
                    values.add(j.next());
                }
            }

            Preference newPref = preferenceSetCtrl.add(pref.getName(), values);            
            ((PreferenceCtrl) newPref).setReadOnly(
                    Boolean.valueOf(pref.isReadOnly()).toString());
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("clone"));
        } 
        
        return portletEntity;
    }
   
}
