package com.hp.frameworks.wpa.wsrp4j.dao.consumerregistry;

import java.util.List;

import org.apache.wsrp4j.commons.producer.interfaces.Registration;


public interface ConsumerRegistryDAO
{

    public void saveRegistration(Registration registration);


    public Registration loadRegistration(String handle);


    public List loadAllRegistrations();


    public void deleteRegistration(String handle);

}