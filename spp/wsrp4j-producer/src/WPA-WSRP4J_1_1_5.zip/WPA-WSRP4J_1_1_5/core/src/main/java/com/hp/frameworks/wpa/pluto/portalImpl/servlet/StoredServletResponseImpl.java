package com.hp.frameworks.wpa.pluto.portalImpl.servlet;

import org.apache.pluto.portalImpl.servlet.ServletResponseImpl;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletOutputStream;
import java.io.PrintWriter;
import java.io.IOException;

/**
 * Class to bridge the gap between Tomcat/Pluto's use of the ServletResponseImpl.getWriter method and WebLogic's use of
 * ServletResponseImpl.getOutputStream.
 */
public class StoredServletResponseImpl extends ServletResponseImpl {
	private PrintWriter mWriter;

	public StoredServletResponseImpl(HttpServletResponse response, PrintWriter writer) {
		super(response);
		mWriter = writer;
	}

	public PrintWriter getWriter() throws IOException {
		return mWriter;
	}

	public void flushBuffer() throws IOException {
		mWriter.flush();
	}

	public ServletOutputStream getOutputStream() throws IOException {
		return new ServletOutputStream() {
			private byte[] mBuf = new byte[1];

			public void write(int b) throws IOException {
				mBuf[0] = (byte) b;
				write(mBuf);
			}

			public void close() {
				mWriter.close();
			}

			public void flush() {
				mWriter.flush();
			}

			public void write(byte b[]) throws IOException {
				mWriter.write(new String(b, "UTF-8"));
			}

			public void write(byte b[], int off, int len) throws IOException {
				mWriter.write(new String(b, off, len, "UTF-8"));
			}
		};
	}
}
