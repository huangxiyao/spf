package com.hp.frameworks.wpa.wsrp4j.services.consumerregistry;

import java.util.Iterator;
import java.util.List;

import oasis.names.tc.wsrp.v1.types.RegistrationContext;
import oasis.names.tc.wsrp.v1.types.RegistrationData;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.exception.WSRPException;
import org.apache.wsrp4j.commons.producer.driver.RegistrationImpl;
import org.apache.wsrp4j.commons.producer.interfaces.ConsumerRegistry;
import org.apache.wsrp4j.commons.producer.interfaces.Registration;
import org.apache.wsrp4j.commons.producer.provider.interfaces.DescriptionHandler;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Provider;
import org.apache.wsrp4j.commons.util.HandleGenerator;
import org.apache.wsrp4j.commons.util.Utility;
import org.apache.wsrp4j.commons.util.impl.HandleGeneratorFactoryImpl;

import com.hp.frameworks.wpa.wsrp4j.dao.consumerregistry.ConsumerRegistryDAO;
import com.hp.frameworks.wpa.wsrp4j.dao.consumerregistry.ConsumerRegistryDAOImpl;
import com.hp.frameworks.wpa.wsrp4j.dao.consumerportletregistry.ConsumerPortletRegistryDAO;
import com.hp.frameworks.wpa.wsrp4j.dao.consumerportletregistry.ConsumerPortletRegistryDAOImpl;


/**
 * <p>
 * This class is a replacement for the WSRP4J-provided ConsumerRegistryImpl
 * class. This class delegates all persistence of consumer registry information
 * to a ConsumerRegistryDAO implementation and is suitable for use in clustered
 * environments.
 * </p>
 * 
 * <p>
 * This class is not directly instantiated, it is created by the
 * WPAConsumerRegistryFactoryImpl. The factory is then registered in the
 * /WEB-INF/classes/WSRPServices.properties file.
 * </p>
 */
public class WPAConsumerRegistryImpl implements ConsumerRegistry
{

    // -------------------------------------------------------- Private Members


    private static final Log log =
        LogFactory.getLog(WPAConsumerRegistryImpl.class);


    // ------------------------------------------------------ Protected Members


    // Reference to handle generator used to create new registration handles
    protected HandleGenerator handleGenerator;

    // Indicates whether the consumer requires registration
    protected boolean requiresRegistration = false;

    // Reference to the DAO used to read/write consumer registry info to DB
    protected ConsumerRegistryDAO dao = new ConsumerRegistryDAOImpl();
    protected ConsumerPortletRegistryDAO cpdao = new ConsumerPortletRegistryDAOImpl();

    // ----------------------------------------------------------- Constructors


    public WPAConsumerRegistryImpl(Provider provider)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("constructor"));
        }

        if (provider != null)
        {
            DescriptionHandler descrHandler = provider.getDescriptionHandler();

            if (descrHandler != null)
            {
                try
                {
                    this.requiresRegistration =
                        descrHandler.isRegistrationRequired();
                }
                catch(WSRPException e)
                {
                    e.printStackTrace(System.out);
                }
            }
        }

        this.handleGenerator =
            new HandleGeneratorFactoryImpl().getHandleGenerator();

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("constructor"));
        }
    }


    // --------------------------------------------------------- Public Methods


    /**
     * Returns a flag indicating whether or not consumers are required to
     * register with the producer.
     */
    public boolean isRegistrationRequired()
    {
        return this.requiresRegistration;
    }


    /**
     * Registers a consumer with the given registration data. Returns a
     * Registration object containing the registration handle for the consumer.
     */
    public Registration register(RegistrationData registrationData)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("register"));
        }

        Registration registration = new RegistrationImpl();
        RegistrationContext context= new RegistrationContext();

        registration.setRegistrationData(registrationData);
        registration.setRegistrationContext(context);

        context.setRegistrationHandle(this.handleGenerator.generateHandle());
        context.setRegistrationState(null);
        context.setExtensions(null);

        this.dao.saveRegistration(registration);

        if (log.isDebugEnabled())
        {
            log.debug("Consumer registered with handle: "
                    + context.getRegistrationHandle());
            log.debug(Utility.strExit("register"));
        }

        return registration;
    }


    /**
     * Returns the Registration object associated with the given handle. Returns
     * null, if no registration info is found for the given handle.
     */
    public Registration get(String handle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("get"));
        }

        Registration result = this.dao.loadRegistration(handle);

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("get"));
        }

        return result;
    }


    /**
     * Returns an iterator for all of the Registration objects
     * currently associated with the producer.
     */
    public Iterator getAll()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getAll"));
        }

        List result = this.dao.loadAllRegistrations();

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getAll"));
        }

        return result.iterator();
    }


    /**
     * Removes the registration object associated with the given handle.
     */
    public void deregister(String handle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("deregister"));
        }

        // remove any consumer portlets associated with this consumer
        this.cpdao.deleteRegistrations(handle);
        
        this.dao.deleteRegistration(handle);

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("deregister"));
        }
    }


    /**
     * Returns a flag indicating whether or not a consumer is registered with
     * the given handle.
     */
    public boolean check(String handle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("check"));
        }

        boolean result = this.dao.loadRegistration(handle) != null;

        if (log.isDebugEnabled())
        {
            log.debug("handle " + handle + (result ? " found" : " not found"));
            log.debug(Utility.strExit("check"));
        }

        return result;
    }

}
