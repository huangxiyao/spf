package com.hp.frameworks.wpa.pluto.portalImpl;

import org.apache.pluto.portalImpl.servlet.ServletResponseFactory;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

public class DualServletResponseFactoryImpl extends DualFactory implements ServletResponseFactory {
	public HttpServletResponse getServletResponse(HttpServletResponse response) {
		if (RequestType.isStandalone()) {
			return ((ServletResponseFactory) mStandaloneFactory).getServletResponse(response);
		}
		else {
			return ((ServletResponseFactory) mWsrpFactory).getServletResponse(response);
		}
	}

	public HttpServletResponse getStoredServletResponse(HttpServletResponse response, PrintWriter printWriter) {
		if (RequestType.isStandalone()) {
			return ((ServletResponseFactory) mStandaloneFactory).getStoredServletResponse(response, printWriter);
		}
		else {
			return ((ServletResponseFactory) mWsrpFactory).getStoredServletResponse(response, printWriter);
		}
	}
}
