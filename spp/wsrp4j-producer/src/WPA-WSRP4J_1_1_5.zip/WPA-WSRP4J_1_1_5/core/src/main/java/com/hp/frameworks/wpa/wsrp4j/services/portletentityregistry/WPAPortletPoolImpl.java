package com.hp.frameworks.wpa.wsrp4j.services.portletentityregistry;

import java.util.Iterator;
import java.util.LinkedList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.exception.ErrorCodes;
import org.apache.wsrp4j.commons.exception.WSRPException;
import org.apache.wsrp4j.commons.exception.WSRPXHelper;
import org.apache.wsrp4j.commons.producer.provider.driver.ConsumerConfiguredPortletImpl;
import org.apache.wsrp4j.commons.producer.provider.driver.ProducerOfferedPortletImpl;
import org.apache.wsrp4j.commons.producer.provider.interfaces.ConsumerConfiguredPortlet;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Portlet;
import org.apache.wsrp4j.commons.producer.provider.interfaces.ProducerOfferedPortlet;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Provider;
import org.apache.wsrp4j.commons.util.HandleGenerator;
import org.apache.wsrp4j.commons.util.HandleGeneratorFactory;
import org.apache.wsrp4j.commons.util.Utility;
import org.apache.wsrp4j.commons.util.impl.HandleGeneratorFactoryImpl;
import org.apache.wsrp4j.producer.provider.pluto.interfaces.PlutoPortletPool;

import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletApplicationEntityListImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletEntityImpl;


/**
 * <p>
 * This class serves as a replacement for the WSRP4J-provided PortletPoolImpl
 * class. Whereas the WSRP4J-provided class uses an XML-based portlet registry,
 * our implementation uses a DBMS. The implementation of the PlutoPortletPool
 * interface methods are all dependent on the data access methods defined in the
 * WPAPortletEntityRegistryService base class.
 * </p>
 * 
 * <p>
 * This class must be registered in the /WEB-INF/config/services.properties file
 * under the following key name:
 * org.apache.pluto.portalImpl.services.portletentityregistry.PortletEntityRegistryService
 * </p>
 */
public class WPAPortletPoolImpl extends WPAPortletEntityRegistryService
        implements PlutoPortletPool
{
    
	// ---------------------------------------------------------- Class Members    
    
    
    private static boolean REGISTRATION_REQUIRED = false;
    
    
    // -------------------------------------------------------- Private Members
    
    
    // You'll never guess what this is for
    private static final Log log = 
        LogFactory.getLog(WPAPortletPoolImpl.class); 
    
    
	// ------------------------------------------------------ Protected Members  
    
    
    // Variable to hold the provider instance.  This doesn't appear to be
    // used in any way.
    protected Provider provider;
    
    
    // Handle generator used to create new, unique portlet handles whenever
    // a portlet is cloned
    protected HandleGenerator handleGenerator;
    
    
	// ----------------------------------------------------------- Constructors  
    
    
    public WPAPortletPoolImpl()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("constructor"));
        } 
        
        HandleGeneratorFactory handleGenFactory = new HandleGeneratorFactoryImpl();
        handleGenerator = handleGenFactory.getHandleGenerator();
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("constructor"));
        } 
    }
    
    
	// --------------------------------------------------------- Public Methods
    
    
    public Provider getProvider()
    {
        return this.provider;
    }


    public void setProvider(Provider provider)
    {
        this.provider = provider;
    }


    /**
     * Goes through all the portlets in the portlet app list and returns an
     * iterator for all the producer offered portlets.  Note that the
     * returned collection contains ProducerOfferedPortlet objects, not 
     * PortletEntity objects.
     */
    public Iterator getAllProducerOfferedPortlets()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getAllProducerOfferedPortlets"));
        } 
        
        Iterator portlets = 
            this.getPortletAppList().getAllPortletEntities();
    
        LinkedList result = new LinkedList();
    
        while (portlets.hasNext())
        {
            WPAPortletEntityImpl portletEntity = 
                (WPAPortletEntityImpl) portlets.next();
                    
            if (!portletEntity.isConsumerConfigured())
            {
                ProducerOfferedPortlet portlet = 
                    new ProducerOfferedPortletImpl();
                portlet.setPortletHandle(portletEntity.getId().toString());
                portlet.setRegistrationRequired(REGISTRATION_REQUIRED);
    
                result.add(portlet);
            }
        }
    
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getAllProducerOfferedPortlets"));
        } 
        
        return result.iterator();
    }


    /**
     * Goes through all the portlets in the portlet app list and returns an
     * iterator for all the consumer configured portlets.  Note that the
     * returned collection contains ConsumerConfiguredPortlet objects, not 
     * PortletEntity objects.
     */    
    public Iterator getAllConsumerConfiguredPortlets()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getAllConsumerConfiguredPortlets"));
        } 
        
        Iterator portlets = 
            this.getPortletAppList().getAllPortletEntities();
        
        LinkedList result = new LinkedList();
    
        while (portlets.hasNext())
        {
            WPAPortletEntityImpl portletEntity = 
                (WPAPortletEntityImpl) portlets.next();
    
            if (portletEntity.isConsumerConfigured())
            {
                ConsumerConfiguredPortlet portlet = 
                    new ConsumerConfiguredPortletImpl();
                portlet.setPortletHandle(portletEntity.getId().toString());
                portlet.setParentHandle(portletEntity.getParentHandle());
    
                result.add(portlet);
            }
        }
    
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getAllConsumerConfiguredPortlets"));
        } 
        
        return result.iterator();
    }


    /**
     * Returns the portlet identified by the given portlet handle.  Throws a
     * WSRPException if a portlet with the given handle cannot be located.
     */
    public Portlet get(String portletHandle) throws WSRPException
    {                  
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("get"));
        } 
        
        Portlet portlet = null;
        
        WPAPortletApplicationEntityListImpl portletAppList = 
            this.getPortletAppList();
        
        WPAPortletEntityImpl portletEntity = (WPAPortletEntityImpl)
            portletAppList.getPortletEntity(portletHandle);
        
        if (portletEntity != null)
        {                          
            if (portletEntity.isConsumerConfigured())
            {
                ConsumerConfiguredPortletImpl ccp = 
                    new ConsumerConfiguredPortletImpl();
                ccp.setPortletHandle(portletHandle);
                ccp.setParentHandle(portletEntity.getParentHandle());
                
                portlet = ccp;
            }
            else
            {
                ProducerOfferedPortletImpl pop = 
                    new ProducerOfferedPortletImpl();
                pop.setPortletHandle(portletHandle);
                pop.setRegistrationRequired(REGISTRATION_REQUIRED);
                
                portlet = pop;
            }
        } 
        else
        {
            WSRPXHelper.throwX(log, ErrorCodes.GET_PORTLET_FAILED);
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("get"));
        } 
        
        return portlet;
    }


    /**
     * Clones the portlet identified by the given handle. The new portlet will
     * receive a unique ID and be added to the portlet app list. Only the
     * portlet object is cloned, not the portlet description the portlet
     * references, i.e. the resulting cloned portlet references the same portlet
     * description as its original.
     */    
    public Portlet clone(String portletHandle) throws WSRPException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("clone"));
        } 

        // Retrieve portlet app list and use it to get at the
        // portlet in question
        WPAPortletApplicationEntityListImpl portletAppList = 
            this.getPortletAppList();
                
        WPAPortletEntityImpl portletEntity = (WPAPortletEntityImpl)
            portletAppList.getPortletEntity(portletHandle);

        // Clone portlet entity and update ID
        WPAPortletEntityImpl portletClone = (WPAPortletEntityImpl) 
            portletEntity.clone();
        portletClone.setId(this.handleGenerator.generateHandle());
        portletClone.setParentHandle(portletHandle);

        // persist portlet entity and flush the cache
		this.savePortletEntity(portletClone);

	   // Generate ConsumerConfiguredPortlet
        ConsumerConfiguredPortletImpl ccp = 
            new ConsumerConfiguredPortletImpl();
        ccp.setPortletHandle(portletClone.getId().toString());
        ccp.setParentHandle(portletHandle);
              
        // TODO: clone portletState within PortletStateManager? 
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("clone"));
        }
        
        return ccp;
    }


    /**
     * Removes the portlet identified by the given handle from the portlet app
     * list. The portlet entity must exist and be a consumer-configured portlet
     * for it to be removed. Returns true if the portlet was successfully
     * destroyed; otherwise, false. Once the portlet is removed from the portlet
     * app list, the list is persisted back to the DB.
     */
    public boolean destroy(String portletHandle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("destroy"));
        }
        
        boolean result = false;

        // Retrieve portlet app list and use it to get at the
        // portlet in question
        WPAPortletApplicationEntityListImpl portletAppList = 
            this.getPortletAppList();
                
        WPAPortletEntityImpl portletEntity = (WPAPortletEntityImpl)
            portletAppList.getPortletEntity(portletHandle);

        if (portletEntity != null && portletEntity.isConsumerConfigured())
        {
            this.deletePortletEntity(portletEntity);
			result = true;
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("destroy"));
        }
        
        return result;
    }


    /**
     * Removes the portlets identified by the given handles from the portlet app
     * list. A portlet entity must exist and be a consumer-configured portlet
     * for it to be removed. Returns the list of portlet handles that could
     * not be removed. Once the portlets have been removed from the
     * portlet app list, the list is persisted back to the DB.
     */    
    public Iterator destroySeveral(Iterator portletHandles)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("destroySeveral"));
        }
        
        LinkedList result = new LinkedList();

        // Iterate over all portlet handles
        while (portletHandles.hasNext())
        {
            String portletHandle = portletHandles.next().toString();
        
            if (!this.destroy(portletHandle))
            {
                result.add(portletHandle);
            }
		}

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("destroySeveral"));
        }
        
        return result.iterator();
    }

}
