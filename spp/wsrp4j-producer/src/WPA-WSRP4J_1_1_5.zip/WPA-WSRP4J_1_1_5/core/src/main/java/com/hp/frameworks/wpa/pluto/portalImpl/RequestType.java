package com.hp.frameworks.wpa.pluto.portalImpl;

/**
 * Class to determine whether an incoming request is for a standalone portlet request.  If the
 * {@link com.hp.frameworks.wpa.pluto.portalImpl.Servlet} handles the request, the request type will be set as
 * a standalone request.  Child classes of {@link DualFactory} use this class
 * to determine to which factory calls should be delegated.
 */
public class RequestType {
	private static ThreadLocal mIsWsrp = new ThreadLocal();

	private RequestType() {}

	static void setRequestTypeAsStandalone() {
		mIsWsrp.set(Boolean.TRUE);
	}

	static void resetRequestType() {
		mIsWsrp.set(null);
	}

	public static boolean isStandalone() {
		return mIsWsrp.get() != null;
	}
}
