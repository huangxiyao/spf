package com.hp.frameworks.wpa.wsrp4j.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class BaseDAO
{

	// ------------------------------------------------------ Private Constants   
    
   
    private static final String DATASOURCE_JNDI_NAME = "java:comp/env/jdbc/wsrp4j";
    
    
	// -------------------------------------------------------- Private Members
    
    
    // Reference to the DataSource used to return connections.
    private DataSource dataSource = null;  

    
	// ------------------------------------------------------ Protected Methods    
    
    
    /**
     * Returns a Connection object from the DataSource.  If the DataSource has
     * not yet been initialized, a JNDI lookup is performed to locate and
     * cache the DataSource.  Throws a SQLException if the Connection cannot 
     * be returned for any reason. 
     */
    protected Connection getConnection() throws SQLException
    {
        // Make sure that we've got a data source to pull our connection from
        if (this.dataSource == null)
        {
            synchronized(this)
            {
                if (this.dataSource == null)
                {                    
                    this.dataSource = this.lookupDataSource();                            
                }
            }
        }
    
        if (this.dataSource == null)
        {
            throw new SQLException("Unable to locate datasource");
        }
        
        return this.dataSource.getConnection();
    }
        
        
	// -------------------------------------------------------- Private Methods
    
    
    /**
     * Does and JNDI lookup to retrieve the DataSource that has been configured
     * under the following context name: java:comp/env/jdbc/wsrp4j
     */
    private DataSource lookupDataSource()
    {
        DataSource dataSource = null;
        Context ctx = null;
        
        try
        {
            ctx = new InitialContext();          
            dataSource = (DataSource) ctx.lookup(DATASOURCE_JNDI_NAME);
        }
        catch (NamingException e)
        {
            // Do nothing, will throw an exception later
        }
        finally
        {
            try
            {
                // Closing the Context is a best practice, but the JNDI testing
                // framework we are using doesn't implement the close() method
                // for some reason.  To work around the test failures, we need
                // to wrap this in a try/catch and catch any Throwable.  
                // Catching a Throwable is overkill (and probably a bad 
                // practice) when running in an app server, but since its not 
                // really going to hurt anything we'll leave the hack in place 
                // so that our unit tests will execute properly.
                ctx.close();
            }
            catch (Throwable t) { }         
        }
        
        return dataSource;
    }
}
