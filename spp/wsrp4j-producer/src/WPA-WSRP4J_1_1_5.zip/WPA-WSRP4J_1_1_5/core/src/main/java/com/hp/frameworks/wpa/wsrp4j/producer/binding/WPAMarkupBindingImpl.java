package com.hp.frameworks.wpa.wsrp4j.producer.binding;

import org.apache.wsrp4j.commons.producer.binding.WSRPMarkupBindingImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import oasis.names.tc.wsrp.v1.types.*;

import java.rmi.RemoteException;

import com.hp.frameworks.wpa.wsrp4j.producer.driver.WPAWSRPEngine;

/**
 * <p>
 * WPA custom implementation of the WSRPMarkupBindingImpl class.  This class is necessary in order to use
 * the WPA customized implementation of WSRPEngine to handle redirects from portlet actions through WSRP.
 * If the WSRP4J implementation is ever fixed to handle redirects appropriately as per the WSRP spec, this
 * class would no longer be necessary.
 * </p>
 * <p>
 * This class must be registered in the /WEB-INF/server-config.wsdd
 * configuration file as the implementing class for the WSRPBaseService.
 * </p>
 *
 * @see WPAWSRPEngine
 */
public class WPAMarkupBindingImpl extends WSRPMarkupBindingImpl {

    private static final Log log =
        LogFactory.getLog(WPARegistrationBindingImpl.class);


    public MarkupResponse getMarkup(GetMarkup getMarkup) throws RemoteException, InconsistentParametersFault, InvalidRegistrationFault, MissingParametersFault, OperationFailedFault, UnsupportedMimeTypeFault, UnsupportedModeFault, UnsupportedLocaleFault, InvalidUserCategoryFault, InvalidSessionFault, InvalidCookieFault, AccessDeniedFault, InvalidHandleFault, UnsupportedWindowStateFault {
        return WPAWSRPEngine.getInstance().getMarkup(getMarkup);
    }

    public BlockingInteractionResponse performBlockingInteraction(PerformBlockingInteraction performBlockingInteraction) throws RemoteException, InconsistentParametersFault, InvalidRegistrationFault, MissingParametersFault, OperationFailedFault, UnsupportedMimeTypeFault, UnsupportedModeFault, UnsupportedLocaleFault, InvalidUserCategoryFault, InvalidSessionFault, InvalidCookieFault, PortletStateChangeRequiredFault, AccessDeniedFault, InvalidHandleFault, UnsupportedWindowStateFault {
        return WPAWSRPEngine.getInstance().
                performBlockingInteraction(performBlockingInteraction);
    }

    public ReturnAny releaseSessions(ReleaseSessions releaseSessions) throws RemoteException, InvalidRegistrationFault, OperationFailedFault, MissingParametersFault, AccessDeniedFault {
        return WPAWSRPEngine.getInstance().releaseSessions(releaseSessions);
    }

    public ReturnAny initCookie(InitCookie initCookie) throws RemoteException, InvalidRegistrationFault, OperationFailedFault, AccessDeniedFault {
         return WPAWSRPEngine.getInstance().initCookie(initCookie);
    }
}
