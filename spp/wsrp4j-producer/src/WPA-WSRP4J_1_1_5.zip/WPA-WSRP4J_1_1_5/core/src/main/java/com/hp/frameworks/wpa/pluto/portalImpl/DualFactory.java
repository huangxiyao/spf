package com.hp.frameworks.wpa.pluto.portalImpl;

import org.apache.pluto.factory.Factory;

import javax.servlet.ServletConfig;
import java.util.Map;

/**
 * Child classes rely upon the {@link RequestType} to determine to which factory their calls should be delegated.  The
 * RequestType.isStandalone method will return true if the incoming request is being handled by the WPA-customized
 * {@link Servlet} class.  These factories are configured in FactoryManagerService.properties file.  These classes
 * should be used only in development.  In production, the properties file should be modified to ensure the use of
 * only the WSRP factories.
 */
public abstract class DualFactory {
	protected Factory mWsrpFactory = null;
	protected Factory mStandaloneFactory = null;

	public void init(ServletConfig config, Map map) throws Exception {
		String wsrpRenderResponseFactoryClassName = (String) map.get("wsrp");
		if (wsrpRenderResponseFactoryClassName != null) {
			mWsrpFactory = (Factory) Class.forName(wsrpRenderResponseFactoryClassName).newInstance();
			mWsrpFactory.init(config, map);
		}

		String standaloneRenderResponseFactoryClassName = (String) map.get("standalone");
		if (standaloneRenderResponseFactoryClassName != null) {
			mStandaloneFactory = (Factory) Class.forName(standaloneRenderResponseFactoryClassName).newInstance();
			mStandaloneFactory.init(config, map);
		}
	}

	public void destroy() throws Exception {
		Exception e = null;
		if (mStandaloneFactory != null) {
			try {
				mStandaloneFactory.destroy();
			}
			catch (Exception e1) {
				e = e1;
			}
		}
		if (mWsrpFactory != null) {
			try {
				mWsrpFactory.destroy();
			}
			catch (Exception e1) {
				e = e1;
			}
		}
		if (e != null) {
			throw e;
		}
	}
}
