package com.hp.frameworks.wpa.pluto.portalImpl;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.io.IOException;

/**
 * Servlet class that extends the Pluto Servlet in order to ensure a session is created when using the standalone
 * mode.  The service method also sets the {@link RequestType} as standalone to ensure proper request and response handling
 * downstream by the children of {@link DualFactory}.
 *
 */
public class Servlet extends org.apache.pluto.portalImpl.Servlet {
	private static final String SERVICE_DESCRIPTION_RESOURCE_PATH = "/WEB-INF/persistence/descriptions/org.apache.wsrp4j.commons.persistence.driver.WSRPServiceDescription.xml";
	private boolean mRequiresSession = false;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		// With WSRP requiresInitCookie defines producer's cookie protocol. If it's perGroup or perUser
		// (or different than none), the consumer is supposed to initialize the session. As in standalone
		// mode we don't have consumer, we have to initialize the session manually.
		// Here we read whether the session must be create prior to invoking portlet.
		InputStream is = config.getServletContext().getResourceAsStream(SERVICE_DESCRIPTION_RESOURCE_PATH);
		if (is == null) {
			throw new ServletException("Unable to find resource '" + SERVICE_DESCRIPTION_RESOURCE_PATH + "'");
		}
		try {
			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
			Element root = doc.getDocumentElement();
			if ("none".equals(root.getAttribute("requiresInitCookie"))) {
				mRequiresSession = false;
			}
			else {
				mRequiresSession = true;
			}
			is.close();
		}
		catch (Exception e) {
			throw new ServletException("Error reading service description file", e);
		}
	}


	public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
		// If this producers requires the consumer to initialize the session, let's do it here
		// as in standalone mode we don't have a conumser. Invoking "getSession" will create a new
		// session if none exists already
		if (mRequiresSession) {
			((HttpServletRequest) servletRequest).getSession(true);
		}

		try {
			RequestType.setRequestTypeAsStandalone();
			super.service(servletRequest, servletResponse);
		}
		finally {
			RequestType.resetRequestType();
		}
	}
}
