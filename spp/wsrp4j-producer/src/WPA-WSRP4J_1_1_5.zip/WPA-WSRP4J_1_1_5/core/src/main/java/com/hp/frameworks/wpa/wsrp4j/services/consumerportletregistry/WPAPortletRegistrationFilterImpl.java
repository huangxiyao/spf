package com.hp.frameworks.wpa.wsrp4j.services.consumerportletregistry;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.exception.WSRPException;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletRegistrationFilter;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletRegistrationFilterWriter;
import org.apache.wsrp4j.commons.util.Utility;

import com.hp.frameworks.wpa.wsrp4j.dao.consumerportletregistry.ConsumerPortletRegistryDAO;
import com.hp.frameworks.wpa.wsrp4j.dao.consumerportletregistry.ConsumerPortletRegistryDAOImpl;


/**
 * <p>
 * This class is a replacement for the WSRP4J-provided
 * PortletRegistrationFilterImpl class. This class delegates all persistence of
 * consumer/portlet registry information to a ConsumerPortletRegistryDAO
 * implementation and is suitable for use in clustered environments.
 * </p>
 * 
 * <p>
 * This class is accessed directly by the WPADBProviderImpl class.
 * WPADBProviderImpl is instantiated by the WPADBProviderFactoryImpl which is
 * registered in the /WEB-INF/classes/WSRPServices.properties file.
 * </p>
 */
public class WPAPortletRegistrationFilterImpl implements
        PortletRegistrationFilter, PortletRegistrationFilterWriter
{

	// ---------------------------------------------------------- Class Members    
    
    
    // Single allowable instance of this class
    private static WPAPortletRegistrationFilterImpl singleton = 
        new WPAPortletRegistrationFilterImpl();
    
    
	// -------------------------------------------------------- Private Members
    
    
    private static final Log log = 
        LogFactory.getLog(WPAPortletRegistrationFilterImpl.class); 
    
    
	// ------------------------------------------------------ Protected Members    
    
    
    // Reference to our DAO
    protected ConsumerPortletRegistryDAO dao = 
        new ConsumerPortletRegistryDAOImpl();
    
    
	// ----------------------------------------------------------- Constructors  
    
    
    // Private default constructor
    private WPAPortletRegistrationFilterImpl() { }
    
    
	// ---------------------------------------------------------- Class Methods
    
    
    /**
     * Returns an instance of this class as a PortletRegistrationFilter.
     */
    public static PortletRegistrationFilter getReader()
    {
        return singleton;
    }
    
    
    /**
     * Returns an instance of this class as a PortletRegistrationFilterWriter.
     */
    public static PortletRegistrationFilterWriter getWriter()
    {
        return singleton;
    }
    
    
	// --------------------------------------------------------- Public Methods
    
    
    /**
     * Returns all portlet handles of portlets a consumer (identified by
     * regHandle) can utilize. Returns null if there are no entries for the
     * provided regHandle.
     * 
     * @param regHandle
     * String representing the registration handle of a consumer
     * 
     * @return Iterator of portlet handles
     */
    public Iterator getAvailable(String regHandle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getAvailable"));
        } 
        
        List portletHandles = dao.loadRegistrations(regHandle);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getAvailable"));
        } 
        
        return portletHandles.iterator();
    }


    /**
     * Indicates whether a certain consumer is allowed to utilize the portlet
     * identified by portletHandle. Returns false if there is no entry for the
     * provided handles.
     * 
     * @param regHandle
     * String representing the registration handle of a consumer
     * @param portletHandle
     * String representing the portlet handle of a portlet
     * 
     * @return boolean indicating whether the consumer corresponding to
     * regHandle is allowed to use the portlet identified by portletHandle
     */
    public boolean isAvailable(String regHandle, String portletHandle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("isAvailable"));
            log.debug("regHandle: " + regHandle);
            log.debug("portletHandle: " + portletHandle);
        }                 
        
        boolean result = false;
        
        Iterator i = dao.loadRegistrations(regHandle).iterator();
        
        while (i.hasNext())
        {
            String curHandle = i.next().toString();
            
            if (curHandle.equals(portletHandle))
            {
                result = true;
                break;
            }
        }
        
        if (log.isDebugEnabled()) {
            log.debug("RESULT: " + result);
            log.debug(Utility.strExit("isAvailable"));
        }  
        
        return result;
    }


    /**
     * Makes a certain portlet (identified by portletHandle) available to a
     * consumer (identified by regHandle). If there is no portlet in the portlet
     * pool that corresponds to portletHandle, the method performs nothing.
     * 
     * @param regHandle
     * String representing the registration handle of a consumer
     * @param portletHandle
     * String representing the portlet handle of a consumer
     */
    public void makeAvailable(String regHandle, String portletHandle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("makeAvailable"));
            log.debug("regHandle: " + regHandle);
            log.debug("portletHandle: " + portletHandle);
        } 
        
        dao.saveRegistration(regHandle, portletHandle);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("makeAvailable"));
        } 
    }


    /**
     * Makes several portlets (identified by portletHandles) available to a
     * certain consumer (identified by regHandle). For portlet handles that do
     * not correspond to portlets kept within the portlet pool, the method makes
     * no availability-entry.
     * 
     * @param regHandle
     * String representing the registration handle of a consumer
     * @param portletHandles
     * Iterator containing some portlet handles of portlets
     */
    public void makeAvailable(String regHandle, Iterator portletHandles)
            throws WSRPException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("makeAvailable"));
        } 

        while (portletHandles.hasNext())
        {
            dao.saveRegistration(regHandle, portletHandles.next().toString());
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("makeAvailable"));
        }         
    }


    /**
     * Removes an entire entry for a certain consumer (identified by regHandle).
     * If there are no entries for the provided regHandle, the method performs
     * nothing. The method is useful when a consumer deregisters.
     * 
     * @param regHandle
     * String representing the registration handle of a consumer
     */
    public void remove(String regHandle)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("remove"));
            log.debug("regHandle: " + regHandle);
        } 
        
        dao.deleteRegistrations(regHandle);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("remove"));
        }      
    }


    /**
     * Abrogates the availability of a certain portlet (identified by
     * portletHandle) regarding a certain consumer (identified by regHandle). If
     * there is no entry for the provided regHandle and portletHandle, the
     * method performs nothing.
     * 
     * @param regHandle
     * String representing the registration handle of a consumer
     * @param portletHandle
     * String representing the portlet handle of a consumer
     */
    public void remove(String regHandle, String portletHandle)
            throws WSRPException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("remove"));
            log.debug("regHandle: " + regHandle);
            log.debug("portletHandle: " + portletHandle);
        } 

        dao.deleteRegistration(regHandle, portletHandle);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("remove"));
        }        
    }


    /**
     * Abrogates the availability of several portlets (identified by
     * portletHandles) regarding a certain consumer (identified by regHandle).
     * For portlet handles that do not correspond to portlets kept within the
     * portlet pool, the method performs nothing.
     * 
     * @param regHandle
     * String representing the registration handle of a consumer
     * @param portletHandles
     * Iterator containing some portlet handles of portlets
     */
    public void remove(String regHandle, Iterator portletHandles)
            throws WSRPException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("remove"));
            log.debug("regHandle: " + regHandle);
            log.debug( "portletHandles: " + portletHandles);
        } 

        while (portletHandles.hasNext())
        {
            dao.deleteRegistration(regHandle, portletHandles.next().toString());
        }
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("remove"));
        }        
    }

}
