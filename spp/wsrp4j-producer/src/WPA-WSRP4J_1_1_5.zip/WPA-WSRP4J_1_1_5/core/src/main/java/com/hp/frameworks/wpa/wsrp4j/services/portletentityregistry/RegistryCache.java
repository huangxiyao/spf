package com.hp.frameworks.wpa.wsrp4j.services.portletentityregistry;

import com.opensymphony.oscache.general.GeneralCacheAdministrator;

/**
 * This class serves as a singleton wrapper around the OSCache-provided
 * GeneralCacheAdministrator.  We're only doing this cause we need to be able
 * to access the same cache from a couple different places and there is no
 * good way to pass it around.
 */
public class RegistryCache extends GeneralCacheAdministrator
{
    
	// ------------------------------------------------------- Public Constants
    
   
    // Key under which we'll be storing the portlet entity registry
    public static final String PORTLET_REGISTRY = 
        "com.hp.frameworks.wpa.wsrp4j.services.portletentityregistry.WPAPortletEntityRegistry";
    
    
    // ---------------------------------------------------------- Class Members
    
    
    // The single allowable instance of this class
    private static RegistryCache singleton = new RegistryCache();
    
    
	// ----------------------------------------------------------- Constructors    
    
    
    /**
     * Requisite private constructor
     */
    private RegistryCache() { }
    
    
    // ---------------------------------------------------------- Class Methods
    
    
    /**
     * Returns the single allowable instance of this class
     */
    public static RegistryCache getInstance()
    {
        return singleton;
    }
}
