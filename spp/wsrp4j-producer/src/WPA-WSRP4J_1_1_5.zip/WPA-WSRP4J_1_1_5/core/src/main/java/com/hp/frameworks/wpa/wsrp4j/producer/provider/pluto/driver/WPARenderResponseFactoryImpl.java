package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import java.util.Map;

import javax.portlet.RenderResponse;
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.pluto.factory.RenderResponseFactory;
import org.apache.pluto.om.window.PortletWindow;


/**
 * <p>
 * This class is solely responsible for instantiating and returning an
 * instance of the WPARenderResponseImpl.  For details regarding why we
 * even need a WPARenderResponseImpl in the first place, see the comments
 * in that class.
 * </p>
 * 
 * <p>
 * This class must be registered in 
 * the /config/services/FactoryManagerService.properties file under the
 * following key name: factory.javax.portlet.RenderResponse
 * </p>
 * 
 * <p>
 * If there comes a time where the WPARenderResponseImpl class is no longer
 * needed, this class can safely be deleted and de-registered as well.
 * </p>
 */
public class WPARenderResponseFactoryImpl implements RenderResponseFactory
{

	// --------------------------------------------------------- Public Methods   
    
    
    public RenderResponse getRenderResponse(
            PortletWindow portletWindow,
            HttpServletRequest servletRequest, 
            HttpServletResponse servletResponse,
            boolean containerSupportsBuffering)
    {
        RenderResponse renderResponse = 
            new WPARenderResponseImpl(
                    portletWindow, 
                    servletRequest, 
                    servletResponse, 
                    containerSupportsBuffering);
        
        return renderResponse;
    }


    public void init(ServletConfig config, Map properties) 
    {
        // NO-OP
    }


    public void destroy() 
    {
        // NO-OP
    }

}
