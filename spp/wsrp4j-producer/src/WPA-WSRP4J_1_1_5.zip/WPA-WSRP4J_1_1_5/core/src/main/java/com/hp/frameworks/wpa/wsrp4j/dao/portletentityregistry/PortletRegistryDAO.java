package com.hp.frameworks.wpa.wsrp4j.dao.portletentityregistry;

import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletApplicationEntityListImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletEntityImpl;

import java.util.List;


/**
 * <p>
 * The PortletRegistryDAO interface serves as the front-end to all transactions
 * dealing with the portlet entity registry. The portlet entity registry
 * consists of the following tables: APPLICATION, PORTLET, PREFERENCE and
 * PREFERENCE_VALUE.
 * </p>
 * 
 * <p>
 * A PortletRegistryDAO is instantiated and used by the
 * WPAPortletEntityRegistryService.
 * </p>
 */
public interface PortletRegistryDAO
{

    /**
     * Loads and returns the entire portlet entity registry, including all
     * applications, portlets, preferences and preference values.
     */
    public WPAPortletApplicationEntityListImpl loadPortletRegistry();


    /**
     * Loads and returns the portlet entity registry, including applications,
     * portlets, preferences and preference values for the given definition IDs.
     */
    public WPAPortletApplicationEntityListImpl loadPortletRegistry(String[] definitionIds);


    /**
     * Takes the given portlet application list and persists it back to the
     * database, including all applications, portlets, preferences and
     * preference values.
     */
    public void savePortletRegistry(WPAPortletApplicationEntityListImpl portletApps);


    /**
     * Persists a particular portlet entity back to the database including all
     * of its preferences and preference values.
     */
    public void savePortletEntity(WPAPortletEntityImpl portlet);


    /**
     * Deletes the given portlet entity from the database including all of its
     * preferences and preference values.
     */
    public void deletePortletEntity(WPAPortletEntityImpl portlet);

    /**
     * Loads and returns a List of portlet handles corresponding to the given portlet's children.
     */
    public List getChildPortletHandles(WPAPortletEntityImpl portlet);
}