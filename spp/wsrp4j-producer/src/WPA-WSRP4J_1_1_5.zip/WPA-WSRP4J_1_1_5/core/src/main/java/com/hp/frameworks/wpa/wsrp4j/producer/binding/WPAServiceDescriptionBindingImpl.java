package com.hp.frameworks.wpa.wsrp4j.producer.binding;

import org.apache.wsrp4j.commons.producer.binding.WSRPServiceDescriptionBindingImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import oasis.names.tc.wsrp.v1.types.ServiceDescription;
import oasis.names.tc.wsrp.v1.types.GetServiceDescription;
import oasis.names.tc.wsrp.v1.types.InvalidRegistrationFault;
import oasis.names.tc.wsrp.v1.types.OperationFailedFault;

import java.rmi.RemoteException;

import com.hp.frameworks.wpa.wsrp4j.producer.driver.WPAWSRPEngine;

/**
 * <p>
 * WPA custom implementation of the WSRPServiceDescriptionBindingImpl class.  This class is necessary in
 * order to use the WPA customized implementation of WSRPEngine to handle redirects from portlet actions
 * through WSRP.  If the WSRP4J implementation is ever fixed to handle redirects appropriately as per the
 * WSRP spec, this class would no longer be necessary.
 * </p>
 * <p>
 * This class must be registered in the /WEB-INF/server-config.wsdd
 * configuration file as the implementing class for the WSRPServiceDescriptionService.
 * </p>
 *
 * @see WPAWSRPEngine
 */
public class WPAServiceDescriptionBindingImpl extends WSRPServiceDescriptionBindingImpl {

    private static final Log log =
        LogFactory.getLog(WPAServiceDescriptionBindingImpl.class);

        public ServiceDescription getServiceDescription(
            GetServiceDescription getServiceDescription)
    throws RemoteException, InvalidRegistrationFault, OperationFailedFault {

        return WPAWSRPEngine.getInstance().
                getServiceDescription(getServiceDescription);
    }
}
