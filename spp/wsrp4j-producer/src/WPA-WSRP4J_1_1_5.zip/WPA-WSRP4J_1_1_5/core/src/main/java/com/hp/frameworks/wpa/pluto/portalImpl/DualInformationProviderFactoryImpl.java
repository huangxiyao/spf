package com.hp.frameworks.wpa.pluto.portalImpl;

import org.apache.pluto.portalImpl.factory.InformationProviderFactory;
import org.apache.pluto.services.information.StaticInformationProvider;
import org.apache.pluto.services.information.DynamicInformationProvider;
import org.apache.pluto.services.information.InformationProviderService;

import javax.servlet.http.HttpServletRequest;

public class DualInformationProviderFactoryImpl extends DualFactory implements InformationProviderFactory, InformationProviderService {

	public StaticInformationProvider getStaticProvider() {
		if (RequestType.isStandalone()) {
			return ((InformationProviderFactory) mStandaloneFactory).getStaticProvider();
		}
		else {
			return ((InformationProviderFactory) mWsrpFactory).getStaticProvider();
		}
	}

	public DynamicInformationProvider getDynamicProvider(HttpServletRequest request) {
		if (RequestType.isStandalone()) {
			return ((InformationProviderFactory) mStandaloneFactory).getDynamicProvider(request);
		}
		else {
			return ((InformationProviderFactory) mWsrpFactory).getDynamicProvider(request);
		}
	}
}
