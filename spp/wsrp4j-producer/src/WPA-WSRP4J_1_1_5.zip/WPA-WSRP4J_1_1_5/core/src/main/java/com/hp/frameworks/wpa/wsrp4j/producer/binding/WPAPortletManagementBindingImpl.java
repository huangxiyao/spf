package com.hp.frameworks.wpa.wsrp4j.producer.binding;

import org.apache.wsrp4j.commons.producer.binding.WSRPPortletManagementBindingImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import oasis.names.tc.wsrp.v1.types.*;

import java.rmi.RemoteException;

import com.hp.frameworks.wpa.wsrp4j.producer.driver.WPAWSRPEngine;

/**
 * <p>
 * WPA custom implementation of the WSRPPortletManagementBindingImpl class.  This class is necessary in
 * order to use the WPA customized implementation of WSRPEngine to handle redirects from portlet actions
 * through WSRP. If the WSRP4J implementation is ever fixed to handle redirects appropriately as per the
 * WSRP spec, this class would no longer be necessary.
 * </p>
 * <p>
 * This class must be registered in the /WEB-INF/server-config.wsdd
 * configuration file as the implementing class for the WSRPManagementService.
 * </p>
 *
 * @see WPAWSRPEngine
 */
public class WPAPortletManagementBindingImpl extends WSRPPortletManagementBindingImpl {

    private static final Log log =
        LogFactory.getLog(WPAPortletManagementBindingImpl.class);

    public PortletDescriptionResponse getPortletDescription(
            GetPortletDescription getPortletDescription)
    throws RemoteException, InvalidUserCategoryFault,
            InconsistentParametersFault, InvalidRegistrationFault,
            OperationFailedFault, MissingParametersFault, AccessDeniedFault,
            InvalidHandleFault {

        return WPAWSRPEngine.getInstance().
                getPortletDescription(getPortletDescription);
    }

    public PortletContext clonePortlet(ClonePortlet clonePortlet)
    throws RemoteException, InvalidUserCategoryFault,
            InconsistentParametersFault, InvalidRegistrationFault,
            OperationFailedFault, MissingParametersFault, AccessDeniedFault,
            InvalidHandleFault {

        return WPAWSRPEngine.getInstance().clonePortlet(clonePortlet);
    }

    public DestroyPortletsResponse destroyPortlets(
            DestroyPortlets destroyPortlets)
    throws RemoteException, InconsistentParametersFault,
            InvalidRegistrationFault, OperationFailedFault,
            MissingParametersFault {

        return WPAWSRPEngine.getInstance().destroyPortlets(destroyPortlets);
    }

    public PortletContext setPortletProperties(
            SetPortletProperties setPortletProperties)
    throws RemoteException, InvalidUserCategoryFault,
            InconsistentParametersFault, InvalidRegistrationFault,
            OperationFailedFault, MissingParametersFault, AccessDeniedFault,
            InvalidHandleFault {

        return WPAWSRPEngine.getInstance().
                setPortletProperties(setPortletProperties);
    }

    public PropertyList getPortletProperties(
            GetPortletProperties getPortletProperties)
    throws RemoteException, InvalidUserCategoryFault,
            InconsistentParametersFault, InvalidRegistrationFault,
            OperationFailedFault, MissingParametersFault, AccessDeniedFault,
            InvalidHandleFault {

        return WPAWSRPEngine.getInstance().
                getPortletProperties(getPortletProperties);
    }

    public PortletPropertyDescriptionResponse getPortletPropertyDescription(
            GetPortletPropertyDescription getPortletPropertyDescription)
    throws RemoteException, InvalidUserCategoryFault,
            InconsistentParametersFault, InvalidRegistrationFault,
            OperationFailedFault, MissingParametersFault, AccessDeniedFault,
            InvalidHandleFault {

        return WPAWSRPEngine.getInstance().
                getPortletPropertyDescription(getPortletPropertyDescription);
    }
}
