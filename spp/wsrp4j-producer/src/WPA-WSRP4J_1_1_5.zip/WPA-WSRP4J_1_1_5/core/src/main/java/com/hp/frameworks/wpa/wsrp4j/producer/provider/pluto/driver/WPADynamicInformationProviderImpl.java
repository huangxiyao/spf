package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import java.util.ArrayList;
import java.util.Iterator;

import javax.portlet.PortletMode;
import javax.portlet.WindowState;
import javax.servlet.http.HttpServletRequest;

import oasis.names.tc.wsrp.v1.types.GetMarkup;
import oasis.names.tc.wsrp.v1.types.MarkupParams;
import oasis.names.tc.wsrp.v1.types.MarkupType;
import oasis.names.tc.wsrp.v1.types.PerformBlockingInteraction;
import oasis.names.tc.wsrp.v1.types.PortletContext;
import oasis.names.tc.wsrp.v1.types.PortletDescription;
import oasis.names.tc.wsrp.v1.types.RuntimeContext;
import oasis.names.tc.wsrp.v1.types.UserContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pluto.om.window.PortletWindow;
import org.apache.pluto.services.information.PortletActionProvider;
import org.apache.pluto.services.information.PortletURLProvider;
import org.apache.pluto.services.information.ResourceURLProvider;
import org.apache.wsrp4j.commons.exception.WSRPException;
//import org.apache.wsrp4j.commons.log.LogManager;
//import org.apache.wsrp4j.commons.log.Logger;
import org.apache.wsrp4j.commons.producer.provider.interfaces.ConsumerConfiguredPortlet;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Portlet;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Provider;
import org.apache.wsrp4j.commons.util.Utility;
import org.apache.wsrp4j.commons.util.WindowStates;
import org.apache.wsrp4j.producer.provider.pluto.driver.PortletURLProviderImpl;
import org.apache.wsrp4j.producer.provider.pluto.driver.ResourceURLProviderImpl;
import org.apache.wsrp4j.producer.provider.pluto.interfaces.WSRPDynamicInformationProvider;

import com.hp.frameworks.wpa.wsrp4j.util.ModeMapper;


/**
 * <p>
 * This class is provided as a substitute for the WSRP4J-supplied
 * DynamicInformationProviderImpl. We are replacing the WSRP4J-provided class so
 * that we can make use of our custom portlet mode mapping logic. Both the
 * getPortletMode() and isPortletModeAllowed() methods need to translate between
 * WSRP modes and Portlet modes and this is where our ModeMapper comes into
 * play.
 * </p>
 * 
 * <p>
 * In an effort to showcase their crack OO design skills, the WSRP4J team marked
 * all of the members of the DynamicInformationProviderImpl as private -- so,
 * even though we only need to override a few methods, we were forced to
 * re-implement the entire class. We considered simply wrapping their
 * implementation with our own and delegating the method calls, but that
 * wouldn't even work since their constructor alters the HttpServletRequest
 * argument in such a way that it no longer contains the information we need
 * after they are done with it. The bulk of our implementation is cut-n-pasted
 * from theirs, however we have done a significant amount of code clean-up to
 * help with the readability/maintainability of our implementation.
 * </p>
 * 
 * <p>
 * This class is not directly instantiated, it is created by the
 * WPAInformationProviderServiceFactoryImpl. The factory is then registered in
 * the /WEB-INF/config/services/FactoryManagerService.properties file.
 * </p>
 */
public class WPADynamicInformationProviderImpl implements
        WSRPDynamicInformationProvider
{

    // -------------------------------------------------------- Private Members
    
    
    private static final Log log = 
        LogFactory.getLog(WPADynamicInformationProviderImpl.class);
    
    
    // ------------------------------------------------------ Protected Members
    
    
    // References the servlet request
    protected HttpServletRequest servletRequest;

    // References the provider
    protected Provider provider;

    // Reference to the runtime context of the request
    protected RuntimeContext runtimeContext;

    // Reference to the user context of the request
    protected UserContext userContext;

    // Default mode
    protected PortletMode mode = new PortletMode(PortletMode.VIEW.toString());

    // Default window state
    protected WindowState winState = new WindowState(WindowState.NORMAL.toString());

    // Is this a secure request between browser and consumer 
    protected boolean isSecure = false;

    // Portlet context
    protected PortletContext portletContext;

    // MIME types
    protected String[] mimeTypes;
    
    // The root portlet handle for the current portlet. If the portlet is a 
    // producer-provided portlet, then the root handle is just the handle of 
    // the portlet itself.  If the portlet is a consumer-configured portlet,
    // then the root handle is the handle of the producer-provided portlet that 
    // this portlet has been cloned from.
    protected String rootPortletHandle;
    
    // Reference to our mode mapper instance
    protected ModeMapper modeMapper = ModeMapper.getInstance();


    // ----------------------------------------------------------- Constructors
    
    
    public WPADynamicInformationProviderImpl(HttpServletRequest request)
    {              
        this.servletRequest = request;

        // Retrieve provider and then remove from request scope
        this.provider = (Provider) 
            request.getAttribute(WSRPDynamicInformationProvider.PROVIDER);
        request.removeAttribute(WSRPDynamicInformationProvider.PROVIDER);

        if (provider == null)
        {
            // TODO: Exception ??
        }

        // Retrieve the WSRP request object and then remove from request scope
        Object wsrpRequest = 
            request.getAttribute(WSRPDynamicInformationProvider.REQUEST);
        request.removeAttribute(WSRPDynamicInformationProvider.REQUEST);

        if (request == null)
        {
            // TODO Exception 
        }

        MarkupParams markupParams = null;
        
        // getMarkup was called
        if (wsrpRequest instanceof GetMarkup)
        {
            GetMarkup markupRequest = (GetMarkup) wsrpRequest;
            
            this.runtimeContext = markupRequest.getRuntimeContext();
            this.userContext = markupRequest.getUserContext();
            this.portletContext = markupRequest.getPortletContext();
            markupParams = markupRequest.getMarkupParams();
        }
        else if (wsrpRequest instanceof PerformBlockingInteraction)
        {
            PerformBlockingInteraction blockingInteractionRequest = 
                (PerformBlockingInteraction)wsrpRequest;

            this.runtimeContext = blockingInteractionRequest.getRuntimeContext();
            this.userContext = blockingInteractionRequest.getUserContext();
            this.portletContext = blockingInteractionRequest.getPortletContext();
            markupParams = blockingInteractionRequest.getMarkupParams();
            
        } 
        else
        {
            // TODO Exception ??
        }   
        
        this.rootPortletHandle = 
            this.getRootPortletHandle(this.portletContext);
        
        this.readMarkupParams(markupParams);        
    }


    // --------------------------------------------------------- Public Methods
    
    
    /**
     * Retrieve a PortletActionProvider instance.  We had to provide a custom
     * implementation of the PortletActionProvider since it needs to be 
     * instantiated with a reference to the "this".
     */
    public PortletActionProvider getPortletActionProvider(PortletWindow portletWindow)
    {
        return new WPAPortletActionProviderImpl(this);
    }


    /**
     * Return the portlet mode.  This implementation is identical to the
     * WSRP4J-supplied class.
     */
    public PortletMode getPortletMode(PortletWindow portletWindow)
    {        
        return new PortletMode(this.mode.toString());
    }


    /**
     * Return a PortletURLProvider.  This implementation is identical to the
     * WSRP4J-supplied class.
     */
    public PortletURLProvider getPortletURLProvider(PortletWindow portletWindow)
    {
        return new PortletURLProviderImpl(
                this.servletRequest, 
                this.provider,
                this.runtimeContext, 
                this.portletContext, 
                this.userContext);
    }


    /**
     * Return a ResourceURLProvider.  This implementation is identical to the
     * WSRP4J-supplied class.
     */    
    public ResourceURLProvider getResourceURLProvider(
            PortletWindow portletWindow)
    {
        // I can't figure out why I thought I needed a custom implementation here,
        // I'm putting the WSRP4J-provided class back for the time being.
//        return new WPAResourceURLProviderImpl(
//                this.servletRequest,
//                this.provider, 
//                this.isSecure);
        
        return new ResourceURLProviderImpl(
                this.servletRequest, 
                this.provider, 
                this.isSecure);
    }


    /**
     * Return the MIME type for the current request.  This implementation is 
     * identical to the WSRP4J-supplied class.
     */
    public String getResponseContentType()
    {
        return this.mimeTypes[0];
    }


    /**
     * Return all MIME types associated with the current request. This
     * implementation is identical to the WSRP4J-supplied class.
     */
    public Iterator getResponseContentTypes()
    {
        ArrayList arrayList = new ArrayList(this.mimeTypes.length);
        
        for(int x = 0; x < arrayList.size(); x++)
        {
            arrayList.add(mimeTypes[x]);
        }
        
        return arrayList.iterator();
    }


    /**
     * Return the portlet window state. This implementation is identical to the
     * WSRP4J-supplied class.
     */
    public WindowState getWindowState(PortletWindow portletWindow)
    {        
        return new WindowState(this.winState.toString());
    }


    /**
     * Returns whether or not the given portlet mode is allowed.  This method
     * has been significantly changed from the WSRP4J-supplied implementation
     * so that we can make use of the ModeMapper class.
     */
    public boolean isPortletModeAllowed(PortletMode portletMode)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("isPortletModeAllowed"));
            log.debug("INPUT: portletMode=" + portletMode.toString());
        } 
        
        boolean result = false;
        
        Iterator i = this.getSupportedPortletModes();
        
        while (i.hasNext())
        {
            PortletMode curMode = (PortletMode) i.next();
            
            if (curMode.equals(portletMode))
            {
                result = true;
                break;
            }
        }
        
        if (log.isDebugEnabled()) {
            log.debug("RESULT: " + result);
            log.debug(Utility.strExit("isPortletModeAllowed"));
        } 
        
        return result;
    }


    /**
     * Returns whether or not the given window state is allowed. For the sake of
     * efficiency, this method has been significantly refactored from the
     * implementation provided by WSRP4j.
     */
    public boolean isWindowStateAllowed(WindowState windowState)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("isWindowStateAllowed"));
            log.debug("INPUT: windowState =" + windowState.toString());
        } 
        
        boolean result = false;
    
        Iterator i = this.getSupportedWindowStates();
    
        while (i.hasNext())
        {
            WindowState curWinState = (WindowState) i.next();
    
            if (curWinState.equals(windowState))
            {
                result = true;
                break;
            }
        }
        
        if (log.isDebugEnabled()) {
            log.debug("RESULT: " + result);
            log.debug(Utility.strExit("isWindowStateAllowed"));
        } 
        
        return result;
    }


    /**
     * Set the portlet mode. This implementation is identical to the
     * WSRP4J-supplied class.
     */
    public void changePortletMode(PortletMode mode)
    {
        this.mode = mode;
    }


    /**
     * Set the portlet window state. This implementation is identical to the
     * WSRP4J-supplied class.
     */
    public void changePortletWindowState(WindowState state)
    {
        this.winState = state;
    }

      
    // ------------------------------------------------------ Protected Methods
    
    
    /**
     * Retrieves the root portlet handle for the current portlet. If the 
     * portlet is a producer-provided portlet, then the root handle is just 
     * the handle of the portlet itself.  If the portlet is a 
     * consumer-configured portlet, then the root handle is the handle of the 
     * producer-provided portlet that this portlet has been cloned from.
     */
    protected String getRootPortletHandle(PortletContext portletContext)
    {
        String handle = portletContext.getPortletHandle();
        
        try
        {
            Portlet p = this.provider.getPortletPool().get(handle);
            
            if (p instanceof ConsumerConfiguredPortlet)
            {
                handle = ((ConsumerConfiguredPortlet) p).getParentHandle();
            }
            
        }
        catch (WSRPException e)
        {
            e.printStackTrace(System.out);
        }
        
        return handle;
    }
    
    
    protected void readMarkupParams(MarkupParams markupParams)
    {
        // Retrieve the portlet mode
        this.mode = modeMapper.getPortletModeFromWsrpMode(
                this.rootPortletHandle, markupParams.getMode());

        // Retrieve the window state
        String wsrpWinState = markupParams.getWindowState();
        this.winState = WindowStates.getJsrPortletStateFromWsrpState(
                WindowStates.fromString(wsrpWinState));

        String[] currentMimeTypes = markupParams.getMimeTypes();
        
        if (currentMimeTypes != null)
        {
            this.mimeTypes = currentMimeTypes;
        }

        this.isSecure = markupParams.isSecureClientCommunication();        
    }
    
    
    /**
     * Return the supported Portlet Modes. These depend on the mime type of the
     * request.  This is where we've hooked our ModeMapper in to handle the
     * translation between WSRP modes and Portlet modes.
     */
    protected Iterator getSupportedPortletModes() 
    {
        ArrayList supportedModes = new ArrayList();
        
        try
        {
            // Use the DescriptionHandler to obtain the PortletDescription
            PortletDescription desc = this.provider.getDescriptionHandler()
                    .getPortletDescription(
                            this.portletContext.getPortletHandle(), 
                            null, 
                            null,
                            null);
            
            MarkupType[] markupTypes = desc.getMarkupTypes();
            
            for (int i = 0; i < markupTypes.length; i++)
            {
                String mimeType = markupTypes[i].getMimeType();
                
                if (mimeType.equalsIgnoreCase(this.mimeTypes[0]))
                {
                    String[] wsrpModes = markupTypes[i].getModes();

                    for (int j = 0; j < wsrpModes.length; j++) 
                    {
                        PortletMode mode = modeMapper.getPortletModeFromWsrpMode(
                                this.rootPortletHandle, wsrpModes[j]);
                        supportedModes.add(mode);
                    }
                    
                    break;
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace(System.out);
        }
        
        return supportedModes.iterator();
    }


    /** 
     * Return collection of supported JSR-168 window states.
     */
    protected Iterator getSupportedWindowStates() 
    {
        ArrayList supportedWinStates = new ArrayList();
    
        try 
        {
            // Use the DescriptionHandler to obtain the PortletDescription
            PortletDescription desc = this.provider.getDescriptionHandler().
                getPortletDescription(
                        portletContext.getPortletHandle(),
                        null,
                        null, 
                        null);
            
            MarkupType[] markupTypes = desc.getMarkupTypes();
            
            for (int i = 0; i < markupTypes.length; i++)
            {
                String mimeType = markupTypes[i].getMimeType();
                
                if (mimeType.equalsIgnoreCase(this.mimeTypes[0]))
                {
                    String[] winStates = markupTypes[i].getWindowStates();
                    
                    for (int j = 0; j < winStates.length; j++)
                    {
                        supportedWinStates.add(WindowStates
                                .getJsrPortletStateFromWsrpState(
                                        WindowStates.fromString(winStates[j])));
                    }
                    
                    break;
                }
            }                          
        }
        catch(Exception e) 
        {
            e.printStackTrace(System.out);
        }
        
        return supportedWinStates.iterator();
    }
}
