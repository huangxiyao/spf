package com.hp.frameworks.wpa.pluto.portalImpl;

import org.apache.pluto.PortletContainer;
import org.apache.pluto.PortletContainerException;
import org.apache.pluto.portalImpl.services.config.Config;
import org.apache.pluto.om.window.PortletWindow;
import org.apache.pluto.services.PortletContainerEnvironment;
import org.apache.pluto.services.log.Logger;
import org.apache.pluto.services.log.LogService;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.portlet.PortletException;
import java.util.Properties;
import java.io.IOException;

import com.hp.frameworks.wpa.pluto.portalImpl.RequestType;

public class DualPortalContainerImpl implements PortletContainer {
	private PortletContainer mStandalonePortletContainer = null;
	private PortletContainer mWsrpPortletContainer = null;
	private boolean mInitialized = false;
	private Logger mLog = null;

	public void init(String name, ServletConfig config, PortletContainerEnvironment portletContainerEnvironment, Properties properties) throws PortletContainerException {
		mLog = ((LogService)portletContainerEnvironment.getContainerService(LogService.class)).getLogger(getClass());

		long now = System.currentTimeMillis();

		String wsrpContainerClassName = Config.getParameters().getString("portletcontainer.entrance.impl.wsrp");
		if (wsrpContainerClassName != null) {
			try {
				mWsrpPortletContainer = (PortletContainer) Class.forName(wsrpContainerClassName).newInstance();
				mWsrpPortletContainer.init("wsrp-" + now + "-" + name, config, portletContainerEnvironment, properties);
				if (mLog.isInfoEnabled()) {
					mLog.info("Using WSRP container class: " + wsrpContainerClassName);
				}
			}
			catch (Exception e) {
				throw new PortletContainerException("Error instantiating WSRP portlet container", e);
			}
		}
		else {
			if (mLog.isInfoEnabled()) {
				mLog.info("WSRP container class not defined!");
			}
		}

		String standaloneContainerClassName = Config.getParameters().getString("portletcontainer.entrance.impl.standalone");
		if (standaloneContainerClassName != null) {
			try {
				mStandalonePortletContainer = (PortletContainer) Class.forName(standaloneContainerClassName).newInstance();
				mStandalonePortletContainer.init("standalone-" + now + "-" + name, config, portletContainerEnvironment, properties);
				if (mLog.isInfoEnabled()) {
					mLog.info("Using Standalone container class: " + standaloneContainerClassName);
				}
			}
			catch (Exception e) {
				throw new PortletContainerException("Error instantiating Standalone portlet container", e);
			}
		}
		else {
			if (mLog.isInfoEnabled()) {
				mLog.info("Standalone container class not defined!");
			}
		}

		mInitialized = true;
	}

	public void shutdown() throws PortletContainerException {
		Exception e = null;
		if (mStandalonePortletContainer != null) {
			try {
				mStandalonePortletContainer.shutdown();
			}
			catch (PortletContainerException e1) {
				e = e1;
			}
		}

		if (mWsrpPortletContainer != null) {
			try {
				mWsrpPortletContainer.shutdown();
			}
			catch (PortletContainerException e1) {
				e = e1;
			}
		}

		if (e != null) {
			if (e instanceof PortletContainerException) {
				throw (PortletContainerException) e;
			}
			else if (e instanceof RuntimeException) {
				throw (RuntimeException) e;
			}
			else {
				mLog.error("Unexpected error occured", e);
			}
		}
	}

	public void renderPortlet(PortletWindow portletWindow, HttpServletRequest request, HttpServletResponse response) throws PortletException, IOException, PortletContainerException {
		if (RequestType.isStandalone()) {
			mStandalonePortletContainer.renderPortlet(portletWindow, request, response);
		}
		else {
			mWsrpPortletContainer.renderPortlet(portletWindow, request, response);
		}
	}

	public void processPortletAction(PortletWindow portletWindow, HttpServletRequest request, HttpServletResponse response) throws PortletException, IOException, PortletContainerException {
		if (RequestType.isStandalone()) {
			mStandalonePortletContainer.processPortletAction(portletWindow, request, response);
		}
		else {
			mWsrpPortletContainer.processPortletAction(portletWindow, request, response);
		}
	}

	public void portletLoad(PortletWindow portletWindow, HttpServletRequest request, HttpServletResponse response) throws PortletException, PortletContainerException {
		if (RequestType.isStandalone()) {
			mStandalonePortletContainer.portletLoad(portletWindow, request, response);
		}
		else {
			mWsrpPortletContainer.portletLoad(portletWindow, request, response);
		}
	}

	public boolean isInitialized() {
		return mInitialized;
	}
}
