package com.hp.frameworks.wpa.wsrp4j.services.portletentityregistry;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import javax.servlet.ServletConfig;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pluto.om.common.ObjectID;
import org.apache.pluto.om.entity.PortletApplicationEntityList;
import org.apache.pluto.om.entity.PortletEntity;
import org.apache.pluto.portalImpl.services.portletentityregistry.PortletEntityRegistryService;
import org.apache.pluto.portalImpl.util.Properties;
import org.apache.wsrp4j.commons.util.Utility;

import com.hp.frameworks.wpa.wsrp4j.dao.portletentityregistry.PortletRegistryDAO;
import com.hp.frameworks.wpa.wsrp4j.dao.portletentityregistry.PortletRegistryDAOImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletApplicationEntityListImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletEntityImpl;
import com.opensymphony.oscache.base.NeedsRefreshException;


/**
 * <p>
 * This class is provided as a replacement for the Pluto-supplied
 * PortletEntityRegistryService. Pluto's implementation of this class makes use
 * of a XML file for portlet registration. This implementation uses a DBMS for
 * portlet registration and is therefore better suited to work in clustered
 * environments.
 * </p>
 * 
 * <p>
 * This class makes use of the OSCache GeneralCacheAdministrator to reduce the
 * number of trips to the database. Once the PortletApplicationEntityList is
 * retrieved the first time, it is stored in the cache -- all subsequent
 * requests for the list are retrieved from the cache. Only when the cache is
 * determined to be stale will data be reloaded from the DB. To ensure the
 * maximum use of the cache, the portlet application list should always be
 * retrieved via the protected getPortletAppList() method.
 * </p>
 * 
 * <p>
 * OSCache was chosen as the cache implementation because it can function in a
 * clustered environment. When a cache key is flushed on one system, all the
 * other systems in the cluster will automatically be notified that they should
 * flush the same key.
 * </p>
 */
public class WPAPortletEntityRegistryService extends
        PortletEntityRegistryService
{

	// ------------------------------------------------------ Private Constants    

    
    private static final String PORTLETCONTEXTS_FILE = 
        "/WEB-INF/data/portletcontexts.txt";
    
    
    // -------------------------------------------------------- Private Members
    
   
    // You'll never guess what this is for
    private static final Log log = 
        LogFactory.getLog(WPAPortletEntityRegistryService.class); 
    
    
    // ------------------------------------------------------ Protected Members
    
    protected String[] contextNames;
    
    
    // DAO for interacting with the portlet registry
    protected PortletRegistryDAO dao = new PortletRegistryDAOImpl();
    
    
    // Cache used for storing the portlet app list once it is loaded from 
    // the DB
    protected RegistryCache cache = RegistryCache.getInstance();
    
    
    // --------------------------------------------------------- Public Methods
    
    
    /**
     * This method is called automatically after the service is instantiated.
     * We're using it simply to pre-load the portlet registry from the 
     * database.
     */
    public void init(ServletConfig servletConfig, Properties properties)
            throws Exception
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("init"));
        } 
        
        InputStream stream = servletConfig.getServletContext()
                .getResourceAsStream(PORTLETCONTEXTS_FILE);
        
        this.contextNames = this.getPortletContexts(stream);
                
        load();
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("init"));
        }     
    }


    /**
     * Returns the complete portlet application entity list.
     */
    public PortletApplicationEntityList getPortletApplicationEntityList()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getPortletApplicationEntityList"));
        } 
        
        PortletApplicationEntityList result = this.getPortletAppList();
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getPortletApplicationEntityList"));
        } 
        
        return result;
    }


    /**
     * Returns the portlet entity with the given object ID.
     */
    public synchronized PortletEntity getPortletEntity(ObjectID objectId)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getPortletEntity"));
        } 
        
        PortletEntity result = 
            this.getPortletAppList().getPortletEntity(objectId);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getPortletEntity"));
        } 
        
        return result;
    }


    /**
     * Load the portlet app list from the database and store it in the local
     * cache.  This method is called only at init time.
     */
    public void load()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("load"));
        } 
    
        // Load the portlet app list from the database
        WPAPortletApplicationEntityListImpl portletAppList = 
            this.loadPortletAppList();
        
        // Store a copy of the list in the cache so that we don't
        // have to go back to the DB
        this.cache.putInCache(RegistryCache.PORTLET_REGISTRY, portletAppList);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("load"));
        }      
    }


    /**
     * Takes the cached copy of the portlet application list and persists it
     * back to the database.  This method doesn't appear to be invoked anywhere
     * but is included for the sake of completeness.
     */
    public void store()
    {        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("store"));
        } 
        
        WPAPortletApplicationEntityListImpl result = null;
        
        try
        {
            // Attempt to retrieve portlet app list from cache
            result = (WPAPortletApplicationEntityListImpl) this.cache
                    .getFromCache(RegistryCache.PORTLET_REGISTRY);
        }
        catch (NeedsRefreshException e)
        {       
            // If the cached version is stale, don't refresh, just use the
            // stale version
            result = (WPAPortletApplicationEntityListImpl) e.getCacheContent();
        }
        
        // Persist portlet app list to database
        dao.savePortletRegistry(result);
        
        // Flush cache so that everyone knows they need to reload the
        // portlet app list
        this.cache.flushEntry(RegistryCache.PORTLET_REGISTRY);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("store"));
        } 
    }


    /**
     * Not really sure what the heck this is supposed to do and as far as I can
     * tell it's never called, so we're not providing an implementation
     */
    public void refresh(PortletEntity portletEntity)
    {
        log.error("Method refresh() not implemented");
    }
    
    
    // ------------------------------------------------------ Protected Methods
    
    
    /**
     * Returns the cached copy of the portlet app list.  If we discover that
     * the cache is stale, the list is reloaded from the DB and put back
     * into the cache.
     */
    protected WPAPortletApplicationEntityListImpl getPortletAppList()
    {
        boolean updated = false;
        WPAPortletApplicationEntityListImpl result = null;
        
        try
        {
            result = (WPAPortletApplicationEntityListImpl) this.cache
                    .getFromCache(RegistryCache.PORTLET_REGISTRY);
        }
        catch (NeedsRefreshException e)
        {            
            try
            {
                result = this.loadPortletAppList();
            
                cache.putInCache(RegistryCache.PORTLET_REGISTRY, result);
                updated = true;
            }
            finally
            {
                if (!updated)
                {
                    cache.cancelUpdate(RegistryCache.PORTLET_REGISTRY);
                }
            }
        }
        
        return result;
    }    
            
    
    /**
     * Invokes the DAO in order to load the portlet app list from the DB.
     */
    protected WPAPortletApplicationEntityListImpl loadPortletAppList()
    {
        if (log.isDebugEnabled()) {
            log.debug("Reloading portlet registry from DB");
        }         

        return dao.loadPortletRegistry(this.contextNames);
    }
    
    
    /**
     * Takes the given copy of the portlet app list and persists it back
     * to the DB via the DAO.  Also flushes the cache so that all
     * subsequent requests for the portlet app list are forced to reload
     * it.
     */
    protected void savePortletAppList(
            WPAPortletApplicationEntityListImpl portletAppList)
    {
        this.dao.savePortletRegistry(portletAppList);
        this.cache.flushEntry(RegistryCache.PORTLET_REGISTRY);
    }
    
    
    protected void savePortletEntity(WPAPortletEntityImpl portletEntity)
    {
        this.dao.savePortletEntity(portletEntity);
        this.cache.flushEntry(RegistryCache.PORTLET_REGISTRY);
    }
    
    
    protected void deletePortletEntity(WPAPortletEntityImpl portletEntity)
    {
        //delete child portlet entities first
        List childHandles = this.dao.getChildPortletHandles(portletEntity);
        Iterator iter = childHandles.iterator();
        while(iter.hasNext())
        {
            String portletID = (String)iter.next();
            WPAPortletEntityImpl child = (WPAPortletEntityImpl) this.getPortletAppList().getPortletEntity(portletID);
            this.deletePortletEntity(child);
        }
        // then delete the portlet entity itself
        this.dao.deletePortletEntity(portletEntity);
        this.cache.flushEntry(RegistryCache.PORTLET_REGISTRY);
    }
    
    
	// -------------------------------------------------------- Private Methods
    
    
    private String[] getPortletContexts(InputStream portletContextsStream)
    {
        List contextNames = new ArrayList();
        
        if (portletContextsStream != null)
        {
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(portletContextsStream));
        
            try
            {
                while (reader.ready())
                {
                    String contextName = reader.readLine();
                    
                    if (contextName.startsWith("/"))
                    {
                        contextName = contextName.substring(1);
                    }
                    
                    contextNames.add(contextName);
                }
            }
            catch (IOException e) 
            { 
                // Nothing for us to do
            }
            finally 
            { 
                try 
                {
                    reader.close();
                }
                catch (IOException e) { }
            }
        }
        
        return (String[]) contextNames.toArray(new String[] {});
    }
}
