package com.hp.frameworks.wpa.pluto.portalImpl.servlet;

import org.apache.pluto.portalImpl.servlet.ServletResponseFactory;
import org.apache.pluto.portalImpl.servlet.ServletResponseImpl;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletConfig;
import java.io.PrintWriter;
import java.util.Map;

/**
 * Class to return the WPA-customized {@link StoredServletResponseImpl} object rather than the defacto
 * ServletResponseImpl which assumes use of the getWriter method while WebLogic uses getOutputStream.  This class is
 * configured in the FactoryManagerService.properties file.
 */
public class ServletResponseFactoryImpl implements ServletResponseFactory {
	public HttpServletResponse getServletResponse(HttpServletResponse response) {
		return new ServletResponseImpl(response);
	}

	public HttpServletResponse getStoredServletResponse(HttpServletResponse response, PrintWriter printWriter) {
		return new StoredServletResponseImpl(response, printWriter);
	}

	public void init(ServletConfig config, Map map) throws Exception {
	}

	public void destroy() throws Exception {
	}
}
