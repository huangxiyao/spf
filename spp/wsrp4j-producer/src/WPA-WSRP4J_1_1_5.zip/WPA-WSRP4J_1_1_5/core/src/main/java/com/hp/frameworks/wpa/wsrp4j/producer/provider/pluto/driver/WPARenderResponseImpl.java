package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oasis.names.tc.wsrp.v1.types.PortletDescription;

import org.apache.pluto.core.impl.RenderResponseImpl;
import org.apache.pluto.om.entity.PortletEntity;
import org.apache.pluto.om.window.PortletWindow;
import org.apache.wsrp4j.commons.exception.WSRPException;
import org.apache.wsrp4j.commons.producer.interfaces.ProviderAccess;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Provider;


/**
 * <p>
 * We are forced to provide a custom implementation of this class because
 * one of the WSRP4J developers got lazy.  In the WSRP4J-provided 
 * implementation (WSRPRenderResponseImpl), the ProviderFactoryImpl class
 * is directly instantiated and used to construct an instance of the
 * Provider class.  Since we need to provide our own implementation of 
 * the Provider, we also need to ensure that our class is used through-out
 * the system.
 * </p>
 * 
 * <p>
 * Instead of directly instantiating the provider factory, the constructor
 * for this class makes use of the ProviderAccess class which will look-up
 * the factory that has been configured in the /classes/WSRPServices.properties
 * file and use it to instantiate the appropriate Provider (this is what the 
 * WSRP4J guys should have done in the first place!).  If the 
 * WSRPRenderResponseImpl is ever fixed, we will be able to remove this class 
 * and it's associated factory.
 * </p>
 * 
 * <p>
 * Since the WSRP4J-provided implementation of this class makes use of
 * private member variables, we are again forced to reimplement the class
 * in it's entirety.  The only method that has changed is the constructor --
 * all other methods are cut-n-pasted from the WSRPRenderResponseImpl class.
 * </p>
 * 
 * <p>
 * This class is not directly instantiated, it is created by the 
 * WPARenderResponseFactoryImpl.  The factory is then registered in 
 * the /config/services/FactoryManagerService.properties file.
 * </p>
 *
 */
public class WPARenderResponseImpl extends RenderResponseImpl
{
    
	// ------------------------------------------------------ Protected Members
    
    
    // Reference to the provider
    protected Provider provider;

    // Portlet entity we are associated with
    protected final PortletEntity portletEntity;


	// ----------------------------------------------------------- Constructors
    
    
    public WPARenderResponseImpl(PortletWindow portletWindow,
            HttpServletRequest servletRequest,
            HttpServletResponse servletResponse,
            boolean containerSupportsBuffering)
    {
        super(portletWindow, servletRequest, servletResponse,
                containerSupportsBuffering);
        
        try
        {
            this.provider = ProviderAccess.getProvider();
        }
        catch (WSRPException e)
        {
            e.printStackTrace(System.out);
        }

        this.portletEntity = portletWindow.getPortletEntity();
    }


	// --------------------------------------------------------- Public Methods
    
    
    /**
     * Returns the encoded version of a URL string
     * 
     * @param url String representing a URL
     * @return java.lang.String representing an encoded URL
     */
    public String encodeURL(String url)
    {
        String resourceUrl = "";
        try
        {
            PortletDescription desc = provider.getDescriptionHandler()
                    .getPortletDescription(portletEntity.getId().toString());

            if (url.indexOf("://") != -1)
            {
                if (desc.getDoesUrlTemplateProcessing().booleanValue())
                {
                    // TODO: create url by template processing
                }
                else
                {
                    resourceUrl = provider.getURLComposer().createResourceURL(
                            url, false, false, null, null, null);
                }
            }
            else
            {
                HttpServletRequest request = this.getHttpServletRequest();
                StringBuffer buffer = new StringBuffer();
                buffer.append(request.getScheme());
                buffer.append("://");
                buffer.append(request.getServerName());
                
                if (request.getServerPort() != 80)
                {
                    buffer.append(':');
                    buffer.append(request.getServerPort());
                }
                
                String base = buffer.toString();

                if (desc.getDoesUrlTemplateProcessing().booleanValue())
                {
                    // TODO: create url by template processing
                }
                else
                {
                    resourceUrl = provider.getURLComposer().createResourceURL(
                            base + url, false, false, null, null, null);
                }
            }
        }
        catch (WSRPException e)
        {
            //TODO: log error
        }
        return resourceUrl;
    }


    /**
     * Provides a specific namespace for a name/key
     * 
     * @param aValue String representing a name or a key
     * @return java.lang.String encoded name or key
     */
    public String encodeNamespace(String aValue)
    {
        // TODO: template processing
        return provider.getURLComposer().createNamespacedToken(aValue, null);
    }
}
