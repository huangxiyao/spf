package com.hp.frameworks.wpa.pluto.portalImpl;

import org.apache.pluto.factory.RenderResponseFactory;
import org.apache.pluto.om.window.PortletWindow;

import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Factory which determines the type of RenderResponseFactory to use based on the incoming request type being a
 * standalone portlet request or WSRP request.
 *
 * @see RequestType
 * @see 
 *
 */
public class DualRenderResponseFactoryImpl extends DualFactory implements RenderResponseFactory {

	public RenderResponse getRenderResponse(PortletWindow portletWindow, HttpServletRequest request, HttpServletResponse response, boolean b) {
		if (RequestType.isStandalone()) {
			return ((RenderResponseFactory) mStandaloneFactory).getRenderResponse(portletWindow, request, response, b);
		}
		else {
			return ((RenderResponseFactory) mWsrpFactory).getRenderResponse(portletWindow, request, response, b);
		}
	}

}
