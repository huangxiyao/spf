package com.hp.frameworks.wpa.pluto.portalImpl;

import org.apache.pluto.portalImpl.servlet.ServletRequestFactory;
import org.apache.pluto.om.window.PortletWindow;

import javax.servlet.http.HttpServletRequest;

/**
 * Factory which determines the type of ServletRequestFactory to use based on the incoming request type being a
 * standalone portlet request or WSRP request.
 */
public class DualServletRequestFactoryImpl extends DualFactory implements ServletRequestFactory {
	public HttpServletRequest getServletRequest(HttpServletRequest request, PortletWindow portletWindow) {
		if (RequestType.isStandalone()) {
			return ((ServletRequestFactory) mStandaloneFactory).getServletRequest(request, portletWindow);
		}
		else {
			return ((ServletRequestFactory) mWsrpFactory).getServletRequest(request, portletWindow);
		}
	}
}
