package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletRegistrationFilter;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletRegistrationFilterWriter;

import com.hp.frameworks.wpa.wsrp4j.services.consumerportletregistry.WPAPortletRegistrationFilterImpl;


/**
 * <p>
 * This class is provided for users that want to make use of the DBMS-based
 * consumer portlet registry. The consumer portlet registry is accessed through
 * the PortletRegistrationFilter and PortletRegistrationFilterWriter interfaces
 * so we have overriden the getPortletRegistrationFilter() and
 * getPortletRegistrationFilterWriter() methods to return our custom
 * implementation.
 * </p>
 * 
 * <p>
 * Note that this class extends to WPAProviderImpl so we automatically inherit
 * all of the behavior of that class (see the comments associated with that
 * class for a discussion of what it does),
 * </p>
 * 
 * <p>
 * This class is not directly instantiated, it is created by the 
 * WPADBProviderFactoryImpl.  The factory is then registered in 
 * the /WEB-INF/classes/WSRPServices.properties file.
 * </p>
 */
public class WPADBProviderImpl extends WPAProviderImpl
{

	// --------------------------------------------------------- Public Methods   
    
    
    public PortletRegistrationFilterWriter getPortletRegistrationFilterWriter()
    {
        return WPAPortletRegistrationFilterImpl.getWriter();
    }


    public PortletRegistrationFilter getPortletRegistrationFilter()
    {
        return WPAPortletRegistrationFilterImpl.getReader();
    }
}
