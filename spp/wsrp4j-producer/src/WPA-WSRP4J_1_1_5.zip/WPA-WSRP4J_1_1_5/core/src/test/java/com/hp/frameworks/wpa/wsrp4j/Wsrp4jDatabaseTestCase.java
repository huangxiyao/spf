package com.hp.frameworks.wpa.wsrp4j;

import com.javaranch.unittest.helper.sql.pool.JNDIUnitTestHelper;
import org.dbunit.DatabaseTestCase;
import org.dbunit.ext.mssql.MsSqlConnection;
import org.dbunit.ext.mssql.InsertIdentityOperation;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.operation.DatabaseOperation;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 * Created by IntelliJ IDEA.
 * User: arnoldmi
 * Date: Mar 24, 2006
 * Time: 2:48:13 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class Wsrp4jDatabaseTestCase extends DatabaseTestCase
{
	public Wsrp4jDatabaseTestCase(String name) {
		super(name);
	}

	protected void setUp() throws Exception
	{
		if(JNDIUnitTestHelper.notInitialized()){
			JNDIUnitTestHelper.init(this.getClass().getClassLoader().getResource("jndi_unit_test_helper.properties").getPath());
		}

		super.setUp();
	}

	protected IDatabaseConnection getConnection() throws Exception
	{
		//DataSource pool = (DataSource) new InitialContext().lookup("java:comp/env/jdbc/wsrp4j");
		Context ctx = new InitialContext(); //bd
		DataSource pool = (DataSource) ctx.lookup("java:comp/env/jdbc/wsrp4j"); //bd
		//ctx.close();
		return new MsSqlConnection(pool.getConnection());
	}

	protected IDataSet getDataSet() throws Exception
	{
		return new FlatXmlDataSet(Thread.currentThread().getContextClassLoader().getResourceAsStream("wsrp4j_dbunit_setup.xml"));
		// return new FlatXmlDataSet(Thread.currentThread().getContextClassLoader().getResourceAsStream("wsrp4j_db.xml"));
	}


	protected DatabaseOperation getSetUpOperation() throws Exception
	{
		return InsertIdentityOperation.CLEAN_INSERT;
	}

	protected DatabaseOperation getTearDownOperation() throws Exception
	{
		return InsertIdentityOperation.DELETE_ALL;
	}

}
