package com.hp.frameworks.wpa.wsrp4j.services.portletentityregistry;

import com.hp.frameworks.wpa.wsrp4j.Wsrp4jDatabaseTestCase;
import junit.framework.Test;
import junit.framework.TestSuite;
import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.SortedTable;
import org.dbunit.dataset.filter.DefaultColumnFilter;
import org.dbunit.dataset.xml.FlatXmlDataSet;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * WPAPortletPoolImpl Tester.
 *
 * @author <Authors name>
 * @since <pre>04/11/2006</pre>
 * @version 1.0
 */
public class TestWPAPortletPoolImpl extends Wsrp4jDatabaseTestCase {
	public TestWPAPortletPoolImpl(String name) {
		super(name);
	}

	public static Test suite() {
		return new TestSuite(TestWPAPortletPoolImpl.class);
	}

	public void testDestroy() throws Exception
	{
		String handle = "0.15.244.195.146_1142973175875_1";

		WPAPortletPoolImpl pool = new WPAPortletPoolImpl();
		boolean destroyed = pool.destroy(handle);

		assertTrue(destroyed);

		// compare to database
		compareData("destroy_expected.xml");
	}

	public void testDestroySeveral() throws Exception
	{
		String handle1 = "0.15.244.195.146_1142973175875_1";
		String handle2 = "1.4";

		ArrayList handles = new ArrayList();
		handles.add(handle1);
		handles.add(handle2);

		WPAPortletPoolImpl pool = new WPAPortletPoolImpl();
		Iterator results = pool.destroySeveral(handles.iterator());

		assertNotNull(results);
		assertTrue(results.hasNext());

		// compare to database
		compareData("destroySeveral_expected.xml");

	}

	public void testClone() throws Exception
	{

	}

	public void testSetGetProvider() throws Exception {
		//TODO: Test goes here...
	}

	public void testGetAllProducerOfferedPortlets() throws Exception {
		//TODO: Test goes here...
	}

	public void testGetAllConsumerConfiguredPortlets() throws Exception {
		//TODO: Test goes here...
	}

	public void testGet() throws Exception {
		//TODO: Test goes here...
	}

	/**
	 * Performs comparison of actual database entries to an FlatXmlDataSet.
	 *
	 * @param dataSetResource resource containing a FlatXmlDataSet
	 * @throws Exception
	 */
	private void compareData(String dataSetResource) throws Exception
	{
		// ================================================================== compare db actual state to expected state
		/*
		 * Have to filter the actual data to exclude columns that aren't testable.  Also have to use SortedTable
		 * in assertions due to 'order by' clause in SQL select statements for actual data.
		 */
		IDataSet databaseDataSet = getConnection().createDataSet();
		ITable actualTable = databaseDataSet.getTable("WSRP_PORTLET");

		// Load expected portlet data from XML dataset
		IDataSet expectedDataSet = new FlatXmlDataSet(
				Thread.currentThread().getContextClassLoader().getResourceAsStream(dataSetResource)
			);
		ITable expectedTable = expectedDataSet.getTable("WSRP_PORTLET");
		ITable filteredTable = DefaultColumnFilter.excludedColumnsTable(
				actualTable, new String[] {"ID","PARENT_HANDLE","APPLICATION"}
			);
		// Assert actual database table match expected table
		Assertion.assertEquals(new SortedTable(expectedTable), new SortedTable(filteredTable, expectedTable.getTableMetaData()));

		// Load expected preference data from XML dataset
		actualTable = databaseDataSet.getTable("WSRP_PREFERENCE");
		expectedTable = expectedDataSet.getTable("WSRP_PREFERENCE");
		filteredTable = DefaultColumnFilter.excludedColumnsTable(
				actualTable, new String[] {"ID","PORTLET"}
			);
		Assertion.assertEquals(new SortedTable(expectedTable), new SortedTable(filteredTable, expectedTable.getTableMetaData()));

		// Load expected preference values data from XML dataset
		actualTable = databaseDataSet.getTable("WSRP_PREFERENCE_VALUE");
		expectedTable = expectedDataSet.getTable("WSRP_PREFERENCE_VALUE");
		filteredTable = DefaultColumnFilter.excludedColumnsTable(
				actualTable, new String[] {"ID","PREFERENCE","PREFERENCE_IDX"}
			);
		Assertion.assertEquals(new SortedTable(expectedTable), new SortedTable(filteredTable, expectedTable.getTableMetaData()));
	}

}
