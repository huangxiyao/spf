package com.hp.frameworks.wpa.wsrp4j.dao.portletentityregistry;

import com.hp.frameworks.wpa.wsrp4j.Wsrp4jDatabaseTestCase;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletApplicationEntityListImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletEntityImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletApplicationEntityImpl;
import com.hp.frameworks.wpa.wsrp4j.om.entity.impl.WPAPortletEntityListImpl;
import com.hp.frameworks.wpa.wsrp4j.om.common.impl.WPAPreferenceImpl;
import com.hp.frameworks.wpa.wsrp4j.om.common.impl.WPAPreferenceSetImpl;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.SortedTable;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.dataset.filter.DefaultColumnFilter;
import org.dbunit.Assertion;
import org.apache.pluto.portalImpl.util.ObjectID;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Test cases targeting the PortletRegistryDAOImpl.
 */
public class TestPortletRegistryDAOImpl extends Wsrp4jDatabaseTestCase
{
	public TestPortletRegistryDAOImpl(String name)
	{
		super(name);
	}

	/**
	 * Tests the loading of the portlet registry.
	 *
	 * @throws Exception
	 */
	public void testLoadPortletRegistry() throws Exception
	{
		PortletRegistryDAOImpl dao = new PortletRegistryDAOImpl();
		WPAPortletApplicationEntityListImpl portletApplicationEntityList = null;

		portletApplicationEntityList = dao.loadPortletRegistry();
		assertFalse(portletApplicationEntityList.isEmpty());
		assertEquals(3, portletApplicationEntityList.size());

		portletApplicationEntityList =
				dao.loadPortletRegistry(new String[] {"wsrp4j-testportlet"});
		assertFalse(portletApplicationEntityList.isEmpty());
		assertEquals(1, portletApplicationEntityList.size());

		portletApplicationEntityList =
				dao.loadPortletRegistry(new String[] {"wsrp4j-testportlet2", "wsrp4j-testportlet3"});

		assertFalse(portletApplicationEntityList.isEmpty());
		assertEquals(2, portletApplicationEntityList.size());
	}


	/**
	 * Tests the saving of both a new portlet entity (SQL Insert) as well as an existing portlet entity (SQL Update).
	 *
	 * @throws Exception
	 */
	public void testSavePortletEntity() throws Exception
	{
		String definitionId = "wsrp4j-testportlet.WSRP4JTestPortlet";
		String portletObjectId = "6";
		String parentHandle = "0.1";
		String applicationObjectId = "0";
		String prefName = "testPref";

		// =================================================================================== load portlet application
		PortletRegistryDAOImpl dao = new PortletRegistryDAOImpl();
		WPAPortletApplicationEntityListImpl portletApplicationEntityList = dao.loadPortletRegistry();
		WPAPortletApplicationEntityImpl portletApp =
				(WPAPortletApplicationEntityImpl)portletApplicationEntityList.get(
						ObjectID.createFromString(applicationObjectId)
				);
		assertNotNull(portletApp);
		assertEquals(portletApp.getId(), applicationObjectId);
		assertFalse(((WPAPortletEntityListImpl)portletApp.getPortletEntityList()).isEmpty());

		// TEST NEW PORTLET ENTITY INSERT
		WPAPortletEntityImpl portlet = new WPAPortletEntityImpl();
		portlet.setDefinitionId(definitionId);
		portlet.setId(portletObjectId);
		portlet.setParentHandle(parentHandle);
		portlet.setPortletApplicationEntity(portletApp);

		dao.savePortletEntity(portlet);

		assertNotNull(portlet.getRegistryId());
		// assertNotNull(portlet.getPortletDefinition()); TODO why is this failing?  NPE at portletApp.getPortletApplicationDefinition()

		// TEST EXISTING PORTLET ENTITY UPDATE
		((WPAPreferenceSetImpl)portlet.getPreferenceSet()).add(prefName, new ArrayList());
		dao.savePortletEntity(portlet);

		WPAPreferenceImpl pref = (WPAPreferenceImpl) ((WPAPreferenceSetImpl)portlet.getPreferenceSet()).get(prefName);
		assertNotNull(pref);
		assertNotNull(pref.getRegistryId());

		compareData("savePortletEntity_expected.xml");
	}

	/**
	 * Tests update of an existing portlet registry.  Validates cascade saving of entire object graph.
	 *
	 * @throws Exception
	 */
	public void testSavePortletRegistry() throws Exception
	{
		// values from savePortletEntity_expected.xml
		String definitionId = "wsrp4j-testportlet.WSRP4JTestPortlet";
		String portletObjectId = "6";
		String applicationObjectId = "0";
		String prefName = "testPref";

		// =================================================================================== load portlet application
		PortletRegistryDAOImpl dao = new PortletRegistryDAOImpl();
		WPAPortletApplicationEntityListImpl portletApplicationEntityList = dao.loadPortletRegistry();
		WPAPortletApplicationEntityImpl portletApp =
				(WPAPortletApplicationEntityImpl)portletApplicationEntityList.get(
						ObjectID.createFromString(applicationObjectId)
				);
		assertNotNull(portletApp);
		assertEquals(portletApp.getId(), applicationObjectId);
		assertFalse(((WPAPortletEntityListImpl)portletApp.getPortletEntityList()).isEmpty());

		// ======================================================================================= create a new portlet
		WPAPortletEntityImpl portletEntity = new WPAPortletEntityImpl();
		portletEntity.setDefinitionId(definitionId);
		portletEntity.setId(portletObjectId);
		portletEntity.setPortletApplicationEntity(portletApp);

		// ==================================================================================== create a new preference
		WPAPreferenceImpl preferenceImpl = new WPAPreferenceImpl();
		preferenceImpl.setName(prefName);
		preferenceImpl.setReadOnly("false");

		// ============================================================================== create a new preference value
		ArrayList values = new ArrayList();
		values.add("testValue1");
		values.add("testValue2");

		preferenceImpl.setValues(values); // add the values to the preference
		((WPAPreferenceSetImpl)portletEntity.getPreferenceSet()).add(preferenceImpl); // add the preference to the portlet
		assertNotNull(portletEntity.getPreferenceSet());
		assertTrue(((WPAPreferenceSetImpl)portletEntity.getPreferenceSet()).size() > 0);
		((WPAPortletEntityListImpl)portletApp.getPortletEntityList()).add(portletEntity); // add the portlet to the app

		// ======================================================================================== persist the registry
		dao.savePortletRegistry(portletApplicationEntityList);

		assertNotNull(portletEntity.getPreferenceSet());
		assertTrue(((WPAPreferenceSetImpl)portletEntity.getPreferenceSet()).size() > 0);

		assertNotNull("",portletEntity.getRegistryId());
		assertNotNull(preferenceImpl.getRegistryId());
		Iterator iter = preferenceImpl.getValues();
		int count = 0;
		while(iter.hasNext())
		{
			iter.next();
			count++;
		}
		assertFalse(count==0);
		assertTrue(count==2);

		compareData("savePortletRegistry_expected.xml");
	}

	/**
	 * Performs comparison of actual database entries to an FlatXmlDataSet.
	 * 
	 * @param dataSetResource resource containing a FlatXmlDataSet
	 * @throws Exception
	 */
	private void compareData(String dataSetResource) throws Exception
	{
		// ================================================================== compare db actual state to expected state
		/*
		 * Have to filter the actual data to exclude columns that aren't testable.  Also have to use SortedTable
		 * in assertions due to 'order by' clause in SQL select statements for actual data.
		 */
		IDataSet databaseDataSet = getConnection().createDataSet();
		ITable actualTable = databaseDataSet.getTable("WSRP_PORTLET");

		// Load expected portlet data from XML dataset
		IDataSet expectedDataSet = new FlatXmlDataSet(
				Thread.currentThread().getContextClassLoader().getResourceAsStream(dataSetResource)
			);
		ITable expectedTable = expectedDataSet.getTable("WSRP_PORTLET");
		ITable filteredTable = DefaultColumnFilter.excludedColumnsTable(
				actualTable, new String[] {"ID","PARENT_HANDLE","APPLICATION"}
			);
		// Assert actual database table match expected table
		Assertion.assertEquals(new SortedTable(expectedTable), new SortedTable(filteredTable, expectedTable.getTableMetaData()));

		// Load expected preference data from XML dataset
		actualTable = databaseDataSet.getTable("WSRP_PREFERENCE");
		expectedTable = expectedDataSet.getTable("WSRP_PREFERENCE");
		filteredTable = DefaultColumnFilter.excludedColumnsTable(
				actualTable, new String[] {"ID","PORTLET"}
			);
		Assertion.assertEquals(new SortedTable(expectedTable), new SortedTable(filteredTable, expectedTable.getTableMetaData()));

		// Load expected preference values data from XML dataset
		actualTable = databaseDataSet.getTable("WSRP_PREFERENCE_VALUE");
		expectedTable = expectedDataSet.getTable("WSRP_PREFERENCE_VALUE");
		filteredTable = DefaultColumnFilter.excludedColumnsTable(
				actualTable, new String[] {"PREFERENCE","PREFERENCE_IDX"}
			);
		Assertion.assertEquals(new SortedTable(expectedTable), new SortedTable(filteredTable, expectedTable.getTableMetaData()));
	}


}
