package com.hp.frameworks.wpa.wsrp4j.dao.consumerportletregistry;

import com.hp.frameworks.wpa.wsrp4j.Wsrp4jDatabaseTestCase;
import junit.framework.Test;
import junit.framework.TestSuite;
import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.SortedTable;
import org.dbunit.dataset.filter.DefaultColumnFilter;
import org.dbunit.dataset.xml.FlatXmlDataSet;

import java.util.List;

/**
 * ConsumerPortletRegistryDAOImpl Tester.
 *
 * @author <Authors name>
 * @since <pre>04/11/2006</pre>
 * @version 1.0
 */
public class TestConsumerPortletRegistryDAOImpl extends Wsrp4jDatabaseTestCase
{
	public TestConsumerPortletRegistryDAOImpl(String name) {
		super(name);
	}

	public static Test suite() {
		return new TestSuite(TestConsumerPortletRegistryDAOImpl.class);
	}

	public void testLoadRegistrations()
	{
		String handle = "15.244.195.146_1142973170937_0";
		String expectedPortletHandle = "0.15.244.195.146_1142973175875_1";

		// ============================================================================================== positive test
		ConsumerPortletRegistryDAOImpl dao = new ConsumerPortletRegistryDAOImpl();
		List registrations = dao.loadRegistrations(handle);

		assertNotNull(registrations);
		assertFalse(registrations.isEmpty());
		assertEquals(1, registrations.size());

		String portletHandle = (String)registrations.get(0);
		assertEquals(portletHandle, expectedPortletHandle);

		// ============================================================================================== negative test
		registrations = dao.loadRegistrations("asdf");
		assertTrue(registrations.isEmpty());
	}

	public void testSaveRegistration() throws Exception
	{
		String regHandle = "testRegHandle";
		String portletHandle = "testPortletHandle";

		ConsumerPortletRegistryDAOImpl dao = new ConsumerPortletRegistryDAOImpl();
		dao.saveRegistration(regHandle, portletHandle);

		compareData("saveRegistration_cp_expected.xml");
	}

	public void testDeleteRegistration() throws Exception
	{
		String regHandle = "15.244.195.146_1142973170937_0";
		String portletHandle = "0.15.244.195.146_1142973175875_1";

		ConsumerPortletRegistryDAOImpl dao = new ConsumerPortletRegistryDAOImpl();
		dao.deleteRegistration(regHandle, portletHandle);

		List registrations = dao.loadRegistrations(regHandle);
		assertTrue(registrations.isEmpty());
	}

	public void testDeleteRegistrations()
	{
		String regHandle = "15.244.195.146_1142973170937_0";

		ConsumerPortletRegistryDAOImpl dao = new ConsumerPortletRegistryDAOImpl();
		dao.deleteRegistrations(regHandle);

		List registrations = dao.loadRegistrations(regHandle);
		assertTrue(registrations.isEmpty());

	}

	/**
	 * Performs comparison of actual database entries to an FlatXmlDataSet.
	 *
	 * @param dataSetResource resource containing a FlatXmlDataSet
	 * @throws Exception
	 */
	private void compareData(String dataSetResource) throws Exception
	{
		// ================================================================== compare db actual state to expected state
		/*
		 * Have to filter the actual data to exclude columns that aren't testable.  Also have to use SortedTable
		 * in assertions due to 'order by' clause in SQL select statements for actual data.
		 */
		IDataSet databaseDataSet = getConnection().createDataSet();
		ITable actualTable = databaseDataSet.getTable("WSRP_CONSUMER_PORTLET");

		// Load expected portlet data from XML dataset
		IDataSet expectedDataSet = new FlatXmlDataSet(
				Thread.currentThread().getContextClassLoader().getResourceAsStream(dataSetResource)
			);
		ITable expectedTable = expectedDataSet.getTable("WSRP_CONSUMER_PORTLET");
		ITable filteredTable = DefaultColumnFilter.excludedColumnsTable(
				actualTable, new String[] {"ID"}
			);
		// Assert actual database table match expected table
		Assertion.assertEquals(new SortedTable(expectedTable), new SortedTable(filteredTable, expectedTable.getTableMetaData()));
	}

}
