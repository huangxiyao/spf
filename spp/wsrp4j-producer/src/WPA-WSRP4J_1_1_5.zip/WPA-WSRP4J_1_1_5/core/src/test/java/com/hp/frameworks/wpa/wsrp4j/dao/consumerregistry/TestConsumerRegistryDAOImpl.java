package com.hp.frameworks.wpa.wsrp4j.dao.consumerregistry;

import com.hp.frameworks.wpa.wsrp4j.Wsrp4jDatabaseTestCase;
import junit.framework.Test;
import junit.framework.TestSuite;
import org.apache.wsrp4j.commons.producer.driver.RegistrationImpl;
import org.apache.wsrp4j.commons.producer.interfaces.Registration;
import org.apache.wsrp4j.commons.util.HandleGenerator;
import org.apache.wsrp4j.commons.util.impl.HandleGeneratorFactoryImpl;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.SortedTable;
import org.dbunit.dataset.filter.DefaultColumnFilter;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.Assertion;
import oasis.names.tc.wsrp.v1.types.RegistrationContext;
import oasis.names.tc.wsrp.v1.types.RegistrationData;

import java.util.List;

/**
 * Test cases targeting the ConsumerRegistryDAOImpl.
 */
public class TestConsumerRegistryDAOImpl extends Wsrp4jDatabaseTestCase
{
	private HandleGenerator handleGenerator = new HandleGeneratorFactoryImpl().getHandleGenerator();

	public TestConsumerRegistryDAOImpl(String name) {
		super(name);
	}

	public static Test suite() {
		return new TestSuite(TestConsumerRegistryDAOImpl.class);
	}

	/**
	 * Tests save of new consumer registration
	 *
	 * @throws Exception
	 */
	public void testSaveRegistration() throws Exception
	{
		String consumerName = "Unit Test Consumer Name";
		String consumerAgent = "Unit Test Consumer Agent";
		String handle = this.handleGenerator.generateHandle();
		boolean methodGetSupported = false;

		ConsumerRegistryDAO dao = new ConsumerRegistryDAOImpl();
		Registration registration = new RegistrationImpl();
		RegistrationContext registrationContext = new RegistrationContext();
		RegistrationData registrationData = new RegistrationData();

		registrationContext.setRegistrationHandle(handle);
		registrationContext.setRegistrationState(null);
		registrationContext.setExtensions(null);

		registrationData.setMethodGetSupported(methodGetSupported);
		registrationData.setConsumerName(consumerName);
		registrationData.setConsumerAgent(consumerAgent);

		registration.setRegistrationContext(registrationContext);
		registration.setRegistrationData(registrationData);

		dao.saveRegistration(registration);

		compareData("saveRegistration_expected.xml");

	}

	/**
	 * Test loading of an individual consumer registration
	 */
	public void testLoadRegistration()
	{
		String consumerName = "WSRP4J Swing Consumer";
		String consumerAgent = "WSRP4J Swing Consumer";
		String handle = "15.244.193.34_1141828924140_0";
		boolean methodGetSupported = false;

		ConsumerRegistryDAO dao = new ConsumerRegistryDAOImpl();
		Registration registration = dao.loadRegistration(handle);

		assertNotNull(registration);
		assertTrue(registration.getRegistrationContext().getRegistrationHandle().equals(handle));
		assertTrue(registration.getRegistrationData().getConsumerAgent().equals(consumerAgent));
		assertTrue(registration.getRegistrationData().getConsumerName().equals(consumerName));
		assertFalse(registration.getRegistrationData().isMethodGetSupported());

		// ============================================================================================= negative test
		registration = dao.loadRegistration("asdf");
		assertNull(registration);
	}

	/**
	 * Test loading of all consumer registrations
	 */
	public void testLoadAllRegistrations()
	{
		List registrations;
		ConsumerRegistryDAO dao = new ConsumerRegistryDAOImpl();
		registrations = dao.loadAllRegistrations();

		assertNotNull(registrations);
		assertFalse(registrations.isEmpty());
		assertEquals(10,registrations.size());

	}

	/**
	 * Test deletion of an individual consumer registration
	 */
	public void testDeleteRegistration()
	{
		String handle = "15.244.193.34_1141828924140_0";

		ConsumerRegistryDAO dao = new ConsumerRegistryDAOImpl();
		dao.deleteRegistration(handle);

		Registration registration = dao.loadRegistration(handle);
		assertNull(registration);

		List registrations = dao.loadAllRegistrations();
		assertEquals(9,registrations.size());

		// ============================================================================================== negative test
		dao.deleteRegistration("asdf");
		registrations = dao.loadAllRegistrations();
		assertEquals(9, registrations.size());
	}

	/**
	 * Performs comparison of actual database entries to an FlatXmlDataSet.
	 *
	 * @param dataSetResource resource containing a FlatXmlDataSet
	 * @throws Exception
	 */
	private void compareData(String dataSetResource) throws Exception
	{
		// ================================================================== compare db actual state to expected state
		/*
		 * Have to filter the actual data to exclude columns that aren't testable.  Also have to use SortedTable
		 * in assertions due to 'order by' clause in SQL select statements for actual data.
		 */
		IDataSet databaseDataSet = getConnection().createDataSet();
		ITable actualTable = databaseDataSet.getTable("WSRP_CONSUMER");

		// Load expected portlet data from XML dataset
		IDataSet expectedDataSet = new FlatXmlDataSet(
				Thread.currentThread().getContextClassLoader().getResourceAsStream(dataSetResource)
			);
		ITable expectedTable = expectedDataSet.getTable("WSRP_CONSUMER");
		ITable filteredTable = DefaultColumnFilter.excludedColumnsTable(
				actualTable, new String[] {"HANDLE"}
			);
		// Assert actual database table match expected table
		Assertion.assertEquals(new SortedTable(expectedTable), new SortedTable(filteredTable, expectedTable.getTableMetaData()));
	}
}
