package com.hp.frameworks.wpa.wsrp4j.util;

import javax.portlet.PortletMode;
import junit.framework.TestCase;

public class TestModeMapper extends TestCase
{
    private final static String HANDLE = "0.0";
    
    // ----------------------------------------------------------- Constructors
    
    
    public TestModeMapper(String testName)
    {
        super(testName);
    }
    
    
	// --------------------------------------------------------- Public Methods


    public void testWsrpModeFromPortletMode()
    {
        String wsrpMode = null;
        
        ModeMapper mapper = ModeMapper.getInstance();        
        assertNotNull(mapper);
        
        wsrpMode = mapper.getWsrpModeFromPortletMode(HANDLE, "preview");
        assertEquals("wsrp:preview", wsrpMode);
        
        wsrpMode = mapper.getWsrpModeFromPortletMode(HANDLE, "vignette:preview");
        assertEquals("vignette:preview", wsrpMode);

        wsrpMode = mapper.getWsrpModeFromPortletMode(HANDLE, "config");
        assertEquals("vignette:config", wsrpMode);

        wsrpMode = mapper.getWsrpModeFromPortletMode(HANDLE, "help");
        assertEquals("vignette:help", wsrpMode);
    }


    public void testPortletModeFromWsrpMode()
    {
        PortletMode portletMode = null;
        
        ModeMapper mapper = ModeMapper.getInstance();        
        assertNotNull(mapper);
        
        portletMode = mapper.getPortletModeFromWsrpMode(HANDLE, "wsrp:preview");
        assertEquals(new PortletMode("preview"), portletMode);
        
        portletMode = mapper.getPortletModeFromWsrpMode(HANDLE, "vignette:preview");
        assertEquals(new PortletMode("vignette:preview"), portletMode);

        portletMode = mapper.getPortletModeFromWsrpMode(HANDLE, "vignette:config");
        assertEquals(new PortletMode("config"), portletMode);

        portletMode = mapper.getPortletModeFromWsrpMode(HANDLE, "vignette:help");
        assertEquals(new PortletMode("help"), portletMode);
    }
}
