package com.hp.frameworks.wpa.wsrp4j;

import org.dbunit.database.IDatabaseConnection;
import org.dbunit.database.DatabaseSequenceFilter;
import org.dbunit.dataset.xml.FlatXmlWriter;
import org.dbunit.dataset.xml.FlatDtdDataSet;
import org.dbunit.dataset.filter.ITableFilter;
import org.dbunit.dataset.FilteredDataSet;
import org.dbunit.ext.mssql.MsSqlConnection;

import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBUnitDatabaseExport
{
	public static void main(String[] args) throws Exception
	{
		// database connection
		Class driverClass = Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection jdbcConnection = DriverManager.getConnection(
				"jdbc:sqlserver://alvis-01.mayfield.hp.com:1433;DatabaseName=wsrp4j-test", "wsrp4j", "wsrp4j");
		IDatabaseConnection connection = new MsSqlConnection(jdbcConnection);
		ITableFilter filter = new DatabaseSequenceFilter(connection);

		// partial database export
		/*
		QueryDataSet partialDataSet = new QueryDataSet(connection);
		partialDataSet.addTable("FOO", "SELECT * FROM TABLE WHERE COL='VALUE'");
		partialDataSet.addTable("BAR");
		FlatXmlDataSet.write(partialDataSet, new FileOutputStream("partial.xml"));
		*/

		// write DTD file
        FlatDtdDataSet.write(connection.createDataSet(),
                new FileOutputStream("wsrp4j_db.dtd"));

		// full database export
		FlatXmlWriter datasetWriter = new FlatXmlWriter(
            new FileOutputStream("wsrp4j_db.xml"));
    	datasetWriter.setDocType("wsrp4j_db.dtd");
    	datasetWriter.write(new FilteredDataSet(filter,connection.createDataSet()));

	}
}
