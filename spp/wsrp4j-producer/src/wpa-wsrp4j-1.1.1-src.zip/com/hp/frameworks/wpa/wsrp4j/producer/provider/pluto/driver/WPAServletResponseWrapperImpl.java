package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;


import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.util.Utility;

import java.io.*;


/**
 * <p>
 * This class is used to buffer the rendered response when a portlet is invoked.
 * This class is being used as a replacement for the WSRP4J-provided
 * StoredResponse class. StoredResponse implements only the getWriter() method,
 * however the getOutputStream() method is needed for compatibility with
 * WebLogic.
 * </p>
 * 
 * <p>
 * This class is implemented as a HttpServletResponseWrapper instead of a simple
 * extension to the StoredResponse class. This was necessary because there is
 * some code in WebLogic that looks specifically for an instance of their
 * response object. By wrapping the original response we can still capture the
 * generated output and make WebLogic happy at the same time.
 * </p>
 * 
 * <p>
 * If the StoredResponse class were to implement the getOutputStream() method
 * and be changed to a response wrapper at some point in the future, this class
 * could be safely eliminated.
 * </p>
 * 
 * <p>
 * This class is directly instantiated in both the invokeGetMarkup() and
 * invokedPerformBlockingInteraction() methods of the WPAProtletInvokerImpl
 * class.
 * </p>
 */
public class WPAServletResponseWrapperImpl extends HttpServletResponseWrapper
        implements Serializable
{
    
	// ---------------------------------------------------------- Class Members  
    
    
    private static final Log log = 
        LogFactory.getLog(WPAServletResponseWrapperImpl.class);

    
	// ------------------------------------------------------ Protected Members


    // String writer used when getWriter() is called
    protected StringWriter stringWriter;

    // Wrapper for the string writer
    protected PrintWriter writer;

    // Byte array stream used when getOutputStream is called
    protected ByteArrayOutputStream byteArrayOutputStream;


	// ----------------------------------------------------------- Constructors


    public WPAServletResponseWrapperImpl(HttpServletResponse response)
    {
		super(response);
        
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("constructor"));
            log.debug(Utility.strExit("constructor"));
        } 
	}


	// --------------------------------------------------------- Public Methods


    /**
     * Returns a ServletOutputStream suitable for writing binary data in the
     * response.  Either this method of getWriter() may be called to write the
     * body, not both.
     */
    public ServletOutputStream getOutputStream() throws IOException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getOutputStream"));
        } 

		if (this.byteArrayOutputStream == null)
        {
            this.byteArrayOutputStream = new ByteArrayOutputStream();
        }

        ServletOutputStream servletOutputStream = new ServletOutputStream()
        {
            public void write(int b)
            {
                byteArrayOutputStream.write(b);
            }
        };

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getOutputStream"));
        } 
        
        return servletOutputStream;
    }



    /**
     * Returns a PrintWriter object that can send character text to the
     * client.  Either this method of getWriter() may be called to write the
     * body, not both.
     */
    public PrintWriter getWriter()
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getWriter"));
        } 

		if (this.writer == null)
        {
            this.stringWriter = new StringWriter();
            this.writer = new PrintWriter(this.stringWriter);
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getWriter"));
        }         
        return this.writer;
    }


    /**
     * Due to some weirdness in WSRP4J/Pluto that we don't quite understand
     * it is important that any calls to sendRedirect get swallowed.  The
     * StoredResponse class that we are replacing does this and testing has
     * shown that it is important that we do it also.
     */
    public void sendRedirect(String s) 
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("sendRedirect"));
            log.debug(Utility.strExit("sendRedirect"));
        } 
    }


    /**
     * Returns the output buffer content as String
     * 
     * @return java.lang.String
     */
    public String getOutputBufferAsString() throws IOException
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getOutputBufferAsString"));
        } 

		String output = "";

        if (this.byteArrayOutputStream != null)
        {
            output = this.byteArrayOutputStream.toString();
        }
        else if (this.stringWriter != null)
        {
            output = this.stringWriter.getBuffer().toString();
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getOutputBufferAsString"));
        }
        
        return output;
    }

}
