package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import org.apache.pluto.PortletContainer;
import org.apache.wsrp4j.commons.exception.WSRPException;
import org.apache.wsrp4j.commons.producer.provider.interfaces.DescriptionHandler;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletInvoker;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletPool;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletRegistrationFilter;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletRegistrationFilterWriter;
import org.apache.wsrp4j.commons.producer.provider.interfaces.PortletStateManager;
import org.apache.wsrp4j.commons.producer.provider.interfaces.URLComposer;
import org.apache.wsrp4j.producer.provider.pluto.driver.ProviderImpl;
import org.apache.wsrp4j.producer.provider.pluto.interfaces.PlutoPortletPool;
import org.apache.wsrp4j.producer.provider.pluto.interfaces.PlutoProvider;

/**
 * <p>
 * This class is provided so that we can implement our own PortletInvoker and
 * DescriptionHandler. The PortletInvoker is not a pluggable class, but the
 * Provider is, so we've created our own Provider that is responsible for
 * instantiating and returning our custom PortletInvoker. Similarly, the
 * DescriptionHandler implementation isn't configurable so we have to directly
 * instantiate it here.
 * </p>
 * 
 * <p>
 * As in so many other instances, the WSRP4J-provided ProviderImpl cannot be
 * extended due to the presence of a private constructor (thanks again WSRP4J
 * development team -- much appreciated!). Instead, we are forced to provide our
 * own implementation of the PlutoProvider interface. In order to avoid having
 * to re-implement ALL of the methods of the this interface, we instantiate the
 * WSRP4J-provided ProviderImpl and delegate most of the methods to this
 * instance. The only methods that we are providing a truly custom
 * implementation for are getPortletInvoker() and getDescriptionHandler().
 * </p>
 * 
 * <p>
 * If future versions of WSRP4J provide a declarative mechanism for registering
 * a PortletInvoker a DescriptionHandler implementation, this class could be
 * safely deleted.
 * </p>
 * 
 * <p>
 * This class is not directly instantiated, it is created by the
 * WPAProviderFactoryImpl. The factory is then registered in the
 * /WEB-INF/classes/WSRPServices.properties file.
 * </p>
 * 
 * <p>
 * NOTE: In the WSRP4J-provided ProviderImpl, some of the methods create
 * instances of other classes and pass a "this" reference to those classses.
 * Since we are delegating much of our implementation to the ProviderImpl we
 * end-up with a situation where the "this" reference points to a ProviderImpl
 * instead of our WPAProviderImpl. We haven't yet run into any problems because
 * of this, but if we do, this will be a good place to start looking. The
 * methods where this may be an issue are marked below for future reference.
 * </p>
 */
public class WPAProviderImpl implements PlutoProvider
{
    
	// ------------------------------------------------------ Protected Members    
    
    
    // This is the instance of the WSRP4J-provided class that we delegate most
    // of the method calls to
    protected ProviderImpl baseProvider;
            
    // Our custom PortletInvoker
    protected PortletInvoker portletInvoker;
    
    // Our custom description handler which deals with our custom
    // portlet mode mapping
    protected DescriptionHandler descriptionHandler;
    
    
	// ----------------------------------------------------------- Constructors
    
    
    public WPAProviderImpl()
    {
        this.baseProvider = ProviderImpl.create();
    }
    
    
	// --------------------------------------------------------- Public Methods
    
    
    /**
     * Delegate to WSRP4J-provided implementation.
     */
    public PortletContainer getPortletContainer()
    {
        return this.baseProvider.getPortletContainer();
    }


    /**
     * Delegate to WSRP4J-provided implementation.
     */    
    public PlutoPortletPool getPlutoPortletPool()
    {
        return this.baseProvider.getPlutoPortletPool();
    }


    /**
     * Providing a custom implementation for this method so that we can return
     * our custom description handler which is responsible for handling
     * portlet-to-WSRP mode mapping
     */
    public DescriptionHandler getDescriptionHandler()
    {
        if (this.descriptionHandler == null) 
        {            
            this.descriptionHandler = WPADescriptionHandlerImpl.create(this);            
        }
        
        return this.descriptionHandler;
    }


    /**
     * We are providing a custom implementation of this method so that we can
     * return our custom PortletInvoker
     */
    public PortletInvoker getPortletInvoker()
    {
        if (this.portletInvoker == null) 
        {
            this.portletInvoker = WPAPortletInvokerImpl.create(this);
        }
        
        return this.portletInvoker;
    }


    /**
     * Note: ProviderImpl uses a "this" reference when instantiating the
     * PortletPool.  This could be a problem depending on how the PortletPool 
     * makes use of that reference.
     */    
    public PortletPool getPortletPool()
    {
        return this.baseProvider.getPortletPool();
    }


    /**
     * Delegate to WSRP4J-provided implementation.
     */    
    public PortletStateManager getPortletStateManager() throws WSRPException
    {
        return this.baseProvider.getPortletStateManager();
    }


    /**
     * Note: ProviderImpl uses a "this" reference when instantiating the
     * URLComposer.  This could be a problem depending on how the URLComposer 
     * makes use of that reference.
     */    
    public URLComposer getURLComposer()
    {
        return this.baseProvider.getURLComposer();
    }


    /**
     * Delegate to WSRP4J-provided implementation.
     */    
    public PortletRegistrationFilterWriter getPortletRegistrationFilterWriter()
    {
        return this.baseProvider.getPortletRegistrationFilterWriter();
    }


    /**
     * Delegate to WSRP4J-provided implementation.
     */    
    public PortletRegistrationFilter getPortletRegistrationFilter()
    {
        return this.baseProvider.getPortletRegistrationFilter();        
    }

}
