package com.hp.frameworks.wpa.wsrp4j.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;

import javax.portlet.PortletMode;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>
 * Provides a read-only interface to the contents of the ModeMap.properties
 * configuration file. The ModeMap.properties file contains the mappings
 * between JSR-168 and WSRP portlet modes.
 * </p>
 */
public class ModeMapper
{


	// ------------------------------------------------------ Private Constants

	
	private final static String USER_CONFIG_FILE = 
		"/ModeMap.properties";

	
	// -------------------------------------------------------- Private Members	

	
	private static ModeMapper singleton = new ModeMapper();
    
      
    private static final Log log = 
        LogFactory.getLog(ModeMapper.class); 

    
	// ------------------------------------------------------ Protected Members


	/**
	 * Map from a portlet mode name to the corresponding WSRP mode.
	 */
	protected HashMap portletToWsrpModeMap = new HashMap();


	/**
	 * Map from a WSRP mode name to a portlet mode.
	 */
	protected HashMap wsrpToPortletModeMap = new HashMap();


	// ---------------------------------------------------------- Class Methods


	/**
	* Returns the single allowable instance of this class.
	**/
	public static ModeMapper getInstance()
	{
		return singleton;
	}


	// ----------------------------------------------------------- Constructors

	
	/**
	 * Default constructor. Loads the entries from the ModeMap.properties
	 * configuration.
	 */
	protected ModeMapper()
	{
		this.loadMappings();
	}


	// --------------------------------------------------------- Public Methods


	/**
	 * Returns the WSRP mode name associated with the given portlet mode.
	 */
	public String getWsrpModeFromPortletMode(String portletHandle,
			String portletMode)
	{
		String wsrpMode = null;
		
		if (this.portletToWsrpModeMap != null) 
		{
			String key = portletHandle + "." + portletMode;
			
			wsrpMode = (String) this.portletToWsrpModeMap.get(key);
			
			if (wsrpMode == null)
			{
				wsrpMode = (String) 
					this.portletToWsrpModeMap.get(portletMode);
			}
		}
		
		if (wsrpMode == null)
		{
            if (portletMode.indexOf(":") == -1)
            {
                wsrpMode = "wsrp:" + portletMode;
            }
            else
            {
                wsrpMode = portletMode;
            }
		}
		
        if (log.isDebugEnabled())
        {
            log.debug("Translating Portlet mode " + portletMode
                    + " to WSRP mode " + wsrpMode);
        }
        
		return wsrpMode;
	}


	/**
	 * Returns the porlet mode associated with the given WSRP mode name.
	 */
	public PortletMode getPortletModeFromWsrpMode(String portletHandle, 
			String wsrpMode)
	{		
		PortletMode portletMode = null;
		
		if (this.wsrpToPortletModeMap != null) 
		{
			String key = portletHandle + "." + wsrpMode;
			
			portletMode = (PortletMode) this.wsrpToPortletModeMap.get(key);
			
			if (portletMode == null)
			{
				portletMode = 
					(PortletMode) this.wsrpToPortletModeMap.get(wsrpMode);
			}
		}
		
		if (portletMode == null)
		{
            if (wsrpMode.startsWith("wsrp:"))
            {
                portletMode = 
                    new PortletMode(wsrpMode.substring(wsrpMode.indexOf(":") + 1));
            }
            else
            {
                portletMode = new PortletMode(wsrpMode);
            }
		}

        if (log.isDebugEnabled())
        {
            log.debug("Translating WSRP mode " + wsrpMode + " to portlet mode "
                    + portletMode.toString());
        }
        
		return portletMode;
	}


	// ------------------------------------------------------ Protected Methods


	/**
	 * Uses the classloader associted with this class to load the contents of
	 * the ModeMap.properties file.  The property values are used to populate
	 * the hash maps used to map back and forth between portlet modes and
	 * WSRP modes.
	 */
	protected void loadMappings() 
	{
		Properties properties = new Properties();

		try 
		{
			InputStream stream = 
				this.getClass().getResourceAsStream(USER_CONFIG_FILE);

			if (stream != null) 
			{
				properties.load(stream);
			}			
		} 
		catch (IOException e) 
		{
            log.error("Error loading modemap properties", e);
		}

		Enumeration e = properties.propertyNames();

		while (e.hasMoreElements())
		{
			String key = (String) e.nextElement();
			String value = properties.getProperty(key);
			
			// Portlet-to-WSRP mapping
			this.portletToWsrpModeMap.put(key, value);
			
			// WSRP-to-Portlet mapping
			if (key.indexOf(".") != -1)
			{
				String portletHandle = key.substring(0, key.lastIndexOf("."));
				String portletMode = key.substring(key.lastIndexOf(".") + 1);
				
				this.wsrpToPortletModeMap.put(portletHandle + "." + value, 
						new PortletMode(portletMode));				
			}
			else
			{
				this.wsrpToPortletModeMap.put(value, new PortletMode(key));
			}			
		}         
	}
}