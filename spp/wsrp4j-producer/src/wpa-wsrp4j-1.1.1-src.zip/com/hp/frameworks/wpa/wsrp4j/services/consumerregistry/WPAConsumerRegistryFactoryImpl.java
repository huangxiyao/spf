package com.hp.frameworks.wpa.wsrp4j.services.consumerregistry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wsrp4j.commons.producer.interfaces.ConsumerRegistry;
import org.apache.wsrp4j.commons.producer.interfaces.ConsumerRegistryFactory;
import org.apache.wsrp4j.commons.producer.provider.interfaces.Provider;
import org.apache.wsrp4j.commons.util.Utility;


/**
 * <p>
 * This class is solely responsible for instantiating and returning an instance
 * of the WPAConsumerRegistryImpl.
 * </p>
 * 
 * <p>
 * This class must be registered in the /WEB-INF/classes/WSRPServices.properties
 * file under the following key name: consumer.registry.factory
 * </p>
 */
public class WPAConsumerRegistryFactoryImpl implements ConsumerRegistryFactory
{

    // ---------------------------------------------------------- Class Members

    
    private static final Log log = 
        LogFactory.getLog(WPAConsumerRegistryFactoryImpl.class); 
    
    
    // Single allowable instance of consumer registry
    private static ConsumerRegistry consumerRegistry;


    // ---------------------------------------------------------- Class Methods

    
    /**
     * Returns an instance of the ConsumerRegistry
     */
    public synchronized ConsumerRegistry getConsumerRegistry(Provider provider)
    {
        if (log.isDebugEnabled()) {
            log.debug(Utility.strEnter("getConsumerRegistry"));
        } 
        
        if (consumerRegistry == null)
        {
            consumerRegistry = new WPAConsumerRegistryImpl(provider);
        }

        if (log.isDebugEnabled()) {
            log.debug(Utility.strExit("getConsumerRegistry"));
        } 
        
        return consumerRegistry;
    }

}
