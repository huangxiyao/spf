package com.hp.frameworks.wpa.wsrp4j.om.common.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import javax.portlet.PreferencesValidator;

import org.apache.pluto.om.common.Preference;
import org.apache.pluto.om.common.PreferenceSet;
import org.apache.pluto.om.common.PreferenceSetCtrl;


/**
 * <p>
 * This class is a simple implementation of the PreferenceSet and 
 * PreferenceSetCtrl interfaces that is used in conjunction with the
 * DB-based portlet entity registry.
 * </p>
 * 
 * <p>
 * This class is really only necessary because we have a custom implementation
 * of the Preference interface that we need to use for our DB-persistable
 * portlet entity registry.
 * </p>
 */
public class WPAPreferenceSetImpl extends HashSet implements PreferenceSet,
        PreferenceSetCtrl, Serializable
{

	// --------------------------------------------------------- Public Methods
    
    
    /**
     * Returns the preference with the given name.  If no preference with the 
     * given name can be located, null is returned.
     */
    public Preference get(String name)
    {
        Preference result = null;
        Iterator i = this.iterator();
        
        while (i.hasNext()) 
        {
            Preference preference = (Preference) i.next();
        
            if (preference.getName().equals(name)) 
            {
                result = preference;
                break;
            }
        }
        
        return result;
    }


    /**
     * This method always returns null, preference validators are not currently
     * supported.
     */
    public PreferencesValidator getPreferencesValidator()
    {
        return null;
    }


    /**
     * Creates a new preference with the given name/values and adds it to this
     * collection.
     */
    public Preference add(String name, List values)
    {
        WPAPreferenceImpl preference = new WPAPreferenceImpl();
        preference.setName(name);
        preference.setValues(values);

        super.add(preference);

        return preference;
    }


    /**
     * Removes the preference with the given name from this collection.  The
     * removed preference is returned from this method.  If the named 
     * preference can't be located, null is returned.
     */
    public Preference remove(String name)
    {
        Preference result = null;        
        Iterator i = this.iterator();
        
        while (i.hasNext()) 
        {
            Preference preference = (Preference) i.next();
        
            if (preference.getName().equals(name)) 
            {
                super.remove(preference);
                result = preference;
                break;
            }
        }
        
        return result;
    }


    /**
     * Removes the given preference from this collection.
     */
    public void remove(Preference preference)
    {
        super.remove(preference);
    }

    
    /**
     * Adds the given collection of preferences to this collection.  All
     * preferences are cloned before being added.
     */
    public boolean addAll(Collection c) 
    {
        Iterator i = c.iterator();
        
        while (i.hasNext()) 
        {
            WPAPreferenceImpl pref = (WPAPreferenceImpl) i.next();
            this.add(pref.clone());
        }

        return true;  
    }    
    
    
    public String toString()
    {
      StringBuffer buffer = new StringBuffer();
        
        buffer.append(this.getClass().toString());
        buffer.append("{\n");
        
        Iterator i = this.iterator();
        
        while (i.hasNext())
        {
            buffer.append(i.next().toString());
            buffer.append("\n");
        }
        
        buffer.append("}\n");
        
        return buffer.toString();        
    }
}
