package com.hp.frameworks.wpa.wsrp4j.producer.provider.pluto.driver;

import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.pluto.om.window.PortletWindow;
import org.apache.wsrp4j.producer.provider.pluto.driver.WSRPServletRequestWrapperImpl;

/**
 * <p>
 * This class serves as the HttpServletRequest that is used to initiate a 
 * portlet request.  This class extends the WSRP4J-provided 
 * WSRPServletRequestWrapperImpl and overrides the getRemoteUser() method
 * so that the user information sent in the WSRP &lt;userContextKey&gt; field
 * can be propagated down the the portlet.
 * </p>
 *
 * <p>
 * If the WSRPServletRequestWrapperImpl class implements the getRemoteUser() 
 * method at some point in the future, this class can be safely eliminated.
 * </p>
 * 
 * <p>
 * This class is directly instantiated in both the invokeGetMarkup() and
 * invokePerformBlockingInteraction() methods of the WPAProtletInvokerImpl
 * class.
 * </p>
 * 
 * @version $Id: WPAServletRequestWrapperImpl.java,v 1.2 2006/03/21 10:42:26 bdehamer Exp $
 */
public class WPAServletRequestWrapperImpl extends WSRPServletRequestWrapperImpl
{

	// ------------------------------------------------------ Protected Members
	
    
    // ID of the remote user
    protected String userContextKey;


	// ----------------------------------------------------------- Constructors    

    
    public WPAServletRequestWrapperImpl(HttpServletRequest request,
            PortletWindow window, Locale locale, String mimeType, Map parameters)
    {
        super(request, window, locale, mimeType, parameters);
    }

    
	// --------------------------------------------------------- Public Methods
    
    /**
     * Returns the login of the user making this request, if the user has been
     * authenticated, or null if the user has not been authenticated.
     */
    public String getRemoteUser()
    {
        return this.userContextKey;
    }

        
    /**
     * Sets the value of the WSRP user context key.
     */
	public void setUserContextKey(String userContextKey) 
    {
		this.userContextKey = userContextKey;
	}
}
